
#include "Led.h"

/**
*Led0Taskά���ı���
*
*/

uint8_t Led0FlashPreScale = 1;
uint8_t Led0FlashPreScaleIndex = 0;
uint8_t Led0FlashPeriod = 10;
uint8_t Led0FlashPause = 0;							//��Ҫ�ı��
uint8_t Led0FlashIndex = 0;
uint8_t IsNeedSetLed0 = 1;
uint8_t IsNeedResetLed0 = 1;
uint8_t IsLed0Off2On = 1;

void Led0Task(void)
{
	if(++Led0FlashIndex > Led0FlashPeriod)
	{
		//һ�����ڵ�
		//����װ��
		Led0FlashIndex = 0;
		IsNeedSetLed0 = 1;
		IsNeedResetLed0 = 1;
		if(++Led0FlashPreScaleIndex > Led0FlashPreScale)
		{
			Led0FlashPreScaleIndex = 0;
			//ת���ķ���
			if(IsLed0Off2On)
			{
				//������������������
				if(++Led0FlashPause > Led0FlashPeriod)
				{
					//�����������
					IsLed0Off2On = 0;
				}
			}else
			{
				if(--Led0FlashPause == 0)
				{
					IsLed0Off2On = 1;
				}
			}
		}
	}else
	{
		//����һ��������
		if(Led0FlashIndex > Led0FlashPause)
		{
			//�ߵ�ƽ
			if(IsNeedSetLed0)
			{
				IsNeedSetLed0 = 0;
				HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
			}
		}else
		{
			//�͵�ƽ
			if(IsNeedResetLed0)
			{
				IsNeedResetLed0 = 0;
				HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
			}
		}
	}
}

void Led0TaskErrorHnadler(void)
{
	while(1)
	{
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
	}
}

void Led0FlashTask(void)
{
	
}

void Led0FlashTaskErrorHandler(void)
{
	
}

void Led1Task(void)
{
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
}

void Led1TaskErrorHnadler(void)
{
	while(1)
	{
		HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);
	}	
}

void Callback0(void)
{
	HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
}

void Callback1(void)
{
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
}

void Callback2(void)
{
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
}


	

