
#include "Scheduler.h"

Task SCH_TASKS[SCH_MAX_TASKS];

void InitTasksStacks(void)
{
	uint32_t Index = 0;
	
	for(Index=0; Index<SCH_MAX_TASKS; Index++)
	{
		SCH_TASKS[Index].pTask = NULL;
		SCH_TASKS[Index].Delay = 0;
		SCH_TASKS[Index].Period = 0;
		SCH_TASKS[Index].RunMe = 0;
		SCH_TASKS[Index].IsRunIng = 0;
		SCH_TASKS[Index].pErrorHandler = NULL;
	}		
}

uint8_t SCH_Add_Task(void(*pTask)(void), uint32_t Delay, uint32_t Period, uint8_t RunMe, void(*pErrorHandler)(void))
{
	uint32_t Index = 0;
	
	for(Index=0; Index<SCH_MAX_TASKS; Index++)
	{
		//������ǿյģ����Լӽ���
		if(SCH_TASKS[Index].pTask == NULL)
		{
			SCH_TASKS[Index].pTask = pTask;
			SCH_TASKS[Index].Delay = Delay;
			SCH_TASKS[Index].Period = Period;
			SCH_TASKS[Index].RunMe = RunMe;
			SCH_TASKS[Index].IsRunIng = 0;
			SCH_TASKS[Index].pErrorHandler = pErrorHandler;
			
			return Index;
		}
	}
	
	return FAILED;
}

uint8_t SCH_SetPeriod(uint8_t index, uint32_t Period)
{
	if(index < SCH_MAX_TASKS)
	{
		SCH_TASKS[index].Period = Period;
		return index;
	}
	
	return FAILED;
}

uint8_t SCH_GetTaskId(void(*pTask)(void))
{
	uint32_t Index = 0;
	
	for(Index=0; Index<SCH_MAX_TASKS; Index++)
	{
		if(SCH_TASKS[Index].pTask == pTask)
		{
			return Index;
		}
	}		
	return FAILED;
}

void SCH_UpdataErrorHandler(void)
{
	while(1)
	{
		
	}
}

uint8_t IsSCH_UpdataIng = 0;
uint8_t IsSCH_UpdataNeedRunIng = 1;

void SCH_Updata(void)
{
	uint32_t Index = 0;
	if(IsSCH_UpdataIng == 0)
	{
		IsSCH_UpdataIng = 1;
		if(IsSCH_UpdataNeedRunIng)
		{
			for(Index=0; Index<SCH_MAX_TASKS; Index++)
			{
				//���������
				if(SCH_TASKS[Index].pTask)
				{
					//�����ʱʱ�䵽
					if(SCH_TASKS[Index].Delay == 0)
					{
						//��־Ҫִ��
						SCH_TASKS[Index].RunMe++;
						//����������Ե�
						if(SCH_TASKS[Index].Period)
						{
							//��װ����ʱʱ��
							SCH_TASKS[Index].Delay = SCH_TASKS[Index].Period;
						}
					}else
					{
						//����ʱʱ��--
						SCH_TASKS[Index].Delay--;
					}
				}
			}
		}
		IsSCH_UpdataIng = 0;
	}else
	{
		//���������в�������
		IsSCH_UpdataNeedRunIng = 0;
		//ֹͣ������
		SCH_UpdataErrorHandler();
	}
}

void SCH_Disptch_Tasks(void)
{
	uint32_t Index = 0;
	
	for(Index=0; Index<SCH_MAX_TASKS; Index++)
	{
		//���������
		if(SCH_TASKS[Index].pTask)
		{
			//�����Ҫִ��
			if(SCH_TASKS[Index].RunMe)
			{
				if(SCH_TASKS[Index].IsRunIng == 0)
				{
					//ִ�д�����һ
					SCH_TASKS[Index].RunMe--;
					//ִ��
					SCH_TASKS[Index].IsRunIng = 1;
					(SCH_TASKS[Index].pTask)();
					SCH_TASKS[Index].IsRunIng = 0;
					//�����������ִ��
					if(SCH_TASKS[Index].Period == 0)
					{
						//ɾ������
						SCH_TASKS[Index].pTask = NULL;
					}
				}else
				{
					//ʱ��ִ�в�������
					//ɾ������
						SCH_TASKS[Index].pTask = NULL;
					//�����˴���
					(SCH_TASKS[Index].pErrorHandler)();
				}
			}
		}
	}
}

uint8_t SCH_Delete_Tasks(uint8_t Index)
{
	if(Index < SCH_MAX_TASKS)
	{
		//ɾ������
		SCH_TASKS[Index].pTask = NULL;
	}
	
	return FAILED;
}
