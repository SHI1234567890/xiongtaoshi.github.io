
#include "Key.h"

uint8_t KeyBuffer[KEY_NUMBER] = {0X00, 0XFF, 0XFF};
uint8_t KeyNowStat[KEY_NUMBER] = {0, 0, 0};

void KEY_Scan(void)
{
	uint8_t index = 0;
	
	KeyBuffer[KEY_0] = (KeyBuffer[KEY_0] << 1)|ReadKey0();
  KeyBuffer[KEY_1] = (KeyBuffer[KEY_1] << 1)|ReadKey1();
  KeyBuffer[KEY_2] = (KeyBuffer[KEY_2] << 1)|ReadKey2();

	for(index=0; index<KEY_NUMBER; index++)
	{
		if(KeyBuffer[index] == 0x00)
		{
			KeyNowStat[index] = KEY_UP;
		}else if(KeyBuffer[index] == 0xff)
		{
			KeyNowStat[index] = KEY_DOWN;
		}
	}
}
	
void KEY_ScanErrorHandler(void)
{
	
}

uint8_t KeyBackupStat[KEY_NUMBER] = {0, 0, 0};
uint8_t PreesedKey = KEY_NUMBER;

uint8_t getPreesedKey(void)
{
	uint8_t tempValue = PreesedKey;
	
	PreesedKey = KEY_NUMBER;
	
	return tempValue;
}

void Key_Driver(void)
{
	uint8_t index = 0;
	
	for(index=0; index<KEY_NUMBER; index++)
	{
		if(KeyBackupStat[index] != KeyNowStat[index])
		{
			if(KeyBackupStat[index])
			{
				PreesedKey = index;
			}
			KeyBackupStat[index] = KeyNowStat[index];
		}
	}
}

void Key_DriverErrorHandler(void)
{
	
}

void (*pKeyEventCallback[KEY_NUMBER])(void) = 
{
	NULL, 
	NULL, 
	NULL
};

pArray callbackArray = 
{
	 NULL,
	 NULL,
	 NULL
};

void InitKeyEventCallbackStcks(void)
{
	uint8_t index = 0;
	
	for(index=0; index<KEY_NUMBER; index++)
	{
		pKeyEventCallback[index] = NULL;
		callbackArray[index] = NULL;
	}
}

uint8_t Add_KeyEventCallback(void(*pCallback)(void), uint8_t index)
{
	if(index < KEY_NUMBER)
	{
		pKeyEventCallback[index] = pCallback;
		callbackArray[index] = pCallback;
		
		return index;
	}
	
	return ADD_KEY_EVENT_CALLBACK_FAILED;
}

uint8_t tempPreesedKey;

void Key_Event(void)
{
	tempPreesedKey = getPreesedKey();
	
	if(tempPreesedKey < KEY_NUMBER)
	{
		//(pKeyEventCallback[PreesedKey])();
		callbackArray[tempPreesedKey]();
// 		if(pKeyEventCallback[PreesedKey] != NULL)
// 		{
// 			//ִ��
// 			(pKeyEventCallback[PreesedKey])();
// 		}else
// 		{
// 			PreesedKey = KEY_NUMBER;
// 		}
	}	
}

void Key_EventErrorHandler(void)
{	
	
}





