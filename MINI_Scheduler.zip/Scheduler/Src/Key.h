#ifndef _KEY_H
#define _KEY_H

#include "stm32f1xx_hal.h"

#define KEY_NUMBER					((uint8_t)3)
#define KEY_0								((uint8_t)0)
#define KEY_1								((uint8_t)1)
#define KEY_2								((uint8_t)2)

#define ReadKey0()					HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin);
#define ReadKey1()					HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin);
#define ReadKey2()					HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin);

#define KEY_UP	  ((uint8_t)0)
#define KEY_DOWN	((uint8_t)1)

#define ADD_KEY_EVENT_CALLBACK_SUCCEED	((uint8_t)1)
#define ADD_KEY_EVENT_CALLBACK_FAILED	  ((uint8_t)0)

typedef void(*pArray[])(void);

void KEY_Scan(void);
void KEY_ScanErrorHandler(void);
void Key_Driver(void);
void Key_DriverErrorHandler(void);
void Key_Event(void);
void Key_EventErrorHandler(void);
void InitKeyEventCallbackStcks(void);
uint8_t Add_KeyEventCallback(void(*pCallback)(void), uint8_t index);

uint8_t getPreesedKey(void);

#endif
