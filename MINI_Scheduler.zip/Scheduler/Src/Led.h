#ifndef _LED_H
#define _LED_H

#include "stm32f1xx_hal.h"

void Led0Task(void);
void Led0TaskErrorHnadler(void);
void Led0FlashTask(void);
void Led0FlashTaskErrorHandler(void);
void Led1Task(void);
void Led1TaskErrorHnadler(void);
void Callback0(void);
void Callback1(void);
void Callback2(void);

#endif
