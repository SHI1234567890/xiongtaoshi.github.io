
#include "Record/record.h"

RECORD::RECORD()
{
    //角度文件
    angleFile.setFileName("/home/pi/SensorData/angleFile.txt");
    if(angleFile.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    angleOut.setDevice(&angleFile);

    //MPU60501
    mpu60501File.setFileName("/home/pi/SensorData/mpu60501File.txt");
    if(mpu60501File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    mpu60501Out.setDevice(&mpu60501File);

    //MPU60502
    mpu60502File.setFileName("/home/pi/SensorData/mpu60502File.txt");
    if(mpu60502File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    mpu60502Out.setDevice(&mpu60502File);

    //HMC5883L1
    hmc5883l1File.setFileName("/home/pi/SensorData/hmc5883l1File.txt");
    if(hmc5883l1File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    hmc5883l1Out.setDevice(&hmc5883l1File);

    //HMC5883L2
    hmc5883l2File.setFileName("/home/pi/SensorData/hmc5883l2File.txt");
    if(hmc5883l2File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    hmc5883l2Out.setDevice(&hmc5883l2File);

    //MS56111
    ms56111File.setFileName("/home/pi/SensorData/ms56111File.txt");
    if(ms56111File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    ms56111Out.setDevice(&ms56111File);

    //MS56112
    ms56112File.setFileName("/home/pi/SensorData/ms56112File.txt");
    if(ms56112File.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    ms56112Out.setDevice(&ms56112File);

    //GPS
    gpsFile.setFileName("/home/pi/SensorData/gpsFile.txt");
    if(gpsFile.open(QIODevice::Append|QIODevice::Text) < 0)
    {
        qDebug()<<"Unable to open file";
    }else
    {
        qDebug()<<"Be able to open file";
    }
    gpsOut.setDevice(&gpsFile);
}

RECORD::~RECORD()
{
    if(angleFile.isOpen())
    {
        angleFile.close();
    }
    if(mpu60501File.isOpen())
    {
        mpu60501File.close();
    }
    if(mpu60502File.isOpen())
    {
        mpu60502File.close();
    }
    if(hmc5883l1File.isOpen())
    {
        hmc5883l1File.close();
    }
    if(hmc5883l2File.isOpen())
    {
        hmc5883l2File.close();
    }
    if(ms56111File.isOpen())
    {
        ms56111File.close();
    }
    if(ms56112File.isOpen())
    {
        ms56112File.close();
    }
    if(gpsFile.isOpen())
    {
        gpsFile.close();
    }
}

void RECORD::WriteMpu6050Data(Mpu6050DataTypedef *mpu6050Data1, Mpu6050DataTypedef *mpu6050Data2)
{
    if(mpu60501File.isOpen())
    {
        mpu60501Out << mpu6050Data1->Mpu6050AccX << " "
                    << mpu6050Data1->Mpu6050AccY << " "
                    << mpu6050Data1->Mpu6050AccZ << " "
                    << mpu6050Data1->Mpu6050Temp << " "
                    << mpu6050Data1->Mpu6050GyroX << " "
                    << mpu6050Data1->Mpu6050GyroY << " "
                    << mpu6050Data1->Mpu6050GyroZ << endl;
    }

    if(mpu60502File.isOpen())
    {
        mpu60502Out << mpu6050Data2->Mpu6050AccX << " "
                    << mpu6050Data2->Mpu6050AccY << " "
                    << mpu6050Data2->Mpu6050AccZ << " "
                    << mpu6050Data2->Mpu6050Temp << " "
                    << mpu6050Data2->Mpu6050GyroX << " "
                    << mpu6050Data2->Mpu6050GyroY << " "
                    << mpu6050Data2->Mpu6050GyroZ << endl;
    }
}

void RECORD::WriteHmc5883lData(Hmc5883lDataTypedef *hmc5883lData1, Hmc5883lDataTypedef *hmc5883lData2)
{
    if(hmc5883l1File.isOpen())
    {
        hmc5883l1Out << hmc5883lData1->Hmc5883lMagX << " "
                     << hmc5883lData1->Hmc5883lMagY << " "
                     << hmc5883lData1->Hmc5883lMagZ << endl;
    }

    if(hmc5883l2File.isOpen())
    {
        hmc5883l2Out << hmc5883lData2->Hmc5883lMagX << " "
                     << hmc5883lData2->Hmc5883lMagY << " "
                     << hmc5883lData2->Hmc5883lMagZ << endl;
    }
}

void RECORD::WriteMs5611Data(Ms5611DataTypedef *ms5611Data1, Ms5611DataTypedef *ms5611Data2)
{
    if(ms56111File.isOpen())
    {
        ms56111Out << ms5611Data1->Ms5611P << endl;
    }

    if(ms56112File.isOpen())
    {
        ms56112Out << ms5611Data2->Ms5611P << endl;
    }
}

void RECORD::WriteGpsData(GpsDataTypedef *gpsData)
{
    if(gpsFile.isOpen())
    {
        gpsOut << gpsData->IsFixOk << " "
               << gpsData->longitude << " "
               << gpsData->latitude << " "
               << gpsData->height << " "
               << gpsData->hAcc << " "
               << gpsData->vAcc << " "
               << gpsData->velN << " "
               << gpsData->velE << " "
               << gpsData->velD << endl;
    }
}

void RECORD::WriteAngleData(AngleDataTypedef *angleData)
{
    if(angleFile.isOpen())
    {
        angleOut << angleData->AngleX << " "
                 << angleData->AngleY << " "
                 << angleData->AngleZ << endl;
    }
}
