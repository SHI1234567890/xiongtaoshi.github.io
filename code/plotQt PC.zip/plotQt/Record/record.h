#ifndef RECORD_H
#define RECORD_H

#include "Typedef/typedef.h"
#include "QFile"
#include "QTextStream"
#include "QDebug"

class RECORD
{
public:
    RECORD();
    ~RECORD();

    //角度文件
    QFile angleFile;
    QTextStream angleOut;

    //MPU60501
    QFile mpu60501File;
    QTextStream mpu60501Out;

    //MPU60502
    QFile mpu60502File;
    QTextStream mpu60502Out;

    //HMC5883L1
    QFile hmc5883l1File;
    QTextStream hmc5883l1Out;

    //HMC5883L2
    QFile hmc5883l2File;
    QTextStream hmc5883l2Out;

    //MS56111
    QFile ms56111File;
    QTextStream ms56111Out;

    //MS56112
    QFile ms56112File;
    QTextStream ms56112Out;

    //GPS
    QFile gpsFile;
    QTextStream gpsOut;

    void WriteMpu6050Data(Mpu6050DataTypedef * mpu6050Data1, Mpu6050DataTypedef * mpu6050Data2);
    void WriteHmc5883lData(Hmc5883lDataTypedef * hmc5883lData1, Hmc5883lDataTypedef * hmc5883lData2);
    void WriteMs5611Data(Ms5611DataTypedef * ms5611Data1, Ms5611DataTypedef * ms5611Data2);
    void WriteGpsData(GpsDataTypedef * gpsData);

    void WriteAngleData(AngleDataTypedef * angleData);
};

#endif // RECORD_H
