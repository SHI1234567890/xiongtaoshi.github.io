#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    SensorIndex = 0;
    NetworkDataRate = 0;

    hostPort = 55555;

    myTcpServer.listen(QHostAddress::Any, hostPort);
    QTcpServer::connect(&myTcpServer, &QTcpServer::newConnection, this, &MainWindow::TcpNewConnection);

    QFont labelFont;
    labelFont.setPointSize(30);    

    //初始化图表
    ui->customPlot->xAxis->setLabel("x");
    ui->customPlot->xAxis->setLabelFont(labelFont);
    ui->customPlot->yAxis->setLabel("y");
    ui->customPlot->yAxis->setLabelFont(labelFont);
    ui->customPlot->xAxis->setRange(0, MAX_X_VALUE);
    ui->customPlot->yAxis->setRange(-MIN_Y_VALUE, MIN_Y_VALUE);
    ui->customPlot->legend->setVisible(true);
    QFont legendFont;
    legendFont.setPointSize(10);
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->legend->setSelectedFont(legendFont);
    ui->customPlot->legend->setSelectableParts(QCPLegend::spItems);
    ui->customPlot->setInteractions(QCP::iRangeZoom);

    //初始化曲线
    xAngleGraph = ui->customPlot->addGraph();
    ui->customPlot->graph()->setName("xAngleGraph");
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsStepLeft);//lsLine
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDot);
    QPen xAngleGraphPen;
    xAngleGraphPen.setColor(QColor(255, 0, 0));
    xAngleGraphPen.setWidth(2);
    ui->customPlot->graph()->setPen(xAngleGraphPen);

    yAngleGraph = ui->customPlot->addGraph();
    ui->customPlot->graph()->setName("yAngleGraph");
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsStepLeft);//lsLine
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDot);
    QPen yAngleGraphPen;
    yAngleGraphPen.setColor(QColor(0, 255, 0));
    yAngleGraphPen.setWidth(2);
    ui->customPlot->graph()->setPen(yAngleGraphPen);

    zAngleGraph = ui->customPlot->addGraph();
    ui->customPlot->graph()->setName("zAngleGraph");
    ui->customPlot->graph()->setLineStyle(QCPGraph::lsStepLeft);//lsLine
    ui->customPlot->graph()->setScatterStyle(QCPScatterStyle::ssDot);
    QPen zAngleGraphPen;
    zAngleGraphPen.setColor(QColor(0, 0, 255));
    zAngleGraphPen.setWidth(2);
    ui->customPlot->graph()->setPen(zAngleGraphPen);

    QTimer::connect(&myOneSecondTimer, &QTimer::timeout, this, &MainWindow::OneSecondTimerRun);
    myOneSecondTimer.start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

HAL_StatusTypedef MainWindow::DecodeData(QByteArray data)
{
    uint8_t * NetBuff = (uint8_t *)data.data();

    if((NetBuff[0] == 0X88) &&
            (NetBuff[1] == 0X88) &&
            (NetBuff[28] == 0X88) &&
            (NetBuff[29] == 0X88))
    {
        F2U32 temp;

        temp.u32Data = (((uint32_t)NetBuff[2] << 24)|((uint32_t)NetBuff[3] << 16)|
                        ((uint32_t)NetBuff[4] << 8)|((uint32_t)NetBuff[5]));
        angleData.AngleX = temp.fData;

        temp.u32Data = (((uint32_t)NetBuff[6] << 24)|((uint32_t)NetBuff[7] << 16)|
                        ((uint32_t)NetBuff[8] << 8)|((uint32_t)NetBuff[9]));
        angleData.AngleY = temp.fData;

        temp.u32Data = (((uint32_t)NetBuff[10] << 24)|((uint32_t)NetBuff[11] << 16)|
                        ((uint32_t)NetBuff[12] << 8)|((uint32_t)NetBuff[13]));
        angleData.AngleZ = temp.fData;

        //qDebug()<<"DecodeData Succeed  ";
        return HAL_OK;
    }else
    {
        //qDebug()<<"DecodeData Failed";
        return HAL_ERROR;
    }
}

void MainWindow::PlotData()
{
    xAngleGraph->addData(SensorIndex, angleData.AngleX);
    yAngleGraph->addData(SensorIndex, angleData.AngleY);
    zAngleGraph->addData(SensorIndex, angleData.AngleZ);

//    float angleMaxVal = 0;
//    float angleMinVal = 0;
//    if(angleData.AngleX > angleMaxVal)
//    {
//        angleMaxVal = angleData.AngleX;
//    }else if(angleData.AngleX < angleMinVal)
//    {
//        angleMinVal = angleData.AngleX;
//    }

//    if(angleData.AngleY > angleMaxVal)
//    {
//        angleMaxVal = angleData.AngleY;
//    }else if(angleData.AngleY < angleMinVal)
//    {
//        angleMinVal = angleData.AngleY;
//    }

//    if(angleData.AngleZ > angleMaxVal)
//    {
//        angleMaxVal = angleData.AngleZ;
//    }else if(angleData.AngleZ < angleMinVal)
//    {
//        angleMinVal = angleData.AngleZ;
//    }

//    angleMaxVal += 1;
//    angleMinVal -= 1;

//    if(angleMaxVal < MIN_Y_VALUE)
//    {
//        angleMaxVal = MIN_Y_VALUE;
//    }

//    if(angleMinVal > -MIN_Y_VALUE)
//    {
//        angleMinVal = -MIN_Y_VALUE;
//    }

//    if(SensorIndex > MAX_X_VALUE)
//    {
//        ui->customPlot->xAxis->setRange(SensorIndex-MAX_X_VALUE, SensorIndex);
//    }else
//    {
//        ui->customPlot->xAxis->setRange(0, MAX_X_VALUE);
//    }

//    ui->customPlot->yAxis->setRange(angleMaxVal, angleMinVal);

    ui->customPlot->rescaleAxes();

    if(SensorIndex > MAX_X_VALUE)
    {
        ui->customPlot->xAxis->setRange(SensorIndex-MAX_X_VALUE, SensorIndex);
    }else
    {
        ui->customPlot->xAxis->setRange(0, MAX_X_VALUE);
    }

    SensorIndex++;

    ui->customPlot->replot();
}

//新的TCP开始建立连接
void MainWindow::TcpNewConnection()
{
    qDebug()<<"TcpNewConnection";
    myTcpSocket = myTcpServer.nextPendingConnection();
    myTcpSocket->setReadBufferSize(NETWORK_BUFF_LENGTH);
    QTcpSocket::connect(myTcpSocket, &QTcpSocket::readyRead, this, &MainWindow::TcpReadyRead);
    QTcpSocket::connect(myTcpSocket, &QTcpSocket::disconnected, this, &MainWindow::TcpDisconnected);
}

void MainWindow::TcpReadyRead()
{
    //qDebug()<<"TcpReadyRead";
    //qDebug()<<"TcpReadyRead " << myTcpSocket->bytesAvailable();
    if(myTcpSocket->bytesAvailable() >= NETWORK_BUFF_LENGTH)
    {
        NetworkDataRate++;
        if(DecodeData(myTcpSocket->readAll()) == HAL_OK)
        {
            PlotData();
        }
    }
}

void MainWindow::TcpDisconnected()
{
    qDebug()<<"TcpDisconnected";
}

void MainWindow::OneSecondTimerRun()
{
    qDebug()<<"NetworkDataRate : " << NetworkDataRate;
    NetworkDataRate = 0;
}

void MainWindow::on_cleanButton_clicked()
{
    QVector<double> x(1), y(1);
    x[0] = 0;
    y[0] = 0;

    xAngleGraph->setData(x, y);
    yAngleGraph->setData(x, y);
    zAngleGraph->setData(x, y);
    SensorIndex = 0;
    ui->customPlot->replot();
}
