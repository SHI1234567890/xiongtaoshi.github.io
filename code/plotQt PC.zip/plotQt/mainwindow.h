#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <qcustomplot.h>
#include <QTcpServer>
#include <QTcpSocket>
#include <QDebug>
#include <Typedef/typedef.h>
#include <Thread/mythread.h>
#include <QTimer>

#define NETWORK_BUFF_LENGTH 30
#define MAX_X_VALUE         100
#define MIN_Y_VALUE         5

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    HAL_StatusTypedef DecodeData(QByteArray data);
    void PlotData(void);

public slots:
    void TcpNewConnection(void);
    void TcpReadyRead(void);
    void TcpDisconnected(void);
    void OneSecondTimerRun(void);

private slots:
    void on_cleanButton_clicked();

private:
    Ui::MainWindow *ui;

    uint8_t NetworkBuff[NETWORK_BUFF_LENGTH];

    quint16 hostPort;

    QTcpServer myTcpServer;

    QTcpSocket * myTcpSocket;

    //传感器数据
    AngleDataTypedef angleData;

    uint32_t SensorIndex;

    QTimer myOneSecondTimer;

    //网络接受数据频率
    uint32_t NetworkDataRate;

    //X角度
    QCPGraph * xAngleGraph;
    //Y角度
    QCPGraph * yAngleGraph;
    //Z角度
    QCPGraph * zAngleGraph;
};

#endif // MAINWINDOW_H
