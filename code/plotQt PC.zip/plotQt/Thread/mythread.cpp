
#include "Thread/mythread.h"

MYTHREAD::MYTHREAD(QObject *parent) : QThread(parent)
{
}

void MYTHREAD::run()
{
    emit MyThreadRun();
}

