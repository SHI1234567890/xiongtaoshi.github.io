#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>

class MYTHREAD : public QThread
{
    Q_OBJECT
public:
    MYTHREAD(QObject *parent = 0);

protected:
    void run();
signals:
    void MyThreadRun();
};

#endif // MYTHREAD_H
