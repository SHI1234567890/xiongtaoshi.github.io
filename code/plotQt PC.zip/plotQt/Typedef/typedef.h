#ifndef TYPEDEF
#define TYPEDEF

typedef signed char         int8_t;
typedef signed short int    int16_t;
typedef signed int          int32_t;

typedef unsigned char       uint8_t;
typedef unsigned short int  uint16_t;
typedef unsigned int        uint32_t;

typedef enum
{
    HAL_OK = 0,
    HAL_ERROR = 1,
}HAL_StatusTypedef;

typedef struct
{
    int16_t Mpu6050AccX;
    int16_t Mpu6050AccY;
    int16_t Mpu6050AccZ;
    int16_t Mpu6050Temp;
    int16_t Mpu6050GyroX;
    int16_t Mpu6050GyroY;
    int16_t Mpu6050GyroZ;
}Mpu6050DataTypedef;

typedef struct
{
    int16_t Hmc5883lMagX;
    int16_t Hmc5883lMagY;
    int16_t Hmc5883lMagZ;
}Hmc5883lDataTypedef;

typedef struct
{
    int32_t Ms5611P;
}Ms5611DataTypedef;

typedef struct
{
    uint8_t IsFixOk;
    int32_t longitude;
    int32_t latitude;
    int32_t height;
    uint32_t hAcc;
    uint32_t vAcc;
    int32_t velN;
    int32_t velE;
    int32_t velD;
}GpsDataTypedef;

typedef struct
{
    float AngleX;
    float AngleY;
    float AngleZ;
}AngleDataTypedef;

typedef union
{
    float fData;
    uint32_t u32Data;
}F2U32;

#endif // TYPEDEF

