
#缩放矩阵
def scalar_matrix(a, scalar):
    for i in range(len(a)):
        for j in range(len(a[0])):
            a[i][j] *= scalar
    return a

#矢量相乘
def multiply_vectors(v1, v2):
    new_vector = []
    for i in range(len(v1)):
        new_vector.append(v1[i] * v2[i])
    return new_vector

#矩阵相乘
def multiply_matrices(a, b):
    new_matrix = [[0 for j in range(len(b[0]))] for i in range(len(a))]
    b = transpose_matrix(b)
    for i in range(len(a)):
        for j in range(len(b)):
            new_matrix[i][j] = sum(multiply_vectors(a[i], b[j]))
    return new_matrix

#矩阵转置
def transpose_matrix(a):
    new_matrix = []
    for j in range(len(a[0])):
        vector = []
        for i in range(len(a)):
            vector.append(a[i][j])
        new_matrix.append(vector)
    return new_matrix

#矩阵秩
def calculate_determinent(a):
    if len(a) == 1:
        return a[0][0]
    if len(a) == 2:
        return a[0][0] * a[1][1] - a[0][1] * a[1][0]
    else:
        i = 0
        d = 0
        for j in range(len(a[i])):
            d += (-1) ** (i + 1 + j + 1) * a[i][j] * calculate_determinent(minor_matrix(a, i, j))
        return d

#翻转矩阵
def minor_matrix(a, k, l):
    m = []
    for i in range(len(a)):
        if i != k:
            v = []
            for j in range(len(a[0])):
                if j != l:
                    v.append(a[i][j])
            m.append(v)
    return m

#矩阵余子式
def cofactor_matrix(a):
    m = [[0 for _ in range(len(a[0]))] for _ in range(len(a))]
    for i in range(len(a)):
        for j in range(len(a[0])):
            m[i][j] = ((-1) ** (i + 1 + j + 1)) * calculate_determinent(minor_matrix(a, i, j))
    return m

#矩阵逆
def calculate_inverse(a):
    return scalar_matrix(transpose_matrix(cofactor_matrix(a)), 1 / calculate_determinent(a))




