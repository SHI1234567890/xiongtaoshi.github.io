
import sys

#定义一个用来记录每一天调度的信息的类
class Output():

    def add_service(self, service_type_num):
        #开始累加
        temp_str = '(purchase, ' + str(len(service_type_num)) + ')'
        print(temp_str)
        for service_type in service_type_num.keys():
            temp_str = '(' + service_type + ', ' + str(service_type_num[service_type]) + ')'
            print(temp_str)

    def add_migration(self, machine_migration_list):
        temp_str = '(migration, ' + str(len(machine_migration_list)) + ')'
        print(temp_str)
        for migration_data in machine_migration_list:
            machine_id = migration_data[0].machine_id
            service_id = migration_data[2].service_id
            node = migration_data[3]
            temp_str = '(' + str(machine_id) + ', ' + str(service_id) + ')' if node == 'N' else \
                '(' + str(machine_id) + ', ' + str(service_id) + ', ' + node + ')'
            # if node == 'N': print('xxxyyy')
            # else: print('yyyxxx')
            print(temp_str)


    def add_machine(self, operate_data_day_id_all, machine_his_dict):
        for machine_id in operate_data_day_id_all:
            service_data, node = machine_his_dict[machine_id].service_data, machine_his_dict[machine_id].node
            temp_str = '(' + str(service_data.service_id) + ')' if node == 'N' \
                else '(' + str(service_data.service_id) + ', ' + node + ')'
            print(temp_str)
        #清空输出缓冲区
        sys.stdout.flush()
