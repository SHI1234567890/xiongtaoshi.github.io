
from collections import OrderedDict

def draw_bar(labels, quants, write_dir):
    import numpy as np
    import matplotlib.pyplot as plt
    width = 0.4
    ind = np.arange(len(labels))
    # make a square figure
    fig = plt.figure(figsize=(19.20, 10.80))
    ax = fig.add_subplot(111)
    # Bar Plot
    ax.bar(ind, quants, width, color='green')
    # Set the ticks on x-axis
    ax.set_xticks(ind)
    ax.set_xticklabels(labels,fontsize=5)
    # title
    ax.set_title('type_num = {} total_num = {}'.format(len(labels), np.sum(quants)))
    plt.grid()
    plt.savefig(write_dir)
    plt.show()

#定义一个用于计算价钱的类
class Money():
    def __init__(self, constant):
        # 所有的常数
        self.constant = constant

        self.hardware_cost_total = 0
        self.power_cost_total = 0
        self.cost_total = 0
        #A.cpu_num,A.mem_num,B.cpu_num,B.mem_num,service_num
        self.percent = [[],[],[],[],[]]
        #总数量，开机数量，虚拟机数量
        self.service_num = [[],[],[]]
        #用于统计开机时长
        #用于统计服务器的开机天时
        self.service_type_on_num = OrderedDict()
        #用于统计虚拟机的开机天时
        self.machine_type_num = OrderedDict()
        #用于统计虚拟机添加的次数
        self.machine_add_type_num = OrderedDict()
        #统计只放一个虚拟机的服务器个数
        self.machine_one_service_num = []

    # 统计每一类服务器的个数
    def analysis_service(self, service_his_dict):

        self.machine_one_service_num.append(0)

        for service_data in service_his_dict[0]:
            if len(service_data.machine_list) == 1: self.machine_one_service_num[-1] += 1

        for service_data in service_his_dict[1]:
            if len(service_data.machine_list) == 1: self.machine_one_service_num[-1] += 1

        #统计
        for service_data in service_his_dict[0]:
            if service_data.type not in self.service_type_on_num.keys():
                self.service_type_on_num[service_data.type] = 0
            self.service_type_on_num[service_data.type] += 1
        for service_data in service_his_dict[1]:
            if service_data.type not in self.service_type_on_num.keys():
                self.service_type_on_num[service_data.type] = 0
            self.service_type_on_num[service_data.type] += 1

    #统计虚拟机的开机天时
    def analysis_machine(self, machine_his_dict):

        for machine_data in machine_his_dict.values():
            if machine_data.type not in self.machine_type_num.keys():
                self.machine_type_num[machine_data.type] = 0
            self.machine_type_num[machine_data.type] += 1

    #统计虚拟机添加的次数
    def analysis_machine_add(self, operate_data_day):
        for operate_data in operate_data_day:
            if operate_data[0] == 'add':
                if operate_data[1] not in self.machine_add_type_num.keys():
                    self.machine_add_type_num[operate_data[1]] = 0
                self.machine_add_type_num[operate_data[1]] += 1


    def plot_service(self, service_his_dict, service_type_data, write_dir):
        import math
        # 排序，首先创建一个列表
        service_type_num_on_list = []
        for key in self.service_type_on_num.keys():
            service_type_num_on_list.append([key, self.service_type_on_num[key]])
        # 对列表排序
        service_type_num_on_list.sort(key=lambda data: data[1], reverse=True)
        #
        service_types = []
        service_on_nums = []
        for data in service_type_num_on_list:
            service_types.append(data[0])
            service_on_nums.append(data[1])
        # 画图
        draw_bar(service_types, service_on_nums, write_dir + 'service_type_on_num.pdf')
        #统计服务器类型和数量
        service_type_num = OrderedDict()
        #对所有的虚拟机循环
        for service_data in service_his_dict[0]:
            if service_data.type not in service_type_num.keys():
                service_type_num[service_data.type] = [0.0, 0.0, 0.0]
            ratio_cpu = 1 - ((service_data.A_cpu_num_now + service_data.B_cpu_num_now) / service_data.cpu_num_total)
            ratio_mem = 1 - ((service_data.A_mem_num_now + service_data.B_mem_num_now) / service_data.mem_num_total)
            service_type_num[service_data.type][0] += 1
            service_type_num[service_data.type][1] += ratio_cpu
            service_type_num[service_data.type][2] += ratio_mem
        for service_data in service_his_dict[1]:
            if service_data.type not in service_type_num.keys():
                service_type_num[service_data.type] = [0.0, 0.0, 0.0]
            ratio_cpu = 1 - ((service_data.A_cpu_num_now + service_data.B_cpu_num_now) / service_data.cpu_num_total)
            ratio_mem = 1 - ((service_data.A_mem_num_now + service_data.B_mem_num_now) / service_data.mem_num_total)
            service_type_num[service_data.type][0] += 1
            service_type_num[service_data.type][1] += ratio_cpu
            service_type_num[service_data.type][2] += ratio_mem
        #计算利用率
        for key in service_type_num.keys():
            service_type_num[key][1] /= service_type_num[key][0]
            service_type_num[key][2] /= service_type_num[key][0]
        # 排序，首先创建一个列表
        service_type_num_list = []
        for key in service_type_num.keys():
            service_type_num_list.append([key, service_type_num[key][0]])
        # 对列表排序
        service_type_num_list.sort(key=lambda data: data[1], reverse=True)
        #
        service_types = []
        service_nums = []
        for data in service_type_num_list:
            service_types.append(data[0])
            service_nums.append(data[1])
        # 画图
        draw_bar(service_types, service_nums, write_dir + 'service_type_num.pdf')
        # 排序，首先创建一个列表
        service_type_ratio_list = []
        for key in service_type_num.keys():
            service_type_ratio_list.append([key, service_type_num[key][1], service_type_num[key][2]])
        # 对列表排序
        service_type_ratio_list.sort(key=lambda data: data[1], reverse=True)
        #
        service_types = []
        service_cpu_ratios = []
        service_mem_ratios = []
        for data in service_type_ratio_list:
            service_types.append(data[0])
            service_cpu_ratios.append(data[1])
            service_mem_ratios.append(data[2])
        # 画图
        draw_bar(service_types, service_cpu_ratios, write_dir + 'service_type_cpu_ratio.pdf')
        draw_bar(service_types, service_mem_ratios, write_dir + 'service_type_mem_ratio.pdf')
        # 画全部服务器的图cpu/mem
        cpu_nums = []
        mem_nums = []
        ratios = []
        for service_type in service_types:
            cpu_nums.append(service_type_data[service_type].cpu_num_total)
            mem_nums.append(service_type_data[service_type].mem_num_total)
            ratios.append(math.log(service_type_data[service_type].cpu_num_total / service_type_data[service_type].mem_num_total))
        # 画图
        draw_bar(service_types, ratios, write_dir + 'service_cpu_mem_ratio.pdf')
        #打印对应的服务器数据，用于分析
        print('----------')
        for service_type in service_types:
            print('service_cpu_ratios = ', service_type_num[service_type][1])
            print('service_mem_ratios = ', service_type_num[service_type][2])
            print('service_nums = ', service_type_num[service_type][0])
            print('service_on_nums = ', self.service_type_on_num[service_type])
            print('hardware_cost = ', service_type_num[service_type][0] * service_type_data[service_type].hardware_cost)
            print('day_cost = ', self.service_type_on_num[service_type] * service_type_data[service_type].day_cost)
            print(service_type_data[service_type])
        print('----------')


    def plot_machine(self, machine_type_data, write_dir):
        import math
        # 排序，首先创建一个列表
        machine_type_num_list = []
        for key in self.machine_type_num.keys():
            machine_type_num_list.append([key, self.machine_type_num[key]])
        # 对列表排序
        machine_type_num_list = sorted(machine_type_num_list, key=lambda data: data[1], reverse=True)
        #
        machine_types = []
        machine_nums = []
        for machine_type_num in machine_type_num_list:
            machine_types.append(machine_type_num[0])
            machine_nums.append(machine_type_num[1])
        # 画图
        draw_bar(machine_types, machine_nums, write_dir + 'machine_type_num.pdf')
        # 画全部服务器的图cpu/mem
        cpu_nums = []
        mem_nums = []
        ratios = []
        for service_type in machine_types:
            cpu_nums.append(machine_type_data[service_type].cpu_num)
            mem_nums.append(machine_type_data[service_type].mem_num)
            ratios.append(math.log(machine_type_data[service_type].cpu_num / machine_type_data[service_type].mem_num))
        # 画图
        draw_bar(machine_types, ratios, write_dir + 'machine_cpu_mem_ratio.pdf')

    def plot_machine_add(self, write_dir):
        # 绘制虚拟机的添加次数
        # 排序，首先创建一个列表
        machine_add_type_num_list = []
        for key in self.machine_add_type_num.keys():
            machine_add_type_num_list.append([key, self.machine_add_type_num[key]])
        # 对列表排序
        machine_add_type_num_list = sorted(machine_add_type_num_list, key=lambda data: data[1], reverse=True)
        #
        machine_types = []
        machine_nums = []
        for machine_add_type_num in machine_add_type_num_list:
            machine_types.append(machine_add_type_num[0])
            machine_nums.append(machine_add_type_num[1])
        # 画图
        draw_bar(machine_types, machine_nums, write_dir + 'machine_add_type_num.pdf')

    # 每天计算一次
    def calc(self, service_his_dict, machine_his_dict):
        a_cpu_num_total = 0.0001
        b_cpu_num_total = 0.0001
        a_mem_num_total = 0.0001
        b_mem_num_total = 0.0001
        a_cpu_num_used = 0
        b_cpu_num_used = 0
        a_mem_num_used = 0
        b_mem_num_used = 0
        #
        service_on_num = 0
        # 循环所有的service，并判断是否开机
        hardware_cost_total = 0
        power_cost_day = 0
        #循环单节点和双节点两个节点的服务器信息
        #循环空闲的服务器，计算硬件成本
        for service_data in service_his_dict[-1]:
            hardware_cost_total += service_data.hardware_cost
        #循环单节点
        for service_data in service_his_dict[0]:
            hardware_cost_total += service_data.hardware_cost
            # 服务器在开机状态
            if (service_data.A_cpu_num_now != service_data.A_cpu_num_total) or \
                (service_data.B_cpu_num_now != service_data.B_cpu_num_total) or \
                (service_data.A_mem_num_now != service_data.A_mem_num_total) or \
                (service_data.B_mem_num_now != service_data.B_mem_num_total):
                # 计算每天损耗
                power_cost_day += service_data.day_cost
                service_on_num += 1
                # 总CPU和总MEM，统计数据，不开机也统计
                a_cpu_num_total += service_data.A_cpu_num_total
                b_cpu_num_total += service_data.B_cpu_num_total
                a_mem_num_total += service_data.A_mem_num_total
                b_mem_num_total += service_data.B_mem_num_total
                a_cpu_num_used += (service_data.A_cpu_num_total - service_data.A_cpu_num_now)
                b_cpu_num_used += (service_data.B_cpu_num_total - service_data.B_cpu_num_now)
                a_mem_num_used += (service_data.A_mem_num_total - service_data.A_mem_num_now)
                b_mem_num_used += (service_data.B_mem_num_total - service_data.B_mem_num_now)
        # 循环双节点
        for service_data in service_his_dict[1]:
            hardware_cost_total += service_data.hardware_cost
            # 服务器在开机状态
            if (service_data.A_cpu_num_now != service_data.A_cpu_num_total) or \
                    (service_data.B_cpu_num_now != service_data.B_cpu_num_total) or \
                    (service_data.A_mem_num_now != service_data.A_mem_num_total) or \
                    (service_data.B_mem_num_now != service_data.B_mem_num_total):
                # 计算每天损耗
                power_cost_day += service_data.day_cost
                service_on_num += 1
                # 总CPU和总MEM，统计数据
                a_cpu_num_total += service_data.A_cpu_num_total
                b_cpu_num_total += service_data.B_cpu_num_total
                a_mem_num_total += service_data.A_mem_num_total
                b_mem_num_total += service_data.B_mem_num_total
                a_cpu_num_used += (service_data.A_cpu_num_total - service_data.A_cpu_num_now)
                b_cpu_num_used += (service_data.B_cpu_num_total - service_data.B_cpu_num_now)
                a_mem_num_used += (service_data.A_mem_num_total - service_data.A_mem_num_now)
                b_mem_num_used += (service_data.B_mem_num_total - service_data.B_mem_num_now)

        # 累计费用
        self.hardware_cost_total = hardware_cost_total
        self.power_cost_total += power_cost_day
        self.cost_total = self.hardware_cost_total + self.power_cost_total
        # 使用占比
        self.percent[0].append(a_cpu_num_used / a_cpu_num_total)
        self.percent[1].append(a_mem_num_used / a_mem_num_total)
        self.percent[2].append(b_cpu_num_used / b_cpu_num_total)
        self.percent[3].append(b_mem_num_used / b_mem_num_total)
        self.percent[4].append(service_on_num / (len(service_his_dict[0]) + len(service_his_dict[1])))
        # 总数量
        self.service_num[0].append((len(service_his_dict[0]) + len(service_his_dict[1])))
        self.service_num[1].append(service_on_num)
        self.service_num[2].append(len(machine_his_dict))

    def plot(self, service_his_dict, machine_his_dict, migration_num_max, migration_num_total, write_dir):

        import matplotlib.pyplot as plt

        show_str = 'services num = ' + str((len(service_his_dict[0]) + len(service_his_dict[1]))) + \
                   ' machine num = ' + str(len(machine_his_dict)) + \
                   ' hardware_cost_total = ' + str(self.hardware_cost_total) + \
                   ' power_cost_total = ' + str(self.power_cost_total) + \
                   ' cost_total = ' + str(self.cost_total) + \
                   ' migration_num_max = ' + str(migration_num_max) + \
                   ' migration_num_total = ' + str(migration_num_total)

        # 打印最后的输出
        print(show_str)

        plt.figure(figsize=(19.20, 10.80))
        plt.plot(self.percent[0], '-*', label='A.cpu')
        plt.plot(self.percent[1], '-*', label='A.mem')
        plt.plot(self.percent[2], '-*', label='B.cpu')
        plt.plot(self.percent[3], '-*', label='B.mem')
        plt.plot(self.percent[4], '-*', label='Service')
        plt.grid()
        plt.legend()
        plt.xlabel('day')
        plt.ylabel('percent')
        plt.title(show_str)
        plt.savefig(write_dir+'result_percent_of_cpu_and_mem.pdf')
        plt.show()
        plt.figure(figsize=(19.20, 10.80))
        plt.plot(self.service_num[0], '-*', label='service_num')
        plt.plot(self.service_num[1], '-*', label='service_on_num')
        plt.plot(self.service_num[2], '-*', label='machine_num')
        plt.grid()
        plt.legend()
        plt.xlabel('day')
        plt.ylabel('number')
        plt.title(show_str)
        plt.savefig(write_dir + 'result_number_of_service_and_machine.pdf')
        plt.show()
        plt.figure(figsize=(19.20, 10.80))
        plt.plot(self.machine_one_service_num, '-*', label='machine_one_service_num')
        plt.grid()
        plt.legend()
        plt.xlabel('day')
        plt.ylabel('number')
        plt.title(show_str)
        plt.savefig(write_dir + 'result_machine_one_service_num.pdf')
        plt.show()

