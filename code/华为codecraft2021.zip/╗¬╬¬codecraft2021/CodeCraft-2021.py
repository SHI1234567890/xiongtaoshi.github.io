
from Constant import Constant, ServiceTypeData, MachineTypeData, MachineData
from Output import Output
from Money import Money
from Service_Machine import Service_Machine
from DataAnalysis import DataAnalysis
from Parameter import operate_data_day_del_min_len

#是否读写文件,调试阶段True,运行阶段False
is_redirect_to_file = True
if is_redirect_to_file:
    import sys
    import time
    from tqdm import tqdm
    test_file = 2
    if test_file == 1:
        # 本地文件名
        read_file_name = 'training-data/training-1.txt'
        # read_file_name = 'training-data/training-1-old.txt'
        write_dir = 'training-data/result1/'
        write_file_name = write_dir + 'training_output.txt'
    else:
        # 本地文件名
        read_file_name = 'training-data/training-2.txt'
        # read_file_name = 'training-data/training-2-old.txt'
        write_dir = 'training-data/result2/'
        write_file_name = write_dir + 'training_output.txt'
    sys.stdin = open(read_file_name, 'r')  # 此语句实现了将标准输入重定向
    sys.stdout = open(write_file_name, 'w')  # 此语句实现了将标准输出重定向

def main():
    #开始时间
    if is_redirect_to_file: start_time = time.time()

    #定义常数
    constant = Constant()
    # 1.首先读取总共有多少种可供购买的服务器
    constant.service_type_num = int(input().strip())

    #统计所有服务器的cpu和mem的平均值
    service_cpu_num_mean = 0
    service_mem_num_mean = 0
    for i in range(constant.service_type_num):
        #(host0Y6DP, 300, 830, 141730, 176)
        data = input().strip()[1:-1].split(',')
        constant.service_type_data[data[0]] = \
            ServiceTypeData(data[0], int(data[1]), int(data[2]), int(data[3]), int(data[4]))
        #累计
        service_cpu_num_mean += int(data[1])
        service_mem_num_mean += int(data[2])
    #计算平均值
    service_cpu_num_mean /= constant.service_type_num
    service_mem_num_mean /= constant.service_type_num
    #给服务器的平均值赋值
    for service_type_data in constant.service_type_data.values():
        service_type_data.cpu_num_mean = service_cpu_num_mean
        service_type_data.mem_num_mean = service_mem_num_mean


    # 3.读取虚拟机类型数量
    constant.machine_type_num = int(input().strip())
    for i in range(constant.machine_type_num):
        #(vmU6H3K, 50, 10, 0)
        data = input().strip()[1:-1].split(',')
        constant.machine_type_data[data[0]] = \
            MachineTypeData(data[0], int(data[1]), int(data[2]), int(data[3]))

    # 通过day_cost/hardware_cost聚类，对每一类服务器分别贴标签
    constant.service_classification()

    #分析画图
    # dataAnalysis = DataAnalysis()
    # dataAnalysis.analysis_service1(constant.service_type_data)
    # dataAnalysis.analysis_service(constant.service_type_data)
    # dataAnalysis.analysis_machine(constant.machine_type_data)

    # 回归分析
    constant.calc_linear_regression()
    constant.calc_constant()

    # 5.读取总共多少天
    temp = [int(data) for data in input().strip().split(' ')]
    if len(temp) == 2: constant.total_day, constant.forward_look_k = temp
    else: constant.total_day = temp[0]

    # 输出信息
    output = Output()
    # 计算价钱
    money = Money(constant)
    #
    #定义实例
    service_machine = Service_Machine(constant, money if is_redirect_to_file else None, output)

    # 分成若干个k天读取数据，暂时修改
    constant.forward_look_k = 1
    #
    day_index = 0
    if is_redirect_to_file: pbar = tqdm(total=constant.total_day)
    if is_redirect_to_file: pbar.update(1)
    while day_index < constant.total_day:
        # 开始读取K天数据
        operate_data_day_k = []
        operate_data_day_id_all_k = []
        for index in range(day_index, min(day_index + constant.forward_look_k, constant.total_day), 1):
            # 7.读取一天总的操作次数
            day_operate_num = int(input().strip())
            # 整个一天所有的操作数据
            operate_data_day = []
            operate_data_day_id_all = []
            operate_data_day_add_single = []
            operate_data_day_add_dual = []
            operate_data_day_del = []
            # 8.读取一天的所有操作
            for operate_index in range(day_operate_num):
                # 读取一条操作数据
                operate_data = input().strip()[1:-1].split(',')
                # [add,machine_type,machine_id]/[del,machine_id]
                if operate_data[0] == 'add':
                    machine_type = operate_data[1].strip()
                    machine_id = int(operate_data[2])
                    machine_type_data = constant.machine_type_data[machine_type]
                    machine_data = MachineData(machine_type_data, machine_id, None, None)  # 暂时还没有分配节点和服务器
                    # 将id的顺序保存起来，用于后续输出信息使用
                    operate_data_day_id_all.append(machine_id)
                    if machine_type_data.dual_model == 0:
                        operate_data_day_add_single.append(machine_data)
                    else:
                        operate_data_day_add_dual.append(machine_data)
                else:
                    machine_id = int(operate_data[1])
                    operate_data_day_del.append(machine_id)
                    # 如果del序列超过设定长度，这个参数
                    if len(operate_data_day_del) >= operate_data_day_del_min_len:  # 1
                        operate_data_day.append([operate_data_day_add_single, operate_data_day_add_dual, operate_data_day_del])
                        # 清空
                        operate_data_day_add_single = []
                        operate_data_day_add_dual = []
                        operate_data_day_del = []
            # 如果有剩余的没有加进去，那么加进去
            if len(operate_data_day_add_single) != 0 or len(operate_data_day_add_dual) != 0 or len(operate_data_day_del) != 0:
                operate_data_day.append([operate_data_day_add_single, operate_data_day_add_dual, operate_data_day_del])
            # 存储一天的数据
            operate_data_day_k.append(operate_data_day)
            operate_data_day_id_all_k.append(operate_data_day_id_all)
        # 更新天数
        day_index += min(day_index + constant.forward_look_k, constant.total_day) - day_index
        # 开始输出K天的决策信息
        service_machine.update_day_k(operate_data_day_k, operate_data_day_id_all_k)
        # 更新进度条
        if is_redirect_to_file: pbar.update(min(day_index + constant.forward_look_k, constant.total_day) - day_index)
    # 关闭进度条
    if is_redirect_to_file: pbar.close()

    #画图输出
    # if is_redirect_to_file: money.plot_service(service_machine.service_his_dict, constant.service_type_data, write_dir)
    # if is_redirect_to_file: money.plot_machine(constant.machine_type_data, write_dir)
    # if is_redirect_to_file: money.plot_machine_add(write_dir)
    if is_redirect_to_file: money.plot(service_machine.service_his_dict, service_machine.machine_his_dict,
                                       service_machine.migration_num_max, service_machine.migration_num_total, write_dir)

    if is_redirect_to_file: end_time = time.time()
    #打印最大迁移数量
    if is_redirect_to_file: print('migration_num_max = ', service_machine.migration_num_max)
    if is_redirect_to_file: print('migration_num_total = ', service_machine.migration_num_total)
    if is_redirect_to_file: print('end_time - start_time = ', end_time - start_time)
    if is_redirect_to_file:
        show_str = 'services num = ' + str((len(service_machine.service_his_dict[0]) + len(service_machine.service_his_dict[1]))) + \
                   ' machine num = ' + str(len(service_machine.machine_his_dict)) + \
                   ' hardware_cost_total = ' + str(money.hardware_cost_total) + \
                   ' power_cost_total = ' + str(money.power_cost_total) + \
                   ' cost_total = ' + str(money.cost_total)
        raise ValueError(show_str)


if __name__ == "__main__":
    main()



