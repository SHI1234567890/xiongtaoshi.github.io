
from collections import OrderedDict
from Constant import ServiceData, MachineData
from Knapsack import Knapsack_single, Knapsack_dual
from Utility import assign_machine_to_service, \
    del_machine, \
    add_old_service, \
    add_machine, \
    assign_service_id, \
    do_migration, \
    update_migration, \
    update_migration_another, \
    update_migration_fine
from Parameter import machine_price_b, machine_add_list_max_len

#定义管理服务器和虚拟机的类
class Service_Machine():
    def __init__(self, constant, money, output):
        #所有的常数
        self.constant = constant
        self.money = money
        self.output = output

        # 定义历史的，实例化的，服务器，
        #0,single/1,dual:[单节点部署服务器地址列表，双节点部署服务器地址列表]
        self.service_his_dict = OrderedDict()
        self.service_his_dict[-1] = []#用于存放暂时没有任何虚拟机的服务器
        self.service_his_dict[0] = []#single model
        self.service_his_dict[1] = []#dual model

        # 记录是什么虚拟机导致购买的服务器,key=服务器,value=[虚拟机]
        self.service_buy_machine_cause = OrderedDict()

        # 定义现阶段，实例化的，虚拟机，当删除的时候，还原服务器数据
        #id:对象地址
        self.machine_his_dict = OrderedDict()

        #最多向前看多少个虚拟机
        self.machine_forward_look = 100000
        # 最大迁移数量 和 总迁移数量
        self.migration_num_max = 0
        self.migration_num_total = 0

    # 计算一个连续add的序列，应该如何调度,包含了单双节点，返回没有成功放置的虚拟机
    def update_add_continue_single(self, machine_add_list, service_his_dict_new_list):
        # 按照价格排序，进行降序排序，也就是先放大的虚拟机 # [虚拟机，虚拟机价格]
        # 这块需要创建一个新的备份，sorted正好是创建备份，这个备份中存储着虚拟机的顺序
        # 对单双节点分别排序
        # hardware_cost这块是根据服务器的系数计算出来的，
        machine_add_list.sort(key=lambda data: data.hardware_cost, reverse=True)

        # 记录需要删除的虚拟机索引值，分别代表单节点和双节点
        machine_add_list_sorted_dels = []
        # 使用0-1背包问题的贪婪算法，分配虚拟机
        # 1.遍历单节点虚拟机，尝试将虚拟机放到服务器中
        for index, machine_data in enumerate(machine_add_list):
            # 尝试将虚拟机放到已有的服务器中
            if add_old_service(self.service_his_dict, self.machine_his_dict, machine_data):
                # 并且记录这个虚拟机信息需要删除
                machine_add_list_sorted_dels.append(index)
        # 删除单节点数据，这块删除的时候，需要按照从后向前删除
        for index in range(len(machine_add_list_sorted_dels) - 1, -1, -1):
            del_index = machine_add_list_sorted_dels[index]
            del machine_add_list[del_index]

        # 3.while直到单节点虚拟机列表为空
        # 开始收集数据，统计虚拟机的cpu/mem和价值
        machine_cpu_cap = []
        machine_mem_cap = []
        for machine_data in machine_add_list:
            # 统计数据
            machine_cpu_cap.append(machine_data.cpu_num)
            machine_mem_cap.append(machine_data.mem_num)
        # 首先循环，尝试放到空闲的服务器中
        while len(self.service_his_dict[-1]) > 0 or len(machine_add_list) > 0:
            # 对每种类型的服务器分别做背包问题，返回的是，服务器的价值/服务器中放入的虚拟机价值，价值越小越好
            # 记录服务器的价值和虚拟机的价值比
            values_ratio = []
            # 对所有的空闲服务器做循环
            for service_index, service_data in enumerate(self.service_his_dict[-1]):
                # 返回在这种服务器中，最多可以装下多少价值的虚拟机，里面不会修改列表的信息，所以不需要拷贝
                value_cpu, value_mem, solutions = Knapsack_single(machine_cpu_cap,
                                                                  machine_mem_cap,
                                                                  service_data.A_cpu_num_total,
                                                                  service_data.A_mem_num_total,
                                                                  service_data.B_cpu_num_total,
                                                                  service_data.B_mem_num_total)
                if len(solutions) > 0:
                    machine_value_in_service = service_data.hardware_cost_cpu_k * value_cpu + \
                                               service_data.hardware_cost_mem_k * value_mem + machine_price_b
                    values_ratio.append([solutions, service_index,
                                         machine_value_in_service / service_data.hardware_cost])
            # 如果这一轮循环没有找到可以安放的虚拟机，那么退出循环
            if len(values_ratio) == 0: break
            # 对价值比进行排序，选择最小的价值比，并取出对应的solution
            values_ratio = sorted(values_ratio, key=lambda data: data[2], reverse=True)
            # 购买服务器，并将solution中的虚拟机放入服务器中
            solution = values_ratio[0][0]
            solution_index = []
            service_index = values_ratio[0][1]
            service_data = self.service_his_dict[-1][service_index]
            # 将服务器从空闲列表中清除
            del self.service_his_dict[-1][service_index]
            # 将solution中的虚拟机索引值取出来，并放到服务器中，并同时统计solution中的索引值，用于后期删除
            for data in solution:
                machine_index, service_node = data[0], data[1]
                # 记录所有的虚拟机索引值，用于后期删除
                solution_index.append(machine_index)
                # 取出虚拟机数据，将虚拟机分配到服务器中
                machine_data = machine_add_list[machine_index]
                # 将虚拟机放到服务器中
                assign_machine_to_service(service_data, service_node, self.machine_his_dict, machine_data)
            # # 如果是新购买的服务器，记录新添加的服务器，用于后面分配ID使用，不是新购买的服务器，所以这里屏蔽
            # service_his_dict_new_list.append(service_data)
            # 保存购买的服务器，保存到单节点中
            self.service_his_dict[0].append(service_data)
            solution_index = sorted(solution_index, key=lambda data: data)
            # 将以及安排好的虚拟机，从列表中删除,这块删除的时候，需要按照从后向前删除
            for index in range(len(solution_index) - 1, -1, -1):
                del_index = solution_index[index]
                # 从列表中删除虚拟机
                del machine_add_list[del_index]
                # 删除用于背包的数据
                del machine_cpu_cap[del_index]
                del machine_mem_cap[del_index]

        # 循环，直到没有虚拟机需要分配
        while len(machine_add_list) > 0:
            # 对每种类型的服务器分别做背包问题，返回的是，服务器的价值/服务器中放入的虚拟机价值，价值越小越好
            # 记录服务器的价值和虚拟机的价值比
            values_ratio = []
            # 对于所有类型的服务器做循环
            for service_type_data in self.constant.service_type_data.values():
                # 返回在这种服务器中，最多可以装下多少价值的虚拟机，里面不会修改列表的信息，所以不需要拷贝
                value_cpu, value_mem, solutions = Knapsack_single(machine_cpu_cap,
                                                                  machine_mem_cap,
                                                                  service_type_data.A_cpu_num_total,
                                                                  service_type_data.A_mem_num_total,
                                                                  service_type_data.B_cpu_num_total,
                                                                  service_type_data.B_mem_num_total)
                if len(solutions) > 0:
                    machine_value_in_service = service_type_data.hardware_cost_cpu_k * value_cpu + \
                                               service_type_data.hardware_cost_mem_k * value_mem + machine_price_b
                    values_ratio.append([solutions, service_type_data.type,
                                         machine_value_in_service / service_type_data.hardware_cost])
            # 如果这一轮循环没有找到可以安放的虚拟机，那么退出循环
            if len(values_ratio) == 0: break
            # 对价值比进行排序，选择最小的价值比，并取出对应的solution
            values_ratio = sorted(values_ratio, key=lambda data: data[2], reverse=True)
            # 购买服务器，并将solution中的虚拟机放入服务器中
            solution = values_ratio[0][0]
            solution_index = []
            service_type = values_ratio[0][1]
            service_type_data = self.constant.service_type_data[service_type]
            # 购买服务器
            service_data = ServiceData(service_type_data, None)  # 暂时未分配service_id
            # print('3. values_ratio[0][2] = ', values_ratio[0][2])
            # 将solution中的虚拟机索引值取出来，并放到服务器中，并同时统计solution中的索引值，用于后期删除
            for data in solution:
                machine_index, service_node = data[0], data[1]
                # 记录所有的虚拟机索引值，用于后期删除
                solution_index.append(machine_index)
                # 取出虚拟机数据，将虚拟机分配到服务器中
                machine_data = machine_add_list[machine_index]
                # 将虚拟机放到服务器中
                assign_machine_to_service(service_data, service_node, self.machine_his_dict, machine_data)
            # 如果是新购买的服务器，记录新添加的服务器，用于后面分配ID使用
            service_his_dict_new_list.append(service_data)
            # 保存购买的服务器，保存到单节点中
            self.service_his_dict[0].append(service_data)
            solution_index = sorted(solution_index, key=lambda data: data)
            # 将以及安排好的虚拟机，从列表中删除,这块删除的时候，需要按照从后向前删除
            for index in range(len(solution_index) - 1, -1, -1):
                del_index = solution_index[index]
                # 从列表中删除虚拟机
                del machine_add_list[del_index]
                # 删除用于背包的数据
                del machine_cpu_cap[del_index]
                del machine_mem_cap[del_index]

    #计算一个连续add的序列，应该如何调度,包含了单双节点，返回没有成功放置的虚拟机
    def update_add_continue_dual(self, machine_add_list, service_his_dict_new_list):
        #按照价格排序，进行降序排序，也就是先放大的虚拟机 # [虚拟机，虚拟机价格]
        #这块需要创建一个新的备份，sorted正好是创建备份，这个备份中存储着虚拟机的顺序
        #对单双节点分别排序
        # hardware_cost这块是根据服务器的系数计算出来的，
        machine_add_list.sort(key=lambda data: data.hardware_cost, reverse=True)

        #记录需要删除的虚拟机索引值，分别代表单节点和双节点
        machine_add_list_sorted_dels = []
        #使用0-1背包问题的贪婪算法，分配虚拟机

        #2.遍历双节点虚拟机，尝试将虚拟机放到服务器中
        for index, machine_data in enumerate(machine_add_list):
            #尝试将虚拟机放到已有的服务器中
            if add_old_service(self.service_his_dict, self.machine_his_dict, machine_data):
                #并且记录这个虚拟机信息需要删除
                machine_add_list_sorted_dels.append(index)
        # 删除双节点数据，这块删除的时候，需要按照从后向前删除
        for index in range(len(machine_add_list_sorted_dels) - 1, -1, -1):
            del_index = machine_add_list_sorted_dels[index]
            del machine_add_list[del_index]


        #4.while直到双节点虚拟机列表为空
        #开始收集数据，统计虚拟机的cpu/mem和价值
        machine_cpu_cap = []
        machine_mem_cap = []
        for machine_data in machine_add_list:
            #统计数据
            machine_cpu_cap.append(machine_data.cpu_num)
            machine_mem_cap.append(machine_data.mem_num)
        # 首先循环，尝试放到空闲的服务器中
        while len(self.service_his_dict[-1]) > 0 or len(machine_add_list) > 0:
            # 对每种类型的服务器分别做背包问题，返回的是，服务器的价值/服务器中放入的虚拟机价值，价值越小越好
            # 记录服务器的价值和虚拟机的价值比
            values_ratio = []
            # 对所有的空闲服务器做循环
            for service_index, service_data in enumerate(self.service_his_dict[-1]):
                # 返回在这种服务器中，最多可以装下多少价值的虚拟机，里面不会修改列表的信息，所以不需要拷贝
                value_cpu, value_mem, solutions = Knapsack_dual(machine_cpu_cap,
                                                                machine_mem_cap,
                                                                service_data.cpu_num_total,
                                                                service_data.mem_num_total)
                if len(solutions) > 0:
                    machine_value_in_service = service_data.hardware_cost_cpu_k * value_cpu + \
                                               service_data.hardware_cost_mem_k * value_mem + machine_price_b
                    values_ratio.append([solutions, service_index,
                                         machine_value_in_service / service_data.hardware_cost])
            #如果这一轮循环没有找到可以安放的虚拟机，那么退出循环
            if len(values_ratio) == 0: break
            # 对价值比进行排序，选择最小的价值比，并取出对应的solution
            values_ratio = sorted(values_ratio, key=lambda data: data[2], reverse=True)
            # 购买服务器，并将solution中的虚拟机放入服务器中
            solution = values_ratio[0][0]
            service_index = values_ratio[0][1]
            service_data = self.service_his_dict[-1][service_index]
            # 将服务器从空闲列表中清除
            del self.service_his_dict[-1][service_index]
            # 将solution中的虚拟机索引值取出来，并放到服务器中，并同时统计solution中的索引值，用于后期删除
            for machine_index in solution:
                # 取出虚拟机数据，将虚拟机分配到服务器中
                machine_data = machine_add_list[machine_index]
                # 将虚拟机放到服务器中
                assign_machine_to_service(service_data, 'N', self.machine_his_dict, machine_data)
            # # 如果是新购买的服务器，记录新添加的服务器，用于后面分配ID使用，不是新购买的服务器，所以这里屏蔽
            # service_his_dict_new_list.append(service_data)
            # 保存购买的服务器，保存到双节点中
            self.service_his_dict[1].append(service_data)
            # 将以及安排好的虚拟机，从列表中删除,这块删除的时候，需要按照从后向前删除
            for index in range(len(solution) - 1, -1, -1):
                del_index = solution[index]
                # 从列表中删除虚拟机
                del machine_add_list[del_index]
                # 删除用于背包的数据
                del machine_cpu_cap[del_index]
                del machine_mem_cap[del_index]

        #循环，直到没有虚拟机需要分配
        while len(machine_add_list) > 0:
            # 对每种类型的服务器分别做背包问题，返回的是，服务器的价值/服务器中放入的虚拟机价值，价值越小越好
            # 记录服务器的价值和虚拟机的价值比
            values_ratio = []
            # 对于所有类型的服务器做循环
            for service_type_data in self.constant.service_type_data.values():
                # 返回在这种服务器中，最多可以装下多少价值的虚拟机，里面不会修改列表的信息，所以不需要拷贝
                value_cpu, value_mem, solutions = Knapsack_dual(machine_cpu_cap,
                                                                machine_mem_cap,
                                                                service_type_data.cpu_num_total,
                                                                service_type_data.mem_num_total)
                if len(solutions) > 0:
                    machine_value_in_service = service_type_data.hardware_cost_cpu_k * value_cpu + \
                                               service_type_data.hardware_cost_mem_k * value_mem + machine_price_b
                    values_ratio.append([solutions, service_type_data.type,
                                         machine_value_in_service / service_type_data.hardware_cost])
            #如果这一轮循环没有找到可以安放的虚拟机，那么退出循环
            if len(values_ratio) == 0: break
            # 对价值比进行排序，选择最小的价值比，并取出对应的solution
            values_ratio = sorted(values_ratio, key=lambda data: data[2], reverse=True)
            # 购买服务器，并将solution中的虚拟机放入服务器中
            solution = values_ratio[0][0]
            service_type = values_ratio[0][1]
            service_type_data = self.constant.service_type_data[service_type]
            # 购买服务器
            service_data = ServiceData(service_type_data, None)  # 暂时未分配service_id
            # print('4. values_ratio[0][2] = ', values_ratio[0][2])
            # 将solution中的虚拟机索引值取出来，并放到服务器中，并同时统计solution中的索引值，用于后期删除
            for machine_index in solution:
                # 取出虚拟机数据，将虚拟机分配到服务器中
                machine_data = machine_add_list[machine_index]
                # 将虚拟机放到服务器中
                assign_machine_to_service(service_data, 'N', self.machine_his_dict, machine_data)
            # 如果是新购买的服务器，记录新添加的服务器，用于后面分配ID使用
            service_his_dict_new_list.append(service_data)
            # 保存购买的服务器，保存到双节点中
            self.service_his_dict[1].append(service_data)
            # 将以及安排好的虚拟机，从列表中删除,这块删除的时候，需要按照从后向前删除
            for index in range(len(solution) - 1, -1, -1):
                del_index = solution[index]
                # 从列表中删除虚拟机
                del machine_add_list[del_index]
                # 删除用于背包的数据
                del machine_cpu_cap[del_index]
                del machine_mem_cap[del_index]



    # 计算一个连续add的序列，应该如何调度,包含了单双节点
    def update_add(self, machine_add_list, service_his_dict_new_list):
        # 按照价格排序，进行降序排序，也就是先放大的虚拟机 # [虚拟机，虚拟机价格]
        # 这块需要创建一个新的备份，sorted正好是创建备份，这个备份中存储着虚拟机的顺序，
        # hardware_cost这块是根据服务器的系数计算出来的，
        machine_add_list.sort(key=lambda data: data.hardware_cost, reverse=True)

        # 记录需要删除的虚拟机索引值，分别代表单节点和双节点
        machine_add_list_sorted_dels = []

        # 对排序后的操作，在这块不需要有顺序，随便分配
        for index, machine_data in enumerate(machine_add_list):
            is_buy_service, service_data = \
                add_machine(self.constant, self.service_his_dict, self.machine_his_dict, machine_data)
            # 如果确实分配了该虚拟机，那么操作
            if service_data is not None:
                # 如果是新购买的服务器，记录新添加的服务器，用于后面分配ID使用
                if is_buy_service: service_his_dict_new_list.append(service_data)
                # 并且记录这个虚拟机信息需要删除
                machine_add_list_sorted_dels.append(index)
        # 删除单节点数据，这块删除的时候，需要按照从后向前删除
        for index in range(len(machine_add_list_sorted_dels) - 1, -1, -1):
            del_index = machine_add_list_sorted_dels[index]
            del machine_add_list[del_index]

        # 到这里可能还有虚拟机还没有安放

    #更新删除序列
    def update_del(self, machine_del_id_list):
        #循环删除虚拟机
        for machine_id in machine_del_id_list:
            del_machine(self.machine_his_dict, machine_id)

    def release_services(self):
        #统计只有一个虚拟机的服务器
        service_machine_one_list = [[], []]
        #遍历单节点和双节点服务器，将完全空的服务器释放出来，放到另外一个位置
        del_index = []
        #单节点
        for index, service_data in enumerate(self.service_his_dict[0]):
            machine_list_len = len(service_data.machine_list)
            if machine_list_len == 0: del_index.append(index)
            if machine_list_len == 1: service_machine_one_list[0].append(service_data)
        # 将已经空的服务器放到空服务器列表中
        for index in del_index[::-1]:
            self.service_his_dict[-1].append(self.service_his_dict[0][index])
            del self.service_his_dict[0][index]
        del_index = []
        #双节点
        for index, service_data in enumerate(self.service_his_dict[1]):
            machine_list_len = len(service_data.machine_list)
            if machine_list_len == 0: del_index.append(index)
            if machine_list_len == 1: service_machine_one_list[1].append(service_data)
        # 将已经空的服务器放到空服务器列表中
        for index in del_index[::-1]:
            self.service_his_dict[-1].append(self.service_his_dict[1][index])
            del self.service_his_dict[1][index]

        return service_machine_one_list

    #根据一天的输入，开始计算所需服务器数量
    def update_day(self, operate_data_day, operate_data_day_id_all):

        # 在请求的过程中，不断判断能不能放在旧的服务器上，如果不能，则购买新的服务器
        # 将新添加的服务器的信息，保存在列表中，用于后面分配id
        # 记录开始的一个id起始
        old_service_his_len = len(self.service_his_dict[-1]) + len(self.service_his_dict[0]) + len(self.service_his_dict[1])
        service_his_dict_new_list = []

        #记录最大迁移数量
        migration_len_max = int((3 * len(self.machine_his_dict)) / 100)
        self.migration_num_max += migration_len_max

        #在一天的开始，首先先做虚拟机迁移
        machine_migration_list_all = []

        # 1.------------------第一次迁移
        machine_migration_list, service_his_dict_new, is_greater_than_max = update_migration(migration_len_max, self.service_his_dict)
        do_migration(machine_migration_list)
        migration_len_max -= len(machine_migration_list)
        if migration_len_max < 0: raise ValueError('migration num greater than max')
        self.migration_num_total += len(machine_migration_list)
        machine_migration_list_all.extend(machine_migration_list)

        # 2.------------------第二次迁移,循环迁移
        while True:
            #不能接着迁移了，退出循环
            if (len(service_his_dict_new[0]) <= 1) and (len(service_his_dict_new[1]) <= 1): break
            machine_migration_list, service_his_dict_new, is_greater_than_max = update_migration_another(migration_len_max, service_his_dict_new)
            do_migration(machine_migration_list)
            migration_len_max -= len(machine_migration_list)
            if migration_len_max < 0: raise ValueError('migration num greater than max')
            self.migration_num_total += len(machine_migration_list)
            machine_migration_list_all.extend(machine_migration_list)

        # 将完全空的服务器释放出来，从而单节点和双节点都可以使用，并同时统计统计只有一个虚拟机的服务器列表
        service_machine_one_list = self.release_services()
        #再次开始迁移，将只有一个虚拟机的服务器，迁移到完全空闲的服务器中，如果迁移后的费用下降，那么确实迁移
        update_migration_fine(migration_len_max, self.service_his_dict[-1], service_machine_one_list)
        # 迁移结束

        # 首先需要取出来一个最长的连续add序列，如果有del，那么开始计数，如果del序列超过设定值，那么开始del
        for operate_data in operate_data_day:
            # 三个变量，连读add_single,连续add_del,连续del
            # 开始分配虚拟机到服务器上，有的虚拟机可能会分配不到服务器，后面处理
            if len(operate_data[0]) >= machine_add_list_max_len and len(operate_data[1]) >= machine_add_list_max_len:
                self.update_add_continue_single(operate_data[0], service_his_dict_new_list)
                self.update_add_continue_dual(operate_data[1], service_his_dict_new_list)
            else:
                self.update_add(operate_data[0], service_his_dict_new_list)
                self.update_add(operate_data[1], service_his_dict_new_list)
            # self.update_add(operate_data[0], service_his_dict_new_list)
            # self.update_add(operate_data[1], service_his_dict_new_list)
            #
            self.update_del(operate_data[2])

        #一天的数据读取完毕，下面开始做服务器id分配
        service_type_num = assign_service_id(old_service_his_len, service_his_dict_new_list)

        if self.output is not None:
            #计算输出信息，先输出购买服务器，再输出迁移虚拟机，最后输出虚拟机放置信息
            self.output.add_service(service_type_num)
            self.output.add_migration(machine_migration_list_all)
            self.output.add_machine(operate_data_day_id_all, self.machine_his_dict)

    # 根据一天的输入，开始计算所需服务器数量
    def update_day_k(self, operate_data_day_k, operate_data_day_id_all_k):
        #k天数据一起过来
        for day_index in range(len(operate_data_day_k)):
            #
            operate_data_day = operate_data_day_k[day_index]
            operate_data_day_id_all = operate_data_day_id_all_k[day_index]
            #
            self.update_day(operate_data_day, operate_data_day_id_all)
            # 更新累积天数，
            self.constant.day_now += 1
            #
            if self.money is not None:
                #计算价钱
                self.money.calc(self.service_his_dict, self.machine_his_dict)
                self.money.analysis_service(self.service_his_dict)
                self.money.analysis_machine(self.machine_his_dict)
                self.money.analysis_machine_add(operate_data_day)






