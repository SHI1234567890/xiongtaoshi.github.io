
class DataAnalysis():

    def plot_service_buy_machine_cause(self, service_buy_machine_cause, service_type_data_all, machine_type_data_all):
        # 打印
        # 绘图
        import matplotlib.pyplot as plt
        total_len = 0
        for key in service_buy_machine_cause:
            print('key = ', key)
            print(service_type_data_all[key])
            print('len = ', len(list(service_buy_machine_cause[key])))
            temp = list(set(service_buy_machine_cause[key]))
            ratio = []
            for machine_type in temp:
                machine_type_data = machine_type_data_all[machine_type]
                ratio.append(machine_type_data.cpu_num / machine_type_data.mem_num)
                print(machine_type_data)
            total_len += len(temp)
            print('len(temp) = ', len(temp))
            print(temp)
            plt.figure(figsize=(19.20, 10.80))
            plt.plot(ratio, 'r*')
            plt.grid()
            plt.title(service_type_data_all[key])
            plt.show()

        print('total_len = ', total_len)

    # def analysis_machine(self, machine_type_data):
    #     cpu_data = []
    #     mem_data = []
    #     ratio_data = []
    #     for machine_data in machine_type_data.values():
    #         cpu_data.append(machine_data.cpu_num)
    #         mem_data.append(machine_data.mem_num)
    #         ratio_data.append(machine_data.cpu_num / machine_data.mem_num)
    #     # 画图
    #     import matplotlib.pyplot as plt
    #     plt.plot(ratio_data, '*r', label='ratio')
    #     plt.grid()
    #     plt.legend()
    #     # plt.xlabel('day')
    #     # plt.ylabel('number')
    #     plt.show()

    def analysis_machine(self, machine_type_data):
        cpu_data = []
        mem_data = []
        ratio_data1 = []
        ratio_data2 = []
        for machine_data in machine_type_data.values():
            cpu_data.append(machine_data.cpu_num)
            mem_data.append(machine_data.mem_num)
            if machine_data.cpu_num/machine_data.mem_num > 1:
                ratio_data1.append(machine_data.cpu_num/machine_data.mem_num)
            else:
                ratio_data2.append(machine_data.mem_num/machine_data.cpu_num)
        #画图
        import matplotlib.pyplot as plt
        fig = plt.figure(figsize=(19.20, 10.80))
        plt.plot(sorted(ratio_data1, key=lambda data:data), '*r', label='ratio')
        plt.grid()
        plt.title('cpu_mem')
        fig = plt.figure(figsize=(19.20, 10.80))
        plt.plot(sorted(ratio_data2, key=lambda data:data), '*r', label='ratio')
        plt.grid()
        plt.title('mem_cpu')
        # plt.legend()
        # plt.xlabel('day')
        # plt.ylabel('number')
        plt.show()


    def norm_data(self, data_list):
        data_max = data_list[0]
        data_min = data_list[0]
        new_data_list = []
        for data in data_list:
            if data > data_max: data_max = data
            if data < data_min: data_min = data
        for data in data_list:
            new_data_list.append(int(100*(data-data_min)/(data_max-data_min)))

        return new_data_list

    def analysis_service1(self, service_type_data):
        #绘制硬件成本比上运营成本
        money_data1 = []
        money_data2 = []
        money_data3 = []
        for service_data in service_type_data.values():
            money_data1.append(service_data.hardware_cost)
            money_data2.append(service_data.day_cost)
            money_data3.append(service_data.day_cost / service_data.hardware_cost)
        import matplotlib.pyplot as plt
        plt.plot(money_data1, money_data2, 'r*')
        plt.show()
        plt.plot(money_data3, 'r*')
        plt.show()
        plt.plot(self.norm_data(money_data3), 'r*')
        plt.show()

    def analysis_service(self, service_type_data):
        import math
        cpu_data = []
        mem_data = []
        ratio_data = []
        ratio_data1 = []
        ratio_data2 = []
        # money_data = []
        for service_data in service_type_data.values():
            cpu_data.append(service_data.cpu_num_total)
            mem_data.append(service_data.mem_num_total)
            ratio_data.append(math.log(service_data.cpu_num_total/service_data.mem_num_total))
            if service_data.cpu_num_total/service_data.mem_num_total > 1:
                ratio_data1.append(service_data.cpu_num_total/service_data.mem_num_total)
            else:
                ratio_data2.append(service_data.mem_num_total/service_data.cpu_num_total)
            # money_data.append(service_data.hardware_cost)
            # money_data.append(service_data.day_cost)
        #画图
        import matplotlib.pyplot as plt
        fig = plt.figure(figsize=(19.20, 10.80))
        plt.plot(sorted(ratio_data, key=lambda data: data), '*r', label='ratio')
        plt.grid()
        plt.title('log(cpu_mem)')
        fig = plt.figure(figsize=(19.20, 10.80))
        plt.plot(sorted(ratio_data1, key=lambda data:data), '*r', label='ratio')
        plt.grid()
        plt.title('cpu_mem')
        fig = plt.figure(figsize=(19.20, 10.80))
        plt.plot(sorted(ratio_data2, key=lambda data:data), '*r', label='ratio')
        plt.grid()
        plt.title('mem_cpu')
        # plt.legend()
        # plt.xlabel('day')
        # plt.ylabel('number')
        plt.show()

        #开始画图
        # import numpy as np
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D  # 空间三维画图

        fig = plt.figure(figsize=(19.20, 10.80))
        # plt.plot(cpu_data, money_data, '*r', label='cpu')
        # plt.plot(mem_data, money_data, '*g', label='mem')

        ax = Axes3D(fig)
        # ax.scatter(cpu_data, mem_data, money_data)
        ax.scatter(cpu_data, mem_data, ratio_data)
        ax.set_zlabel('ratio', fontdict={'size': 15, 'color': 'red'})
        ax.set_ylabel('mem', fontdict={'size': 15, 'color': 'red'})
        ax.set_xlabel('cpu', fontdict={'size': 15, 'color': 'red'})
        plt.grid()
        plt.legend()
        # plt.xlabel('day')
        # plt.ylabel('number')
        plt.show()

    # def analysis_service(self, service_type_data):
    #     cpu_data = [[] for i in range(5)]
    #     mem_data = [[] for i in range(5)]
    #     ratio_data = [[] for i in range(5)]
    #     for service_data in service_type_data.values():
    #         if service_data.cpu_num_total < 200:
    #             cpu_data[0].append(service_data.cpu_num_total)
    #             mem_data[0].append(service_data.mem_num_total)
    #             ratio_data[0].append(service_data.cpu_num_total / service_data.mem_num_total)
    #         elif service_data.cpu_num_total < 400:
    #             cpu_data[1].append(service_data.cpu_num_total)
    #             mem_data[1].append(service_data.mem_num_total)
    #             ratio_data[1].append(service_data.cpu_num_total / service_data.mem_num_total)
    #         elif service_data.cpu_num_total < 600:
    #             cpu_data[2].append(service_data.cpu_num_total)
    #             mem_data[2].append(service_data.mem_num_total)
    #             ratio_data[2].append(service_data.cpu_num_total / service_data.mem_num_total)
    #         elif service_data.cpu_num_total < 800:
    #             cpu_data[3].append(service_data.cpu_num_total)
    #             mem_data[3].append(service_data.mem_num_total)
    #             ratio_data[3].append(service_data.cpu_num_total / service_data.mem_num_total)
    #         else:
    #             cpu_data[4].append(service_data.cpu_num_total)
    #             mem_data[4].append(service_data.mem_num_total)
    #             ratio_data[4].append(service_data.cpu_num_total / service_data.mem_num_total)
    #
    #
    #     #开始画图
    #     # import numpy as np
    #     import matplotlib.pyplot as plt
    #     from mpl_toolkits.mplot3d import Axes3D  # 空间三维画图
    #     import numpy as np
    #     for i in range(5):
    #
    #         fig = plt.figure(figsize=(19.20, 10.80))
    #         # plt.plot(cpu_data, money_data, '*r', label='cpu')
    #         # plt.plot(mem_data, money_data, '*g', label='mem')
    #
    #         ax = Axes3D(fig)
    #         # ax.scatter(cpu_data, mem_data, money_data)
    #         ax.scatter(cpu_data[i], mem_data[i], ratio_data[i])
    #         ax.set_zlabel('ratio' + ' min = ' + str(np.min(ratio_data[i])) + ' max = ' + str(np.max(ratio_data[i])),
    #                       fontdict={'size': 15, 'color': 'red'})
    #         ax.set_ylabel('mem', fontdict={'size': 15, 'color': 'red'})
    #         ax.set_xlabel('cpu' + ' total len = ' + str(len(cpu_data[i])), fontdict={'size': 15, 'color': 'red'})
    #         ax.set_title('wireframe')
    #         plt.grid()
    #         # plt.legend()
    #         # plt.xlabel('day')
    #         # plt.ylabel('number')
    #     plt.show()

    # def analysis_service(self, service_type_data_list):
    #     cpu_data = []
    #     mem_data = []
    #     money_data = []
    #     file_write = open('result/result1.txt', 'w')
    #     for service_type in service_type_data_list:
    #         cpu_num = service_type[0] + service_type[2]
    #         mem_num = service_type[1] + service_type[3]
    #         money = service_type[4]
    #         cpu_data.append(cpu_num)
    #         mem_data.append(mem_num)
    #         money_data.append(money)
    #         write_str = str(cpu_num) + ',' + str(mem_num) + ',' + str(money) + '\n'
    #         file_write.write(write_str)
    #     file_write.close()
    #     #开始画图
    #     # import numpy as np
    #     import matplotlib.pyplot as plt
    #     from mpl_toolkits.mplot3d import Axes3D  # 空间三维画图
    #
    #     fig = plt.figure(figsize=(19.20, 10.80))
    #     # plt.plot(cpu_data, money_data, '*r', label='cpu')
    #     # plt.plot(mem_data, money_data, '*g', label='mem')
    #
    #     ax = Axes3D(fig)
    #     ax.scatter(cpu_data, mem_data, money_data)
    #     ax.set_zlabel('money', fontdict={'size': 15, 'color': 'red'})
    #     ax.set_ylabel('mem', fontdict={'size': 15, 'color': 'red'})
    #     ax.set_xlabel('cpu', fontdict={'size': 15, 'color': 'red'})
    #     plt.grid()
    #     plt.legend()
    #     # plt.xlabel('day')
    #     # plt.ylabel('number')
    #     plt.show()

    # def analysis_machine(self, machine_type_data_list):
    #     cpu_data = [[],[]]#single,dual
    #     mem_data = [[],[]]#single,dual
    #     for machine_type in machine_type_data_list:
    #         cpu_data[machine_type[2]].append(machine_type[0])
    #         mem_data[machine_type[2]].append(machine_type[1])
    #     #
    #     #开始画图
    #     import matplotlib.pyplot as plt
    #     from mpl_toolkits.mplot3d import Axes3D  # 空间三维画图
    #     fig = plt.figure(figsize=(19.20, 10.80))
    #     plt.plot(cpu_data[0], mem_data[0], '*r', label='single')
    #     plt.plot(cpu_data[1], mem_data[1], '*g', label='dual')
    #     plt.grid()
    #     plt.legend()
    #     plt.xlabel('cpu')
    #     plt.ylabel('mem')
    #     plt.show()
