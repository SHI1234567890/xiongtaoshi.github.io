
#0.---------------------------
#del序列的最小长度
operate_data_day_del_min_len = 7
#1.---------------------------
#可以调整的比例系数，用来调整cpu和mem的重要性，在放置旧服务器的时候，cpu和mem的重要性参数，购买新服务器时使用对应的系数
service_score_cpu_k = 2.12
service_score_mem_k = 1.0
#2.---------------------------
#硬件成本和day成本，在放置旧服务器和购买新服务器的hardware_cost和day_cost的重要性
service_score_hardware_k = 1.0
service_score_day_k = 1700
#3.---------------------------
#第一次迁移的时候的，day_cost的重要性系数，虚拟机迁移
service_day_cost_k = 410#1000，但是时间有点长，不知道能不能运行成功
#后面再次迁移的时候，day_cost的重要性系数，虚拟机迁移
calc_service_day_cost_k = 5
#4.---------------------------
#虚拟机计算day_cost时的系数
machine_hardware_cost_cpu_k = 1.9
machine_hardware_cost_mem_k = 1
#虚拟机硬件成本和day_cost计算系数
machine_day_cost_cpu_k = 1
machine_day_cost_mem_k = 1
#5.---------------------------
#再次迁移的时候，分数计算系数，迁移系数
migration_cpu_occupancy_ratio_k = 1.7#3.2时间有点久
migration_cpu_num_now_k = 0.6
migration_mem_occupancy_ratio_k = migration_cpu_occupancy_ratio_k
migration_mem_num_now_k = migration_cpu_num_now_k
#6.---------------------------
#服务器和虚拟机的比例匹配系数，用于匹配服务器和虚拟机的cpu/mem
service_machine_match_k = 48

#7.---------------------------
#在使用continue函数放置新虚拟机的时候，使用贪婪背包，会得出一个虚拟机列表，需要计算价值，这里是系数
#-110的时候，没有开启fine迁移，1773114119，210990，57.163
#-300的时候，没有开启fine迁移，1770744132，213027，128.004
machine_price_b = 300#-110#新修改的没有很好，暂时使用旧的300的参数
#8.---------------------------
#最短的add序列，如果满足这个条件，执行连续add
machine_add_list_max_len = 31

#定义成函数，所有的变量，全部传参过来，更清晰
#9.---------------------------
#搜索的最大长度，不全部搜索，搜索到满足个数的服务器就排序，找最优，并退出
feasible_solution_len_max = 21#46,59
#10.---------------------------
#虚拟机迁移常数变量，遍历服务器，占用比的系数边界
service_occupancy_ratio_max_backward = 0.93 #这个条件满足 continue
service_occupancy_ratio_max_forward = 0.95 #这个条件满足 continue
#11.---------------------------
#虚拟机迁移参数,day_cost，数越大，day_cost越不重要
service_day_cost_divide_k = 30
#12.---------------------------
#虚拟机迁移参数，决定cpu和mem的重要程度
service_migration_cpu_k = 2.9
service_migration_mem_k = 0.86
#13.---------------------------
# 背包遍历最大长度
Knapsack_max_len = 300
