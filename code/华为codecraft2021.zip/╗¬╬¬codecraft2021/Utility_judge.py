
##判断双节点是否放得下
def is_required_dual_model_old(service_data, machine_data):
    #dual_model, is cpu and mem satisfy requirement?
    if (machine_data.cpu_num <= service_data.A_cpu_num_now*2 and machine_data.cpu_num <= service_data.B_cpu_num_now*2) and \
        (machine_data.mem_num <= service_data.A_mem_num_now*2 and machine_data.mem_num <= service_data.B_mem_num_now*2): return True
    else: return False

#判断单节点是否放得下,需要同时返回两个节点的判断结果
def is_required_single_model_two_old(service_data, machine_data):
    #single model, is cpu and mem satisfy requirement?
    A_ret = (machine_data.cpu_num <= service_data.A_cpu_num_now and machine_data.mem_num <= service_data.A_mem_num_now)
    B_ret = (machine_data.cpu_num <= service_data.B_cpu_num_now and machine_data.mem_num <= service_data.B_mem_num_now)
    #
    return A_ret, B_ret

##判断双节点是否放得下，这里是判断服务器类型的数据，
def is_required_dual_model_new(service_type_data, machine_data):
    #dual_model, is cpu and mem satisfy requirement?
    if (machine_data.cpu_num <= service_type_data.A_cpu_num_total*2 and machine_data.cpu_num <= service_type_data.B_cpu_num_total*2) and \
        (machine_data.mem_num <= service_type_data.A_mem_num_total*2 and machine_data.mem_num <= service_type_data.B_mem_num_total*2): return True
    else: return False

#判断单节点是否放得下，这里是判断服务器类型的数据，假如返回数据，肯定会返回A节点
def is_required_single_model_new(service_type_data, machine_data):
    #single model, is cpu and mem satisfy requirement?
    if (machine_data.cpu_num <= service_type_data.A_cpu_num_total and machine_data.mem_num <= service_type_data.A_mem_num_total): return 'A'
    elif (machine_data.cpu_num <= service_type_data.B_cpu_num_total and machine_data.mem_num <= service_type_data.B_mem_num_total): return 'B'
    else: return False

#检测服务器资源是否出现过分配的情况，也就是没有相应的资源，却分配了
def is_error(service_data):
    error = True if (service_data.A_cpu_num_now < 0 or
                     service_data.B_cpu_num_now < 0 or
                     service_data.A_mem_num_now < 0 or
                     service_data.B_mem_num_now < 0) else False
    if error: raise ValueError('error service_data = ', service_data)
    return error

