
from Parameter import Knapsack_max_len

#使用贪心算法，解决0-1背包问题，输入的数据是有序的，从大到小排序了
def Knapsack_single(machine_cpu_cap,
                    machine_mem_cap,
                    service_cpu_A_cap,
                    service_mem_A_cap,
                    service_cpu_B_cap,
                    service_mem_B_cap):
    #设置最大循环长度
    total_len = len(machine_cpu_cap)
    if total_len >= Knapsack_max_len: total_len = Knapsack_max_len
    #
    #总价值
    value_cpu = 0
    value_mem = 0
    index_all = [i for i in range(total_len)]
    solution = []
    #首先对A节点做
    for index in range(total_len):
        #如果可以装下
        if machine_cpu_cap[index] <= service_cpu_A_cap and machine_mem_cap[index] <= service_mem_A_cap:
            #修改占用信息
            service_cpu_A_cap -= machine_cpu_cap[index]
            service_mem_A_cap -= machine_mem_cap[index]
            # 累加cpu
            value_cpu += machine_cpu_cap[index]
            # 累加mem
            value_mem += machine_mem_cap[index]
            solution.append([index, 'A'])
            #在下面循环的时候，负数代表以及选过了，直接跳过
            index_all[index] = -1
            #如果没有容量，提前退出
            if service_cpu_A_cap == 0 or service_mem_A_cap == 0: break
    #对B节点做
    for index in index_all:
        #如果没有选过
        if index >= 0:
            #如果可以装下
            if machine_cpu_cap[index] < service_cpu_B_cap and machine_mem_cap[index] < service_mem_B_cap:
                # 修改占用信息
                service_cpu_B_cap -= machine_cpu_cap[index]
                service_mem_B_cap -= machine_mem_cap[index]
                # 累加cpu
                value_cpu += machine_cpu_cap[index]
                # 累加mem
                value_mem += machine_mem_cap[index]
                solution.append([index, 'B'])
                # 如果没有容量，提前退出
                if service_cpu_B_cap == 0 or service_mem_B_cap == 0: break

    return value_cpu, value_mem, solution


def Knapsack_dual(machine_cpu_cap,
                  machine_mem_cap,
                  service_cpu_cap,
                  service_mem_cap):
    # 设置最大循环长度
    total_len = len(machine_cpu_cap)
    if total_len >= Knapsack_max_len: total_len = Knapsack_max_len
    # 总价值
    value_cpu = 0
    value_mem = 0
    solution = []
    #直接开始，不需要区分两个节点
    for index in range(total_len):
        # 如果可以装下
        if machine_cpu_cap[index] <= service_cpu_cap and machine_mem_cap[index] <= service_mem_cap:
            # 修改占用信息
            service_cpu_cap -= machine_cpu_cap[index]
            service_mem_cap -= machine_mem_cap[index]
            # 累加cpu
            value_cpu += machine_cpu_cap[index]
            # 累加mem
            value_mem += machine_mem_cap[index]
            solution.append(index)
            # 如果没有容量，提前退出
            if service_cpu_cap == 0 or service_mem_cap == 0: break

    return value_cpu, value_mem, solution


#使用贪心算法，解决0-1背包问题，输入的数据是有序的，从大到小排序了
def Knapsack_single_value(machine_cpu_cap,
                          machine_mem_cap,
                          machine_value,
                          service_cpu_A_cap,
                          service_mem_A_cap,
                          service_cpu_B_cap,
                          service_mem_B_cap):
    #设置最大循环长度
    total_len = len(machine_cpu_cap)
    #
    #总价值
    value_cost = 0
    index_all = [i for i in range(total_len)]
    solution = []
    #首先对A节点做
    for index in range(total_len):
        #如果可以装下
        if machine_cpu_cap[index] <= service_cpu_A_cap and machine_mem_cap[index] <= service_mem_A_cap:
            #修改占用信息
            service_cpu_A_cap -= machine_cpu_cap[index]
            service_mem_A_cap -= machine_mem_cap[index]
            # 累加day_cost
            value_cost += machine_value[index]
            solution.append([index, 'A'])
            #在下面循环的时候，负数代表以及选过了，直接跳过
            index_all[index] = -1
            #如果没有容量，提前退出
            if service_cpu_A_cap == 0 or service_mem_A_cap == 0: break
    #对B节点做
    for index in index_all:
        #如果没有选过
        if index >= 0:
            #如果可以装下
            if machine_cpu_cap[index] < service_cpu_B_cap and machine_mem_cap[index] < service_mem_B_cap:
                # 修改占用信息
                service_cpu_B_cap -= machine_cpu_cap[index]
                service_mem_B_cap -= machine_mem_cap[index]
                # 累加day_cost
                value_cost += machine_value[index]
                solution.append([index, 'B'])
                # 如果没有容量，提前退出
                if service_cpu_B_cap == 0 or service_mem_B_cap == 0: break

    return value_cost, solution


def Knapsack_dual_value(machine_cpu_cap,
                        machine_mem_cap,
                        machine_value,
                        service_cpu_cap,
                        service_mem_cap):
    # 设置最大循环长度
    total_len = len(machine_cpu_cap)
    #总价值
    value_cost = 0
    solution = []
    #直接开始，不需要区分两个节点
    for index in range(total_len):
        # 如果可以装下
        if machine_cpu_cap[index] <= service_cpu_cap and machine_mem_cap[index] <= service_mem_cap:
            # 修改占用信息
            service_cpu_cap -= machine_cpu_cap[index]
            service_mem_cap -= machine_mem_cap[index]
            # 累加day_cost
            value_cost += machine_value[index]
            solution.append(index)
            # 如果没有容量，提前退出
            if service_cpu_cap == 0 or service_mem_cap == 0: break

    return value_cost, solution

