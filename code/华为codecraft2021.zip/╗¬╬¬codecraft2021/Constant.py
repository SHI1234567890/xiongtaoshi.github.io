
import math
from collections import OrderedDict
from Parameter import service_score_cpu_k, service_score_mem_k, \
    service_score_hardware_k, service_score_day_k, \
    service_day_cost_k, calc_service_day_cost_k, \
    machine_hardware_cost_cpu_k, machine_hardware_cost_mem_k, \
    machine_day_cost_cpu_k, machine_day_cost_mem_k, \
    migration_cpu_occupancy_ratio_k, migration_cpu_num_now_k, \
    migration_mem_occupancy_ratio_k, migration_mem_num_now_k, \
    service_machine_match_k

class ServiceTypeData():
    def __init__(self, type, cpu_num_total, mem_num_total, hardware_cost, day_cost):
        #
        self.type = type
        #归属类别，暂时无类别
        self.class_belong = None
        self.class_max = None
        #
        self.cpu_num_total = cpu_num_total
        self.mem_num_total = mem_num_total
        #所有服务器的平均值
        self.cpu_num_mean = 0
        self.mem_num_mean = 0
        #计算总的cpu/mem
        # self.ratio_cpu_mem_total = math.log(self.cpu_num_total / self.mem_num_total)
        self.A_cpu_num_total = int(cpu_num_total/2)
        self.B_cpu_num_total = int(cpu_num_total/2)
        self.A_mem_num_total = int(mem_num_total/2)
        self.B_mem_num_total = int(mem_num_total/2)
        #计算每个节点的cpu/mem
        # self.A_ratio_cpu_mem_total = math.log(self.A_cpu_num_total / self.A_mem_num_total)
        # self.B_ratio_cpu_mem_total = math.log(self.B_cpu_num_total / self.B_mem_num_total)
        #
        self.hardware_cost = hardware_cost
        self.day_cost = day_cost
        #按照day_cost/hardware_cost的大小对服务器进行分类，暂时这里会分成三类
        self.ratio_day_cost_hardware_cost = self.day_cost / self.hardware_cost
        self.ratio_day_cost_hardware_cost_norm10 = 0
        #两个节点分别的费用
        self.hardware_cost_A = 0
        self.day_cost_A = 0
        self.hardware_cost_B = 0
        self.day_cost_B = 0
        #通过线性回归算法，拟合，硬件成本和day成本的计算公式的系数，总共6个系数，通过别的地方更新
        self.hardware_cost_cpu_k = 0
        self.hardware_cost_mem_k = 0
        self.hardware_cost_b = 0
        self.day_cost_cpu_k = 0
        self.day_cost_mem_k = 0
        self.day_cost_b = 0

    #计算单个节点的价值
    def calc_cost(self):
        self.hardware_cost_A = self.hardware_cost_cpu_k * self.A_cpu_num_total + \
                               self.hardware_cost_mem_k * self.A_mem_num_total + \
                               self.hardware_cost_b
        self.day_cost_A = self.day_cost_cpu_k * self.A_cpu_num_total + \
                          self.day_cost_mem_k * self.A_mem_num_total + \
                          self.day_cost_b
        self.hardware_cost_B = self.hardware_cost_cpu_k * self.B_cpu_num_total + \
                               self.hardware_cost_mem_k * self.B_mem_num_total + \
                               self.hardware_cost_b
        self.day_cost_B = self.day_cost_cpu_k * self.B_cpu_num_total + \
                          self.day_cost_mem_k * self.B_mem_num_total + \
                          self.day_cost_b

    def calc_score(self, machine_cpu_num, machine_mem_num, day_now, total_day):
        # 计算性价比=硬件成本价钱*(虚拟机/服务器)
        cpu_ratio = machine_cpu_num / self.cpu_num_total  # cpu_num
        mem_ratio = machine_mem_num / self.mem_num_total  # mem_num

        # 使用非线性动态系数
        score = (service_score_hardware_k * self.hardware_cost + service_score_day_k * ((total_day - day_now) / total_day)**2 * self.day_cost) * \
                (self.hardware_cost_cpu_k / self.hardware_cost_mem_k * cpu_ratio + 1 * mem_ratio) * \
                (abs(math.log(machine_cpu_num / machine_mem_num) - math.log(self.cpu_num_total / self.mem_num_total)) +
                 service_machine_match_k)

        return score


    def __str__(self):
        #type = hostZS43C A_cpu_num_total = 462 B_cpu_num_total = 462 A_mem_num_total = 66 B_mem_num_total = 66 hardware_cost = 212065 day_cost = 212
        return 'type = ' + self.type + \
               ' class_belong = ' + str(self.class_belong) + \
               ' class_max = ' + str(self.class_max) + \
               ' A_cpu_num_total = ' + str(self.A_cpu_num_total) + \
               ' B_cpu_num_total = ' + str(self.B_cpu_num_total) + \
               ' A_mem_num_total = ' + str(self.A_mem_num_total) + \
               ' B_mem_num_total = ' + str(self.B_mem_num_total) + \
               ' hardware_cost = ' + str(self.hardware_cost) + \
               ' day_cost = ' + str(self.day_cost)

class ServiceData(ServiceTypeData):
    def __init__(self, service_type_data, service_id):
        super(ServiceData, self).__init__(service_type_data.type,
                                          service_type_data.cpu_num_total,
                                          service_type_data.mem_num_total,
                                          service_type_data.hardware_cost,
                                          service_type_data.day_cost)
        # 所有服务器的平均值
        self.cpu_num_mean = service_type_data.cpu_num_mean
        self.mem_num_mean = service_type_data.mem_num_mean
        #对归属类别进行赋值
        self.class_belong = service_type_data.class_belong
        self.class_max = service_type_data.class_max
        #给回归出来的变量赋值
        self.hardware_cost_cpu_k = service_type_data.hardware_cost_cpu_k
        self.hardware_cost_mem_k = service_type_data.hardware_cost_mem_k
        self.hardware_cost_b = service_type_data.hardware_cost_b
        self.day_cost_cpu_k = service_type_data.day_cost_cpu_k
        self.day_cost_mem_k = service_type_data.day_cost_mem_k
        self.day_cost_b = service_type_data.day_cost_b
        #
        self.hardware_cost_A = service_type_data.hardware_cost_A
        self.day_cost_A = service_type_data.day_cost_A
        self.hardware_cost_B = service_type_data.hardware_cost_B
        self.day_cost_B = service_type_data.day_cost_B
        #
        self.A_cpu_num_now = self.A_cpu_num_total
        self.B_cpu_num_now = self.B_cpu_num_total
        self.A_mem_num_now = self.A_mem_num_total
        self.B_mem_num_now = self.B_mem_num_total
        #占用率
        self.occupancy_ratio = 1
        self.occupancy_ratio_fine = 1
        self.occupancy_ratio_ret = 1
        #实时更新
        self.hardware_cost_now = 0
        self.day_cost_now = 0
        self.hardware_cost_now_A = 0
        self.day_cost_now_A = 0
        self.hardware_cost_now_B = 0
        self.day_cost_now_B = 0
        #分配的id,只用于最后的输出
        self.service_id = service_id
        # 服务器装载的虚拟机是否是dual_model，当服务器清空后重新变为None，否则和虚拟机的值相同
        # self.dual_model = None
        #虚拟机列表，保存这个服务器中，都存储了那些虚拟机
        self.machine_list = OrderedDict()

    def calc_occupancy_ratio(self):

        cpu_occupancy_ratio = 1 - ((self.A_cpu_num_now + self.B_cpu_num_now) / self.cpu_num_total)
        mem_occupancy_ratio = 1 - ((self.A_mem_num_now + self.B_mem_num_now) / self.mem_num_total)

        #计算两个比值中小的那个
        self.occupancy_ratio = cpu_occupancy_ratio if cpu_occupancy_ratio <= mem_occupancy_ratio else mem_occupancy_ratio
        # 占用率越第，越容易发生迁移，价钱越高，越容易发生迁移，如何同时考虑这两种呢？
        # 返回值越小，越容易被迁移
        self.occupancy_ratio_ret = self.occupancy_ratio + (-self.day_cost / service_day_cost_k)
        return self.occupancy_ratio_ret

    def calc_occupancy_num(self):

        # 将剩余空间很大的服务器排到前面，
        # 将占用空间很大的服务器排到前面
        # 将价钱低的排到前面

        #占用空间
        cpu_occupancy_ratio_A = self.cpu_num_total - self.A_cpu_num_now
        mem_occupancy_ratio_A = self.mem_num_total - self.A_mem_num_now
        cpu_occupancy_ratio_B = self.cpu_num_total - self.B_cpu_num_now
        mem_occupancy_ratio_B = self.mem_num_total - self.B_mem_num_now

        score1 = self.A_cpu_num_now * migration_cpu_num_now_k + cpu_occupancy_ratio_A * migration_cpu_occupancy_ratio_k
        score2 = self.A_mem_num_now * migration_mem_num_now_k + mem_occupancy_ratio_A * migration_mem_occupancy_ratio_k
        score3 = self.B_cpu_num_now * migration_cpu_num_now_k + cpu_occupancy_ratio_B * migration_cpu_occupancy_ratio_k
        score4 = self.B_mem_num_now * migration_mem_num_now_k + mem_occupancy_ratio_B * migration_mem_occupancy_ratio_k

        score = score1 + score2 + score3 + score4

        return score + (-self.day_cost * calc_service_day_cost_k)

    def calc_score_dual(self, machine_cpu_num, machine_mem_num):
        # 根据消耗情况，重新计算服务器价值
        self.hardware_cost_now = self.hardware_cost_cpu_k * (self.A_cpu_num_now + self.B_cpu_num_now) + \
                                 self.hardware_cost_mem_k * (self.A_mem_num_now + self.B_mem_num_now) + \
                                 self.hardware_cost_b
        self.day_cost_now = self.day_cost_cpu_k * (self.A_cpu_num_now + self.B_cpu_num_now) + \
                            self.day_cost_mem_k * (self.A_mem_num_now + self.B_mem_num_now) + \
                            self.day_cost_b
        #
        cpu_ratio_now = machine_cpu_num / (self.A_cpu_num_now + self.B_cpu_num_now)  # cpu_num
        mem_ratio_now = machine_mem_num / (self.A_mem_num_now + self.B_mem_num_now)  # mem_num
        #
        score = (service_score_hardware_k * self.hardware_cost_now + service_score_day_k * self.day_cost_now) * \
                (service_score_cpu_k * cpu_ratio_now + service_score_mem_k * mem_ratio_now) * \
                (abs(math.log(machine_cpu_num / machine_mem_num) -
                     math.log((self.A_cpu_num_now + self.B_cpu_num_now) / (self.A_mem_num_now + self.B_mem_num_now))) +
                 service_machine_match_k)

        return score

    def calc_score_A(self, machine_cpu_num, machine_mem_num):
        # 根据消耗情况，重新计算服务器价值
        self.hardware_cost_now_A = self.hardware_cost_cpu_k * self.A_cpu_num_now + \
                                   self.hardware_cost_mem_k * self.A_mem_num_now + \
                                   self.hardware_cost_b
        self.day_cost_now_A = self.day_cost_cpu_k * self.A_cpu_num_now + \
                              self.day_cost_mem_k * self.A_mem_num_now + \
                              self.day_cost_b
        #
        cpu_ratio_now_A = machine_cpu_num / self.A_cpu_num_now  # cpu_num
        mem_ratio_now_A = machine_mem_num / self.A_mem_num_now  # mem_num
        #
        score = (service_score_hardware_k * self.hardware_cost_now_A + service_score_day_k * self.day_cost_now_A) * \
                (service_score_cpu_k * cpu_ratio_now_A + service_score_mem_k * mem_ratio_now_A) * \
                (abs(math.log(machine_cpu_num / machine_mem_num) - math.log(self.A_cpu_num_now / self.A_mem_num_now)) +
                 service_machine_match_k)

        return score

    def calc_score_B(self, machine_cpu_num, machine_mem_num):
        # 根据消耗情况，重新计算服务器价值
        self.hardware_cost_now_B = self.hardware_cost_cpu_k * self.B_cpu_num_now + \
                                   self.hardware_cost_mem_k * self.B_mem_num_now + \
                                   self.hardware_cost_b
        self.day_cost_now_B = self.day_cost_cpu_k * self.B_cpu_num_now + \
                              self.day_cost_mem_k * self.B_mem_num_now + \
                              self.day_cost_b
        #
        cpu_ratio_now_B = machine_cpu_num / self.B_cpu_num_now  # cpu_num
        mem_ratio_now_B = machine_mem_num / self.B_mem_num_now  # mem_num
        #
        score = (service_score_hardware_k * self.hardware_cost_now_B + service_score_day_k * self.day_cost_now_B) * \
                (service_score_cpu_k * cpu_ratio_now_B + service_score_mem_k * mem_ratio_now_B) * \
                (abs(math.log(machine_cpu_num / machine_mem_num) - math.log(self.B_cpu_num_now / self.B_mem_num_now)) +
                 service_machine_match_k)

        return score

    def __str__(self):
         str_show = 'service_id = ' + str(self.service_id) + \
               ' type = ' + self.type + '\n' + \
               'occupancy_ratio = ' + str(self.occupancy_ratio) + '\n' + \
               'A_cpu_num_total = ' + str(self.A_cpu_num_total) + '\n' + \
               'B_cpu_num_total = ' + str(self.B_cpu_num_total) + '\n' + \
               'A_mem_num_total = ' + str(self.A_mem_num_total) + '\n' + \
               'B_mem_num_total = ' + str(self.B_mem_num_total) + '\n' + \
               'A_cpu_num_now = ' + str(self.A_cpu_num_now) + '\n' + \
               'B_cpu_num_now = ' + str(self.B_cpu_num_now) + '\n' + \
               'A_mem_num_now = ' + str(self.A_mem_num_now) + '\n' + \
               'B_mem_num_now = ' + str(self.B_mem_num_now) + '\n' + \
               'hardware_cost = ' + str(self.hardware_cost) + '\n' + \
               'day_cost = ' + str(self.day_cost) + '\n'

         for machine_data in self.machine_list.values():
             str_show += machine_data.__str__() + '\n'
         return str_show


class MachineTypeData():
    def __init__(self, type, cpu_num, mem_num, dual_model):
        self.type = type
        self.cpu_num = cpu_num
        self.mem_num = mem_num
        # 计算总的cpu/mem
        self.ratio_cpu_mem = math.log(self.cpu_num / self.mem_num)
        self.dual_model = dual_model#0/1
        #
        self.hardware_cost = 0
        self.day_cost = 0

    # 按照比例系数计算价值
    def calc_cost(self):
        #手动系数
        self.hardware_cost = machine_hardware_cost_cpu_k * self.cpu_num + machine_hardware_cost_mem_k * self.mem_num
        self.day_cost = machine_day_cost_cpu_k * self.cpu_num + machine_day_cost_mem_k * self.mem_num


    def __str__(self):
        #type = vm0XO3F cpu_num = 2 mem_num = 125 dual_model = 0
        return 'type = ' + self.type + \
               ' cpu_num = ' + str(self.cpu_num) + \
               ' mem_num = ' + str(self.mem_num) + \
               ' dual_model = ' + str(self.dual_model) + \
               ' hardware_cost = ' + str(self.hardware_cost) + \
               ' day_cost = ' + str(self.day_cost)

class MachineData(MachineTypeData):
    def __init__(self, machine_type_data, machine_id, node, service_data):
        super(MachineData, self).__init__(machine_type_data.type,
                                          machine_type_data.cpu_num,
                                          machine_type_data.mem_num,
                                          machine_type_data.dual_model)
        #
        self.hardware_cost = machine_type_data.hardware_cost
        self.day_cost = machine_type_data.day_cost
        #
        self.node = node#N/A/B
        # 被分配的 服务器地址, 使用这个进行寻址
        self.service_data = service_data
        #
        self.machine_id = machine_id
        # 组合的虚拟机列表
        self.combine_machine_list = []

    def try_combine(self, cpu_num, mem_num, target_ratio):
        ratio_diff_before = abs(self.ratio_cpu_mem - target_ratio)
        ratio_diff_after = abs(math.log((self.cpu_num + cpu_num) / (self.mem_num + mem_num)) - target_ratio)

        #ratio_diff越小越好
        #返回融合新的虚拟机，会不会使得这个虚拟机的cpu/mem的比值更接近目标值
        return ratio_diff_after < ratio_diff_before

    #组合多个虚拟机的函数
    def combine(self, machine_data):
        # 记录合并的虚拟机
        self.combine_machine_list.append(machine_data)
        #修改新的虚拟机信息
        self.cpu_num += machine_data.cpu_num
        self.mem_num += machine_data.mem_num
        #更新cpu/mem和hardware_cost，day_cost
        self.ratio_cpu_mem = math.log(self.cpu_num / self.mem_num)
        self.calc_cost()

    def de_combine_one(self):
        machine_data = self.combine_machine_list[-1]
        # 修改新的虚拟机信息
        self.cpu_num -= machine_data.cpu_num
        self.mem_num -= machine_data.mem_num
        # 更新cpu/mem和hardware_cost，day_cost
        self.ratio_cpu_mem = math.log(self.cpu_num / self.mem_num)
        self.calc_cost()
        del self.combine_machine_list[-1]

        #返回解除占用的虚拟机
        return machine_data

    #解除组合,返回被释放的虚拟机
    def de_combine(self):
        for machine_data in self.combine_machine_list:
            # 修改新的虚拟机信息
            self.cpu_num -= machine_data.cpu_num
            self.mem_num -= machine_data.mem_num
        # 更新cpu/mem和hardware_cost，day_cost
        self.ratio_cpu_mem = math.log(self.cpu_num / self.mem_num)
        self.calc_cost()
        # 清空，组合的虚拟机列表
        self.combine_machine_list = []

    def __str__(self):
        if self.service_data is None:
            return 'machine_id = ' + str(self.machine_id) + \
                   ' type = ' + self.type + \
                   ' cpu_num = ' + str(self.cpu_num) + \
                   ' mem_num = ' + str(self.mem_num) + \
                   ' dual_model = ' + str(self.dual_model) + \
                   ' hardware_cost = ' + str(self.hardware_cost) + \
                   ' day_cost = ' + str(self.day_cost)
        else:
            return 'machine_id = ' + str(self.machine_id) + \
                   ' type = ' + self.type + \
                   ' cpu_num = ' + str(self.cpu_num) + \
                   ' mem_num = ' + str(self.mem_num) + \
                   ' dual_model = ' + str(self.dual_model) + \
                   ' hardware_cost = ' + str(self.hardware_cost) + \
                   ' day_cost = ' + str(self.day_cost) + \
                   ' node = ' + self.node + \
                   ' service_data.service_id = ' + str(self.service_data.service_id) + \
                   ' service_data.type = ' + self.service_data.type


class Constant():
    def __init__(self):
        #服务器类型数量
        self.service_type_num = 0
        #服务器类型信息,key=service_type,value=service_type_data
        self.service_type_data = OrderedDict()
        #虚拟机类型数量
        self.machine_type_num = 0
        # 虚拟机类型信息,key=machine_type,value=machine_type_data
        self.machine_type_data = OrderedDict()
        #读取总共多少天
        self.total_day = 0
        #现在是第几天
        self.day_now = 0
        #向前看多少天
        self.forward_look_k = 0
        #--------------优化部分--------------
        #1.计算对于每一个虚拟机，对应可行的服务器。
        self.feasible_services = OrderedDict()
        #提前计算好，用于后续的背包问题
        self.service_cpu_cap_dual = []
        self.service_mem_cap_dual = []
        self.service_values_dual = []
        # 提前计算好，用于后续的背包问题
        self.service_cpu_cap_A = []
        self.service_mem_cap_A = []
        self.service_values_A = []
        # 提前计算好，用于后续的背包问题
        self.service_cpu_cap_B = []
        self.service_mem_cap_B = []
        self.service_values_B = []

    #输出数据序列，和触发新列表的最小值
    def calc_classify(self, num_list):
        assign_class = []
        class_now = 0
        num_index = 0
        num_last = num_list[0]
        while num_index < len(num_list):
            num = num_list[num_index]
            num_index += 1
            # 判断是否出现跳变，需要满足触发最小值
            if num_last == 0 and num >= 1 and num_list[min(num_index, len(num_list)-1)] >= 1: class_now += 1
            # 保存类别
            assign_class.append(class_now)
            # 保存下次使用
            num_last = num

        return assign_class

    def service_classification(self):
        #首先将服务器类型数据，对day_cost/hardware_cost进行归10化，并且，只取比值为0的服务器，其它服务器直接去除
        ratio_max = -1000000
        ratio_min = 1000000
        for service_type_data in self.service_type_data.values():
            if service_type_data.ratio_day_cost_hardware_cost > ratio_max:
                ratio_max = service_type_data.ratio_day_cost_hardware_cost
            if service_type_data.ratio_day_cost_hardware_cost < ratio_min:
                ratio_min = service_type_data.ratio_day_cost_hardware_cost
        #对变量进行归100化[0,100]
        for service_type_data in self.service_type_data.values():
            temp = service_type_data.ratio_day_cost_hardware_cost
            temp = temp - ratio_min
            temp = temp / (ratio_max - ratio_min)
            temp = int(temp * 100)
            service_type_data.ratio_day_cost_hardware_cost_norm100 = temp
        #统计到列表中
        service_type_data_list = []
        for service_type in self.service_type_data.keys():
            service_type_data_list.append([self.service_type_data[service_type],
                                           self.service_type_data[service_type].ratio_day_cost_hardware_cost_norm100])
        #按照最后一个分数进行排名，升序排名
        service_type_data_list = sorted(service_type_data_list, key=lambda data: data[1])
        #统计从0-100的服务器个数
        service_type_num = OrderedDict()
        #首先创建全空的值
        for i in range(101): service_type_num[i] = 0
        #开始遍历循环
        for service_type_data in service_type_data_list:
            service_type_num[service_type_data[1]] += 1
        #统计分类,索引值是比例，对应的值是分类
        assign_class = self.calc_classify(list(service_type_num.values()))
        #开始指定类别
        for service_type_data in service_type_data_list:
            #服务器属于0-100中的哪一个
            service_type_data[0].class_belong = assign_class[service_type_data[0].ratio_day_cost_hardware_cost_norm100]
            #保存总共有多少类，因为类别是从0开始计数的，所以这里要+1
            service_type_data[0].class_max = assign_class[-1] + 1


    #将一些常数提前计算好
    def calc_constant(self):
        for service_type_data in self.service_type_data.values():
            #dual
            self.service_cpu_cap_dual.append(service_type_data.cpu_num_total)
            self.service_mem_cap_dual.append(service_type_data.mem_num_total)
            self.service_values_dual.append(service_type_data.hardware_cost)#暂时只是用hardware_cost
            #A
            self.service_cpu_cap_A.append(service_type_data.A_cpu_num_total)
            self.service_mem_cap_A.append(service_type_data.A_mem_num_total)
            self.service_values_A.append(service_type_data.hardware_cost_A)
            #B
            self.service_cpu_cap_B.append(service_type_data.B_cpu_num_total)
            self.service_mem_cap_B.append(service_type_data.B_mem_num_total)
            self.service_values_B.append(service_type_data.hardware_cost_B)

    def linear_regression_lib(self, x, y):
        # 导入矩阵计算库
        from MatrixOperation import transpose_matrix, multiply_matrices, calculate_inverse
        #线性回归系数计算
        x_t = transpose_matrix(x)
        temp = multiply_matrices(x_t, x)
        temp = calculate_inverse(temp)
        temp = multiply_matrices(temp, x_t)
        theta = multiply_matrices(temp, y)

        #返回计算的系数
        return theta

    #通过回归分析，拟合服务器费用和cpu/mem的关系
    def calc_linear_regression(self):

        #服务器按照day_cost/hardware_cost分为了几类，要分别为每一个列表计算对应的回归系数
        #首先获取总共有多少类别
        service_class_max = list(self.service_type_data.values())[0].class_max
        service_class_num = OrderedDict()
        for service_class in range(service_class_max):
            service_class_num[service_class] = 0
        #首先统计每种类别服务器的个数
        for service_type_data in self.service_type_data.values():
            service_class_num[service_type_data.class_belong] += 1
        #对不同类别的服务器，分别计算回归系数
        for service_class in range(service_class_max):
            x = [[1, 1, 1] for _ in range(service_class_num[service_class])]
            y = [[1, 1] for _ in range(service_class_num[service_class])]
            index = 0
            for service_type_data in self.service_type_data.values():
                if service_type_data.class_belong == service_class:
                    x[index][0] = service_type_data.cpu_num_total
                    x[index][1] = service_type_data.mem_num_total
                    y[index][0] = service_type_data.hardware_cost
                    y[index][1] = service_type_data.day_cost
                    index += 1
            #回归计算
            theta = self.linear_regression_lib(x, y)
            #取出系数
            hardware_cost_cpu_k = theta[0][0]
            hardware_cost_mem_k = theta[1][0]
            hardware_cost_b = theta[2][0]
            #
            day_cost_cpu_k = theta[0][1]
            day_cost_mem_k = theta[1][1]
            day_cost_b = theta[2][1]
            #给服务器变量赋值
            for service_type_data in self.service_type_data.values():
                if service_type_data.class_belong == service_class:
                    # 通过线性回归算法，拟合，硬件成本和day成本的计算公式的系数，总共6个系数
                    service_type_data.hardware_cost_cpu_k = hardware_cost_cpu_k
                    service_type_data.hardware_cost_mem_k = hardware_cost_mem_k
                    service_type_data.hardware_cost_b = hardware_cost_b
                    service_type_data.day_cost_cpu_k = day_cost_cpu_k
                    service_type_data.day_cost_mem_k = day_cost_mem_k
                    service_type_data.day_cost_b = day_cost_b
                    #更新价值
                    service_type_data.calc_cost()
            #赋值结束
        # 给虚拟机变量赋值
        for machine_type_data in self.machine_type_data.values():
            # 更新价值
            machine_type_data.calc_cost()


