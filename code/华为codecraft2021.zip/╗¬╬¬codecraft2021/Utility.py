
from Utility_judge import is_required_dual_model_old, \
    is_required_single_model_two_old, \
    is_required_dual_model_new, \
    is_required_single_model_new, \
    is_error
from Knapsack import Knapsack_single_value, Knapsack_dual_value
from collections import OrderedDict
from Constant import ServiceData
from Parameter import machine_price_b, \
    feasible_solution_len_max, \
    service_occupancy_ratio_max_backward, service_occupancy_ratio_max_forward, \
    service_day_cost_divide_k, \
    service_migration_cpu_k, service_migration_mem_k

#将虚拟机分配到服务器上
def assign_machine_to_service(service_data, service_node, machine_his_dict, machine_data):

    # 判断这个虚拟机有没有和别的虚拟机进行合并，如果合并，那么一起修改
    if len(machine_data.combine_machine_list) > 0:
        for machine_data_temp in machine_data.combine_machine_list:
            # 修改服务器占用信息
            if service_node == 'N':
                service_data.A_cpu_num_now -= int(machine_data_temp.cpu_num / 2)
                service_data.B_cpu_num_now -= int(machine_data_temp.cpu_num / 2)
                service_data.A_mem_num_now -= int(machine_data_temp.mem_num / 2)
                service_data.B_mem_num_now -= int(machine_data_temp.mem_num / 2)
            elif service_node == 'A':
                service_data.A_cpu_num_now -= machine_data_temp.cpu_num
                service_data.A_mem_num_now -= machine_data_temp.mem_num
            else:
                service_data.B_cpu_num_now -= machine_data_temp.cpu_num
                service_data.B_mem_num_now -= machine_data_temp.mem_num

            # 修改虚拟机节点
            machine_data_temp.node = service_node
            # 修改虚拟机对应的服务器
            machine_data_temp.service_data = service_data
            # 同时将这个虚拟机保存到服务器中
            service_data.machine_list[machine_data_temp.machine_id] = machine_data_temp
            # 保存虚拟机到总列表中
            machine_his_dict[machine_data_temp.machine_id] = machine_data_temp
        #解除合并
        machine_data.de_combine()

    # 修改服务器占用信息
    if service_node == 'N':
        service_data.A_cpu_num_now -= int(machine_data.cpu_num / 2)
        service_data.B_cpu_num_now -= int(machine_data.cpu_num / 2)
        service_data.A_mem_num_now -= int(machine_data.mem_num / 2)
        service_data.B_mem_num_now -= int(machine_data.mem_num / 2)
    elif service_node == 'A':
        service_data.A_cpu_num_now -= machine_data.cpu_num
        service_data.A_mem_num_now -= machine_data.mem_num
    else:
        service_data.B_cpu_num_now -= machine_data.cpu_num
        service_data.B_mem_num_now -= machine_data.mem_num

    # 修改虚拟机节点
    machine_data.node = service_node
    # 修改虚拟机对应的服务器
    machine_data.service_data = service_data
    # 同时将这个虚拟机保存到服务器中
    service_data.machine_list[machine_data.machine_id] = machine_data
    # 保存虚拟机到总列表中
    machine_his_dict[machine_data.machine_id] = machine_data

    # 判断是否超过
    if is_error(service_data): raise ValueError('service_data error')

# 从历史的服务器中查找，看能不能将虚拟机分配到上面，如果可以，那么返回服务器地址
def search_old_service(service_his_dict, machine_data):
    # 对于单节点和双节点的虚拟机判断在最外面
    if machine_data.dual_model == 1:
        # 首先遍历一遍，计算所有符合要求的服务器的cpu/mem比
        service_ratio_data_list = []
        for service_data in service_his_dict[1]:
            # 判断CPU和MEM是不是同时满足要求
            ret = is_required_dual_model_old(service_data, machine_data)
            if ret:
                # 将可行的服务器组成一个列表
                service_ratio_data_list.append([service_data,
                                                service_data.calc_score_dual(machine_data.cpu_num, machine_data.mem_num)])
                # 加上退出条件
                if len(service_ratio_data_list) > feasible_solution_len_max: break
        # 按照diff进行升序排序
        # 按照性价比权重进行不减的排序 # [服务器,差值]
        service_ratio_data_list = sorted(service_ratio_data_list, key=lambda data: data[1])
        # 取最小的，将虚拟机放到服务器中
        if len(service_ratio_data_list) > 0: return service_ratio_data_list[0][0], 'N'

    else:
        # 首先遍历一遍，计算所有符合要求的服务器的cpu/mem比
        service_ratio_data_list = []
        for service_data in service_his_dict[0]:
            # 在这里进行判断的时候，优先判断的是A节点
            A_ret, B_ret = is_required_single_model_two_old(service_data, machine_data)
            if A_ret:
                service_ratio_data_list.append([service_data, 'A',
                                                service_data.calc_score_A(machine_data.cpu_num, machine_data.mem_num)])
                # 加上退出条件
                if len(service_ratio_data_list) > feasible_solution_len_max: break
            if B_ret:
                service_ratio_data_list.append([service_data, 'B',
                                                service_data.calc_score_B(machine_data.cpu_num, machine_data.mem_num)])
                # 加上退出条件
                if len(service_ratio_data_list) > feasible_solution_len_max: break
        # 按照diff进行升序排序
        # 按照性价比权重进行不减的排序# [服务器,node,差值]
        service_ratio_data_list = sorted(service_ratio_data_list, key=lambda data: data[2])
        # 取最小的，将虚拟机放到服务器中
        if len(service_ratio_data_list) > 0: return service_ratio_data_list[0][0], service_ratio_data_list[0][1]

    # 最后全部返回为空
    return None, None

# 将虚拟机放到旧的服务器中，True代表放进去了
def add_old_service(service_his_dict, machine_his_dict, machine_data):
    # 尝试将虚拟机放到已有的服务器中
    # 首先看已有的服务器是否能方向虚拟机，如果可以，返回服务器索引，和对应的节点
    service_data, service_node = search_old_service(service_his_dict, machine_data)
    # 如果可以放到，那么修改服务器占用信息
    if service_data is not None:
        assign_machine_to_service(service_data, service_node, machine_his_dict, machine_data)
        return True
    #
    return False

#搜索空闲的服务器，作为新服务器，重新添加
def search_exist_new_service(constant, exist_new_service, machine_data):
    feasible_services_score_list = []
    #循环所有的服务器
    for service_index, service_data in enumerate(exist_new_service):
        ret = False
        if machine_data.dual_model == 1:
            ret = is_required_dual_model_new(service_data, machine_data)
        else:
            ret = is_required_single_model_new(service_data, machine_data)
        if ret:
            score = service_data.calc_score(machine_data.cpu_num, machine_data.mem_num, constant.day_now, constant.total_day)
            feasible_services_score_list.append([service_index, score])
    #判断有没有可行的服务器
    if len(feasible_services_score_list) > 0:
        #按照score升序排序
        feasible_services_score_list = sorted(feasible_services_score_list, key=lambda data: data[1])
        #取出分数最小的服务器
        service_index = feasible_services_score_list[0][0]
        service_node = 'N' if machine_data.dual_model == 1 else 'A'

        # 返回结果
        return service_index, service_node
    else:
        return None, None

# 从服务器类型中查找，如果可以，那么返回服务器类型，和对应的节点
def search_new_service(constant, machine_data):
    # 原来这块所有的服务器的分数都是提前算好的，现在因为要用到动态参数了，所以要每次计算一遍
    # feasible_services = constant.feasible_services[machine_data.type]
    feasible_services_score_list = []
    # 循环所有可行的服务器，并计算分数，如果要组合虚拟机，那么这里需要修改
    # 循环所有的服务器，并判断是否可行，
    for service_type_data in constant.service_type_data.values():
        ret = False
        if machine_data.dual_model == 1:
            ret = is_required_dual_model_new(service_type_data, machine_data)
        else:
            ret = is_required_single_model_new(service_type_data, machine_data)
        if ret:
            score = service_type_data.calc_score(machine_data.cpu_num, machine_data.mem_num, constant.day_now, constant.total_day)
            feasible_services_score_list.append([service_type_data, score])
    #判断有没有可行的服务器
    if len(feasible_services_score_list) > 0:
        #按照score升序排序
        feasible_services_score_list = sorted(feasible_services_score_list, key=lambda data: data[1])
        #取出分数最小的服务器
        service_type_data = feasible_services_score_list[0][0]
        service_node = 'N' if machine_data.dual_model == 1 else 'A'

        # 返回结果
        return service_type_data, service_node
    else:
        return None, None

# 分配虚拟机，所有已有服务器信息，新购买服务器信息，最新一个的虚拟机信息
def add_machine(constant, service_his_dict, machine_his_dict, machine_data):
    is_buy_service = False
    # 首先看已有的服务器是否能方向虚拟机，如果可以，返回服务器索引
    service_data, service_node = search_old_service(service_his_dict, machine_data)
    # 如果可以分配，直接分配，否则购买
    if service_data is None:
        # 首先尝试搜索空闲的服务器，传入空闲的服务器列表
        service_index, service_node = search_exist_new_service(constant, service_his_dict[-1], machine_data)
        if service_index is not None:
            service_data = service_his_dict[-1][service_index]
            #将服务器从空闲列表中移除
            del service_his_dict[-1][service_index]
            # 将虚拟机分配到服务器中
            if service_node == 'N':
                # 添加到双节点列表中
                service_his_dict[1].append(service_data)
            else:
                # 添加到单节点列表中
                service_his_dict[0].append(service_data)
        else:
            # 开始购买服务器，按照性价比排序，购买服务器
            service_type_data, service_node = search_new_service(constant, machine_data)

            if service_type_data is not None:
                # 首先购买服务器
                service_data = ServiceData(service_type_data, None)  # 暂时未分配service_id
                is_buy_service = True
                # 将虚拟机分配到服务器中
                if service_node == 'N':
                    # 添加到双节点列表中
                    service_his_dict[1].append(service_data)
                else:
                    # 添加到单节点列表中
                    service_his_dict[0].append(service_data)

    if service_data is not None:
        # 修改服务器占用信息
        assign_machine_to_service(service_data, service_node, machine_his_dict, machine_data)

        # 判断是否超过
        if is_error(service_data): raise ValueError('service_data error')

    return is_buy_service, service_data

# 删除虚拟机
def del_machine(machine_his_dict, machine_id):
    machine_data = machine_his_dict[machine_id]
    service_data = machine_data.service_data
    # 判断是不是dual model
    if machine_data.dual_model == 1:
        service_data.A_cpu_num_now += int(machine_data.cpu_num / 2)
        service_data.B_cpu_num_now += int(machine_data.cpu_num / 2)
        service_data.A_mem_num_now += int(machine_data.mem_num / 2)
        service_data.B_mem_num_now += int(machine_data.mem_num / 2)
    elif machine_data.node == 'A':
        service_data.A_cpu_num_now += machine_data.cpu_num
        service_data.A_mem_num_now += machine_data.mem_num
    else:
        service_data.B_cpu_num_now += machine_data.cpu_num
        service_data.B_mem_num_now += machine_data.mem_num

    # 首先删除服务器中的虚拟机信息
    del service_data.machine_list[machine_id]
    # 删除总列表中的虚拟机
    del machine_his_dict[machine_id]

# 服务器型号转换，返回一个转换表
def assign_service_id(old_service_his_len, service_his_dict_new_list):
    # 首先统计总共有多少种类型的服务器，并且每种数量多少
    # 首先统计,总共有多少种类型服务器,key是名字，value是数量,有序
    service_type_num = OrderedDict()
    for service_data in service_his_dict_new_list:
        if service_data.type not in service_type_num.keys(): service_type_num[service_data.type] = 0
        # 数量加1
        service_type_num[service_data.type] += 1
    service_id = old_service_his_len
    service_id_array = OrderedDict()
    for key in service_type_num.keys():
        # key是名字,value是一系列新的有顺序的索引值
        service_id_array[key] = []
        for i in range(service_type_num[key]):
            service_id_array[key].append(service_id)
            # 需要记住的是，从0开始
            service_id += 1
    # 开始给服务器分配id

    # service_id_array = OrderedDict([('hostKOIXN', [0, 1]), ('hostMQODP', [2, 3]), ('host1V93K', [4, 5]), ('host3NX39', [6, 7]), ('hostGN1W1', [8]), ('host6CFNF', [9]), ('hostNF877', [10]), ('hostRL1N7', [11, 12]), ('hostZ02XR', [13]), ('hostRPJ1E', [14])])
    for service_data in service_his_dict_new_list:
        # 分配id
        service_data.service_id = service_id_array[service_data.type][0]
        # 分配后删除
        del service_id_array[service_data.type][0]

    return service_type_num

# 一旦检测到需要迁移的虚拟机，必须马上迁移，修改服务器占用，否则可能会重复迁移
def do_migration(machine_migration_list):
    if len(machine_migration_list) <= 0: return
    for migration_data in machine_migration_list:
        machine_data = migration_data[0]
        service_data_backward = migration_data[1]
        service_data_forward = migration_data[2]
        service_node_forward = migration_data[3]

        # 将虚拟机从旧的服务器中删除
        # 判断是不是dual model
        if machine_data.node == 'N':
            service_data_backward.A_cpu_num_now += int(machine_data.cpu_num / 2)
            service_data_backward.B_cpu_num_now += int(machine_data.cpu_num / 2)
            service_data_backward.A_mem_num_now += int(machine_data.mem_num / 2)
            service_data_backward.B_mem_num_now += int(machine_data.mem_num / 2)
        elif machine_data.node == 'A':
            service_data_backward.A_cpu_num_now += machine_data.cpu_num
            service_data_backward.A_mem_num_now += machine_data.mem_num
        elif machine_data.node == 'B':
            service_data_backward.B_cpu_num_now += machine_data.cpu_num
            service_data_backward.B_mem_num_now += machine_data.mem_num
        else:
            raise ValueError('service_data_backward error')

        # 首先删除服务器中的虚拟机信息, 这块花费了很多时间
        del service_data_backward.machine_list[machine_data.machine_id]

        # 将虚拟机分配到新的服务器中 service_data_forward
        # 修改服务器占用信息
        if service_node_forward == 'N':
            service_data_forward.A_cpu_num_now -= int(machine_data.cpu_num / 2)
            service_data_forward.B_cpu_num_now -= int(machine_data.cpu_num / 2)
            service_data_forward.A_mem_num_now -= int(machine_data.mem_num / 2)
            service_data_forward.B_mem_num_now -= int(machine_data.mem_num / 2)
        elif service_node_forward == 'A':
            service_data_forward.A_cpu_num_now -= machine_data.cpu_num
            service_data_forward.A_mem_num_now -= machine_data.mem_num
        elif service_node_forward == 'B':
            service_data_forward.B_cpu_num_now -= machine_data.cpu_num
            service_data_forward.B_mem_num_now -= machine_data.mem_num
        else:
            raise ValueError('service_node_forward error')

        # 修改虚拟机节点
        machine_data.node = service_node_forward
        # 修改虚拟机对应的服务器
        machine_data.service_data = service_data_forward
        # 同时将这个虚拟机保存到服务器中
        service_data_forward.machine_list[machine_data.machine_id] = machine_data

        # 判断是否超过
        if is_error(service_data_forward): raise ValueError('service_data error')

# 迁移虚拟机
def update_migration(migration_len_max, service_his_dict):
    #分别代表单双节点
    service_his_dict_new = [set(), set()]
    # 用来保存所有迁移的数据
    machine_migration_list = []
    # 现在有的是，旧的服务器信息 self.service_his_dict，旧的虚拟机信息 self.machine_his_dict
    # 数量不够，不迁移，返回空列表,是否因为超过最大迁移限制，而返回
    if migration_len_max <= 0: return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True

    # 单节点，在服务器数量大于等于2的情况下，才做迁移
    if len(service_his_dict[0]) >= 2:
        # 首先对服务器，按照占用比例进行排序，降序排序, calc_occupancy_ratio_single 改完之后，效果不好
        service_his_dict_0 = sorted(service_his_dict[0], key=lambda data: data.calc_occupancy_ratio(), reverse=True)
        service_his_dict_0 = [service_data for service_data in service_his_dict_0
                              if service_data.occupancy_ratio <= service_occupancy_ratio_max_forward]
        #满足条件的服务器不能太少
        if len(service_his_dict_0) >= 2:
            # 对排序后的服务器进行遍历，统计得到cpu和mem的数量，用于下面
            service_his_dict_0_cpu_num_A = []
            service_his_dict_0_mem_num_A = []
            service_his_dict_0_cpu_num_B = []
            service_his_dict_0_mem_num_B = []
            service_his_dict_0_occupancy_ratio = []
            for service_data in service_his_dict_0:
                service_his_dict_0_cpu_num_A.append(service_data.A_cpu_num_now)
                service_his_dict_0_mem_num_A.append(service_data.A_mem_num_now)
                service_his_dict_0_cpu_num_B.append(service_data.B_cpu_num_now)
                service_his_dict_0_mem_num_B.append(service_data.B_mem_num_now)
                service_his_dict_0_occupancy_ratio.append(service_data.occupancy_ratio)
            # 尝试将结尾的利用率低的服务器中的虚拟机，放到开够的利用率高的服务器中
            for service_index_backward in range(len(service_his_dict_0) - 1, -1, -1):
                service_data_backward = service_his_dict_0[service_index_backward]
                # 如果利用率很高，那么不迁移，直接退出循环，只是本次循环不做了
                if service_his_dict_0_occupancy_ratio[service_index_backward] >= service_occupancy_ratio_max_backward: continue
                # 取出这个服务器中存储的虚拟机列表数据
                # 对虚拟机按大小进行排序，降序排序，这块day_cost是使用服务器的回归系数计算出来的
                machine_data_list = sorted(list(service_data_backward.machine_list.values()), key=lambda data: data.day_cost, reverse=True)
                # for machine_data in service_data_backward.machine_list.values():
                for machine_data in machine_data_list:
                    # 对所有的前面服务器做循环，从前向后索引，一旦找到可以放的服务器，那么退出循环 # 最起码不能索引到自己身上
                    # 首先将所有可信的服务器收集起来，其次将排序，去最优的服务器进行迁移
                    service_data_forward_list = []
                    for service_index_forward in range(service_index_backward):
                        # 不能超过最大迁移个数，否则直接返回
                        if len(machine_migration_list) >= migration_len_max:
                            return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True
                        # 判断能不能放进去,如果可以放进去，返回对应的节点
                        A_ret = (machine_data.cpu_num <= service_his_dict_0_cpu_num_A[service_index_forward] and
                                 machine_data.mem_num <= service_his_dict_0_mem_num_A[service_index_forward])
                        B_ret = (machine_data.cpu_num <= service_his_dict_0_cpu_num_B[service_index_forward] and
                                 machine_data.mem_num <= service_his_dict_0_mem_num_B[service_index_forward])
                        #按照，虚拟机的利用率排名，并且还有区分节点
                        # 占用率越高越好，费用越低越好，越好，越容易执行迁移
                        if A_ret:
                            score = service_migration_cpu_k * service_his_dict_0[service_index_forward].A_cpu_num_now + \
                                    service_migration_mem_k * service_his_dict_0[service_index_forward].A_mem_num_now - \
                                    (service_his_dict_0[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, 'A', score])
                        if B_ret:
                            score = service_migration_cpu_k * service_his_dict_0[service_index_forward].B_cpu_num_now + \
                                    service_migration_mem_k * service_his_dict_0[service_index_forward].B_mem_num_now - \
                                    (service_his_dict_0[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, 'B', score])
                    # 如果有可行解，那么通过排序，找到最好的可行解
                    if len(service_data_forward_list) > 0:
                        # 对所有可行的服务器进行排序，升序排序，也就是，向cpu/mem剩余少的服务器迁移，向钱钱多的服务器迁移，
                        service_data_forward_list = sorted(service_data_forward_list, key=lambda data: data[2])#
                        # 取出排名最低的服务器进行迁移
                        service_index_forward = service_data_forward_list[0][0]
                        service_data_forward = service_his_dict_0[service_index_forward]
                        service_node_forward = service_data_forward_list[0][1]
                        # 更新表格数据
                        # 首先从 service_data_backward 中取出来，节点数据在 machine_data.node
                        if machine_data.node == 'A':
                            service_his_dict_0_cpu_num_A[service_index_backward] += machine_data.cpu_num
                            service_his_dict_0_mem_num_A[service_index_backward] += machine_data.mem_num
                        else:
                            service_his_dict_0_cpu_num_B[service_index_backward] += machine_data.cpu_num
                            service_his_dict_0_mem_num_B[service_index_backward] += machine_data.mem_num
                        #
                        if service_node_forward == 'A':
                            # 更新表格数据
                            # 从 service_index_forward 放进去
                            service_his_dict_0_cpu_num_A[service_index_forward] -= machine_data.cpu_num
                            service_his_dict_0_mem_num_A[service_index_forward] -= machine_data.mem_num
                            # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                            migration_data = [machine_data, service_data_backward, service_data_forward, 'A']
                            machine_migration_list.append(migration_data)
                            #将迁出虚拟机的服务器记录下来
                            service_his_dict_new[0].add(service_data_backward)
                        else:
                            # 更新表格数据
                            service_his_dict_0_cpu_num_B[service_index_forward] -= machine_data.cpu_num
                            service_his_dict_0_mem_num_B[service_index_forward] -= machine_data.mem_num
                            # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                            migration_data = [machine_data, service_data_backward, service_data_forward, 'B']
                            machine_migration_list.append(migration_data)
                            # 将迁出虚拟机的服务器记录下来
                            service_his_dict_new[0].add(service_data_backward)

    # 双节点，在服务器数量大于等于2的情况下，才做迁移
    if len(service_his_dict[1]) >= 2:
        # 在服务器数量大于等于2的情况下，才做迁移
        service_his_dict_1 = sorted(service_his_dict[1], key=lambda data: data.calc_occupancy_ratio(), reverse=True)
        service_his_dict_1 = [service_data for service_data in service_his_dict_1
                              if service_data.occupancy_ratio <= service_occupancy_ratio_max_forward]
        # 满足条件的服务器不能太少
        if len(service_his_dict_1) >= 2:
            # 对排序后的服务器进行遍历，
            # 对排序后的服务器进行遍历，统计得到cpu和mem的数量，用于下面
            service_his_dict_1_cpu_num = []
            service_his_dict_1_mem_num = []
            service_his_dict_1_occupancy_ratio = []
            for service_data in service_his_dict_1:
                service_his_dict_1_cpu_num.append(service_data.A_cpu_num_now + service_data.B_cpu_num_now)
                service_his_dict_1_mem_num.append(service_data.A_mem_num_now + service_data.B_mem_num_now)
                service_his_dict_1_occupancy_ratio.append(service_data.occupancy_ratio)
            # 尝试将结尾的利用率低的服务器中的虚拟机，放到开够的利用率高的服务器中
            for service_index_backward in range(len(service_his_dict_1) - 1, -1, -1):
                service_data_backward = service_his_dict_1[service_index_backward]
                # 如果利用率很高，那么不迁移，直接退出循环，只是本次循环不做了
                if service_his_dict_1_occupancy_ratio[service_index_backward] >= service_occupancy_ratio_max_backward: continue
                # 取出这个服务器中存储的虚拟机列表数据
                # 对虚拟机按大小进行排序，降序排序，这块day_cost是使用服务器的回归系数计算出来的
                machine_data_list = sorted(list(service_data_backward.machine_list.values()), key=lambda data: data.day_cost, reverse=True)
                # for machine_data in service_data_backward.machine_list.values():
                for machine_data in machine_data_list:
                    # 对所有的前面服务器做循环，从前向后索引，一旦找到可以放的服务器，那么退出循环 # 最起码不能索引到自己身上
                    # 首先将所有可信的服务器收集起来，其次将排序，去最优的服务器进行迁移
                    service_data_forward_list = []
                    for service_index_forward in range(service_index_backward):
                        # 不能超过最大迁移个数，否则直接返回
                        if len(machine_migration_list) >= migration_len_max:
                            return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True
                        # 判断能不能放进去,如果可以放进去，返回对应的节点
                        ret = (machine_data.cpu_num <= service_his_dict_1_cpu_num[service_index_forward] and
                               machine_data.mem_num <= service_his_dict_1_mem_num[service_index_forward])
                        if ret:
                            score = service_migration_cpu_k * service_his_dict_1[service_index_forward].A_cpu_num_now + \
                                    service_migration_cpu_k * service_his_dict_1[service_index_forward].B_cpu_num_now + \
                                    service_migration_mem_k * service_his_dict_1[service_index_forward].A_mem_num_now + \
                                    service_migration_mem_k * service_his_dict_1[service_index_forward].B_mem_num_now - \
                                    (service_his_dict_1[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, score])
                    # 如果有可行解，那么通过排序，找到最好的可行解
                    if len(service_data_forward_list) > 0:
                        # 对所有可行的服务器进行排序
                        service_data_forward_list = sorted(service_data_forward_list, key=lambda data: data[1])  # , reverse=True
                        # 取出排名最低的服务器进行迁移
                        service_index_forward = service_data_forward_list[0][0]
                        service_data_forward = service_his_dict_1[service_index_forward]
                        # 更新表格数据
                        # 首先从 service_data_backward 中取出来，节点数据在 machine_data.node
                        service_his_dict_1_cpu_num[service_index_backward] += machine_data.cpu_num
                        service_his_dict_1_mem_num[service_index_backward] += machine_data.mem_num
                        # 从 service_index_forward 放进去
                        service_his_dict_1_cpu_num[service_index_forward] -= machine_data.cpu_num
                        service_his_dict_1_mem_num[service_index_forward] -= machine_data.mem_num
                        # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                        migration_data = [machine_data, service_data_backward, service_data_forward, 'N']
                        machine_migration_list.append(migration_data)
                        # 将迁出虚拟机的服务器记录下来
                        service_his_dict_new[1].add(service_data_backward)

    # 返回迁移的虚拟机信息
    return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], False


# 迁移虚拟机
def update_migration_another(migration_len_max, service_his_dict):
    #分别代表单双节点
    service_his_dict_new = [set(), set()]
    # 用来保存所有迁移的数据
    machine_migration_list = []
    # 现在有的是，旧的服务器信息 self.service_his_dict，旧的虚拟机信息 self.machine_his_dict
    # 数量不够，不迁移，返回空列表,是否因为超过最大迁移限制，而返回
    if migration_len_max <= 0: return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True

    # 单节点，在服务器数量大于等于2的情况下，才做迁移
    if len(service_his_dict[0]) >= 2:
        # 首先对服务器，按照占用比例进行排序，降序排序
        service_his_dict_0 = sorted(service_his_dict[0], key=lambda data: data.calc_occupancy_num(), reverse=True)#
        #满足条件的服务器不能太少
        if len(service_his_dict_0) >= 2:
            # 对排序后的服务器进行遍历，统计得到cpu和mem的数量，用于下面
            service_his_dict_0_cpu_num_A = []
            service_his_dict_0_mem_num_A = []
            service_his_dict_0_cpu_num_B = []
            service_his_dict_0_mem_num_B = []
            for service_data in service_his_dict_0:
                service_his_dict_0_cpu_num_A.append(service_data.A_cpu_num_now)
                service_his_dict_0_mem_num_A.append(service_data.A_mem_num_now)
                service_his_dict_0_cpu_num_B.append(service_data.B_cpu_num_now)
                service_his_dict_0_mem_num_B.append(service_data.B_mem_num_now)
            # 尝试将结尾的利用率低的服务器中的虚拟机，放到开够的利用率高的服务器中
            for service_index_backward in range(len(service_his_dict_0) - 1, -1, -1):
                service_data_backward = service_his_dict_0[service_index_backward]
                # # 如果利用率很高，那么不迁移，直接退出循环
                # if service_his_dict_0_occupancy_ratio[service_index_backward] >= service_occupancy_ratio_max_backward: break
                # 取出这个服务器中存储的虚拟机列表数据
                # 对虚拟机按大小进行排序，降序排序，这块day_cost是使用服务器的回归系数计算出来的
                machine_data_list = sorted(list(service_data_backward.machine_list.values()), key=lambda data: data.day_cost, reverse=True)
                # for machine_data in service_data_backward.machine_list.values():
                for machine_data in machine_data_list:
                    # 对所有的前面服务器做循环，从前向后索引，一旦找到可以放的服务器，那么退出循环 # 最起码不能索引到自己身上
                    # 首先将所有可信的服务器收集起来，其次将排序，去最优的服务器进行迁移
                    service_data_forward_list = []
                    for service_index_forward in range(service_index_backward):
                        # 不能超过最大迁移个数，否则直接返回
                        if len(machine_migration_list) >= migration_len_max:
                            return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True
                        # 判断能不能放进去,如果可以放进去，返回对应的节点
                        A_ret = (machine_data.cpu_num <= service_his_dict_0_cpu_num_A[service_index_forward] and
                                 machine_data.mem_num <= service_his_dict_0_mem_num_A[service_index_forward])
                        B_ret = (machine_data.cpu_num <= service_his_dict_0_cpu_num_B[service_index_forward] and
                                 machine_data.mem_num <= service_his_dict_0_mem_num_B[service_index_forward])
                        #按照，虚拟机的利用率排名，并且还有区分节点
                        # 占用率越高越好，费用越低越好，越好，越容易执行迁移
                        if A_ret:
                            score = service_his_dict_0[service_index_forward].A_cpu_num_now + \
                                    service_his_dict_0[service_index_forward].A_mem_num_now - \
                                    (service_his_dict_0[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, 'A', score])
                        if B_ret:
                            score = service_his_dict_0[service_index_forward].B_cpu_num_now + \
                                    service_his_dict_0[service_index_forward].B_mem_num_now - \
                                    (service_his_dict_0[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, 'B', score])
                    # 如果有可行解，那么通过排序，找到最好的可行解
                    if len(service_data_forward_list) > 0:
                        # 对所有可行的服务器进行排序
                        service_data_forward_list = sorted(service_data_forward_list, key=lambda data: data[2])#
                        # 取出排名最低的服务器进行迁移
                        service_index_forward = service_data_forward_list[0][0]
                        service_data_forward = service_his_dict_0[service_index_forward]
                        service_node_forward = service_data_forward_list[0][1]
                        # 更新表格数据
                        # 首先从 service_data_backward 中取出来，节点数据在 machine_data.node
                        if machine_data.node == 'A':
                            service_his_dict_0_cpu_num_A[service_index_backward] += machine_data.cpu_num
                            service_his_dict_0_mem_num_A[service_index_backward] += machine_data.mem_num
                        else:
                            service_his_dict_0_cpu_num_B[service_index_backward] += machine_data.cpu_num
                            service_his_dict_0_mem_num_B[service_index_backward] += machine_data.mem_num
                        #
                        if service_node_forward == 'A':
                            # 更新表格数据
                            # 从 service_index_forward 放进去
                            service_his_dict_0_cpu_num_A[service_index_forward] -= machine_data.cpu_num
                            service_his_dict_0_mem_num_A[service_index_forward] -= machine_data.mem_num
                            # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                            migration_data = [machine_data, service_data_backward, service_data_forward, 'A']
                            machine_migration_list.append(migration_data)
                            #将迁出虚拟机的服务器记录下来
                            service_his_dict_new[0].add(service_data_backward)
                        else:
                            # 更新表格数据
                            service_his_dict_0_cpu_num_B[service_index_forward] -= machine_data.cpu_num
                            service_his_dict_0_mem_num_B[service_index_forward] -= machine_data.mem_num
                            # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                            migration_data = [machine_data, service_data_backward, service_data_forward, 'B']
                            machine_migration_list.append(migration_data)
                            # 将迁出虚拟机的服务器记录下来
                            service_his_dict_new[0].add(service_data_backward)

    # 双节点，在服务器数量大于等于2的情况下，才做迁移
    if len(service_his_dict[1]) >= 2:
        # 在服务器数量大于等于2的情况下，才做迁移
        service_his_dict_1 = sorted(service_his_dict[1], key=lambda data: data.calc_occupancy_num(), reverse=True)#
        # 满足条件的服务器不能太少
        if len(service_his_dict_1) >= 2:
            # 对排序后的服务器进行遍历，
            # 对排序后的服务器进行遍历，统计得到cpu和mem的数量，用于下面
            service_his_dict_1_cpu_num = []
            service_his_dict_1_mem_num = []
            for service_data in service_his_dict_1:
                service_his_dict_1_cpu_num.append(service_data.A_cpu_num_now + service_data.B_cpu_num_now)
                service_his_dict_1_mem_num.append(service_data.A_mem_num_now + service_data.B_mem_num_now)
            # 尝试将结尾的利用率低的服务器中的虚拟机，放到开够的利用率高的服务器中
            for service_index_backward in range(len(service_his_dict_1) - 1, -1, -1):
                service_data_backward = service_his_dict_1[service_index_backward]
                # # 如果利用率很高，那么不迁移，直接退出循环
                # if service_his_dict_1_occupancy_ratio[service_index_backward] >= service_occupancy_ratio_max_backward: break
                # 取出这个服务器中存储的虚拟机列表数据
                # 对虚拟机按大小进行排序，降序排序，这块day_cost是使用服务器的回归系数计算出来的
                machine_data_list = sorted(list(service_data_backward.machine_list.values()), key=lambda data: data.day_cost, reverse=True)
                # for machine_data in service_data_backward.machine_list.values():
                for machine_data in machine_data_list:
                    # 对所有的前面服务器做循环，从前向后索引，一旦找到可以放的服务器，那么退出循环 # 最起码不能索引到自己身上
                    # 首先将所有可信的服务器收集起来，其次将排序，去最优的服务器进行迁移
                    service_data_forward_list = []
                    for service_index_forward in range(service_index_backward):
                        # 不能超过最大迁移个数，否则直接返回
                        if len(machine_migration_list) >= migration_len_max:
                            return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], True
                        # 判断能不能放进去,如果可以放进去，返回对应的节点
                        ret = (machine_data.cpu_num <= service_his_dict_1_cpu_num[service_index_forward] and
                               machine_data.mem_num <= service_his_dict_1_mem_num[service_index_forward])
                        if ret:
                            score = service_his_dict_1[service_index_forward].A_cpu_num_now + \
                                    service_his_dict_1[service_index_forward].B_cpu_num_now + \
                                    service_his_dict_1[service_index_forward].A_mem_num_now + \
                                    service_his_dict_1[service_index_forward].B_mem_num_now - \
                                    (service_his_dict_1[service_index_forward].day_cost / service_day_cost_divide_k)
                            service_data_forward_list.append([service_index_forward, score])
                    # 如果有可行解，那么通过排序，找到最好的可行解
                    if len(service_data_forward_list) > 0:
                        # 对所有可行的服务器进行排序
                        service_data_forward_list = sorted(service_data_forward_list, key=lambda data: data[1])  # , reverse=True
                        # 取出排名最低的服务器进行迁移
                        service_index_forward = service_data_forward_list[0][0]
                        service_data_forward = service_his_dict_1[service_index_forward]
                        # 更新表格数据
                        # 首先从 service_data_backward 中取出来，节点数据在 machine_data.node
                        service_his_dict_1_cpu_num[service_index_backward] += machine_data.cpu_num
                        service_his_dict_1_mem_num[service_index_backward] += machine_data.mem_num
                        # 从 service_index_forward 放进去
                        service_his_dict_1_cpu_num[service_index_forward] -= machine_data.cpu_num
                        service_his_dict_1_mem_num[service_index_forward] -= machine_data.mem_num
                        # 保存，需要迁移的虚拟机数据，和原来在那个服务器上，和迁移到那个服务器上，需要转移的节点
                        migration_data = [machine_data, service_data_backward, service_data_forward, 'N']
                        machine_migration_list.append(migration_data)
                        # 将迁出虚拟机的服务器记录下来
                        service_his_dict_new[1].add(service_data_backward)

    # 返回迁移的虚拟机信息
    return machine_migration_list, [list(service_his_dict_new[0]), list(service_his_dict_new[1])], False

#再次迁移,将只有一个虚拟机的服务器关闭，迁移到，完全空的虚拟机中
def update_migration_fine(migration_len_max, service_his_dict_empty, service_machine_one_list):
    machine_migration_list = []
    if migration_len_max <= 0: return machine_migration_list

    #按照加起来最大的服务器
    service_his_dict_empty_new_cpu_large = []
    service_his_dict_empty_new_mem_large = []
    #
    for service_data in service_his_dict_empty:
        if service_data.cpu_num_total >= 400:
            service_his_dict_empty_new_cpu_large.append(service_data)
        if service_data.mem_num_total >= 400:
            service_his_dict_empty_new_mem_large.append(service_data)
    #按照比值排序
    service_his_dict_empty_new_cpu_large.sort(key=lambda data:data.cpu_num_total / data.mem_num_total, reverse=True)
    # 按照比值排序
    service_his_dict_empty_new_mem_large.sort(key=lambda data: data.mem_num_total / data.cpu_num_total, reverse=True)
    #只取一半长度
    machine_data_list_single = []
    machine_data_list_dual = []
    #单节点
    for service_data in service_machine_one_list[0]:
        machine_data_list_single.extend(list(service_data.machine_list.values()))
    #双节点
    for service_data in service_machine_one_list[1]:
        machine_data_list_dual.extend(list(service_data.machine_list.values()))




