#include "Angle/AccAlgorithm/accalgorithm.h"

ACCALGORITHM::ACCALGORITHM()
{
    this->UpdateT = 0.001f;
    this->UpdateHalfT = this->UpdateT/2.0f;
    this->Angle2Radian = (M_PI / 180.0f);
    this->Radian2Angle = (180.0f / M_PI);

    this->angleData.angleXTheta = 0;
    this->angleData.angleYGamma = 0;
    this->angleData.angleZPhi = 0;

    this->angleSaveData.angleXTheta = 0;
    this->angleSaveData.angleYGamma = 0;
    this->angleSaveData.angleZPhi = 0;
}

ACCALGORITHM::~ACCALGORITHM()
{

}

void ACCALGORITHM::Update(Mpu6050DataTypedef *mpu6050Data1, Mpu6050DataTypedef *mpu6050Data2)
{
    AccDataTypedef accNow = {mpu6050Data1->Mpu6050AccX, mpu6050Data1->Mpu6050AccY,
                             mpu6050Data1->Mpu6050AccZ, 0.0f};
    accNow.norm = sqrt(accNow.accX * accNow.accX + accNow.accY * accNow.accY + accNow.accZ * accNow.accZ);
    accNow.accX /= accNow.norm;
    accNow.accY /= accNow.norm;
    accNow.accZ /= accNow.norm;

    this->angleData.angleXTheta = atan2(accNow.accZ, accNow.accY) + M_PI_2;
    this->angleData.angleYGamma = atan2(accNow.accZ, accNow.accX) + M_PI_2;
    this->angleData.angleZPhi = atan2(accNow.accY, accNow.accX);

    this->angleSaveData.angleXTheta = this->angleData.angleXTheta * this->Radian2Angle;
    this->angleSaveData.angleYGamma = this->angleData.angleYGamma * this->Radian2Angle;
    this->angleSaveData.angleZPhi = this->angleData.angleZPhi * this->Radian2Angle;

}
