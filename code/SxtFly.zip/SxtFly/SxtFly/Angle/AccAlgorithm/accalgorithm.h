#ifndef ACCALGORITHM_H
#define ACCALGORITHM_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "math.h"

class ACCALGORITHM
{
public:
    ACCALGORITHM();
    ~ACCALGORITHM();

    void Update(Mpu6050DataTypedef * mpu6050Data1, Mpu6050DataTypedef * mpu6050Data2);

    AngleDataTypedef angleData;
    AngleDataTypedef angleSaveData;

    float UpdateT;
    float UpdateHalfT;

    float Radian2Angle;
    float Angle2Radian;

};

#endif // ACCALGORITHM_H
