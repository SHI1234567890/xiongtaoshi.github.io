#ifndef GYROALGORITHM_H
#define GYROALGORITHM_H

#include "Typedef/typedef.h"
#include "QDebug"

class GYROALGORITHM
{
public:
    GYROALGORITHM();
    ~GYROALGORITHM();

    void Update(Mpu6050DataTypedef * mpu6050Data1, Mpu6050DataTypedef * mpu6050Data2);
};

#endif // GYROALGORITHM_H
