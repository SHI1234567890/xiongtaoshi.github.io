#include "Angle/GyroAlgorithm/gyroalgorithm.h"

GYROALGORITHM::GYROALGORITHM()
{

}

GYROALGORITHM::~GYROALGORITHM()
{

}

void GYROALGORITHM::Update(Mpu6050DataTypedef *mpu6050Data1, Mpu6050DataTypedef *mpu6050Data2)
{

}
