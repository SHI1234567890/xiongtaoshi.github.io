#include "Angle/DcmAlgorithm/dcmalgorithm.h"


DCMALGORITHM::DCMALGORITHM()
{

}

DCMALGORITHM::~DCMALGORITHM()
{

}

void DCMALGORITHM::Update(Mpu6050DataTypedef *mpu6050Data1, Mpu6050DataTypedef *mpu6050Data2, Hmc5883DataTypedef *hmc5883Data1, Hmc5883DataTypedef *hmc5883Data2)
{

}
