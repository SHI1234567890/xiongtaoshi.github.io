#ifndef DCMALGORITHM_H
#define DCMALGORITHM_H

#include "Typedef/typedef.h"
#include "QDebug"

class DCMALGORITHM
{
public:
    DCMALGORITHM();
    ~DCMALGORITHM();

    void Update(Mpu6050DataTypedef * mpu6050Data1, Mpu6050DataTypedef * mpu6050Data2,
                Hmc5883DataTypedef * hmc5883Data1, Hmc5883DataTypedef * hmc5883Data2);
};

#endif // DCMALGORITHM_H
