#ifndef QALGORITHM_H
#define QALGORITHM_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "math.h"
#include "Filter/AccFilter/accfilter.h"
#include "Filter/MagFilter/magfilter.h"

class QALGORITHM
{
public:
    QALGORITHM();
    ~QALGORITHM();

    QDataTypedef qData;
    DcmDataTypedef dcmData;

    AngleDataTypedef angleData;
    AngleDataTypedef angleSaveData;

    GyroPiDataTypedef accGyroPiData;
    GyroPiDataTypedef magGyroPiData;


    ACCFILTER myAccFilter;
    MAGFILTER myMagFilter;

    float UpdateT;
    float UpdateHalfT;
    float Radian2Angle;
    float Angle2Radian;

    float Gyro2Radian;

    float time20Ms;

    void Update(Mpu6050DataTypedef * mpu6050Data1, Mpu6050DataTypedef * mpu6050Data2,
                Hmc5883DataTypedef * hmc5883Data1, Hmc5883DataTypedef * hmc5883Data2);

    void UpdateQ(void);

    float sign(float value);
};

#endif // QALGORITHM_H
