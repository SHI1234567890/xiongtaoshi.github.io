#include "Angle/QAlgorithm/qalgorithm.h"

QALGORITHM::QALGORITHM()
{
    this->qData.q0 = 1.0f;
    this->qData.q1 = 0.0f;
    this->qData.q2 = 0.0f;
    this->qData.q3 = 0.0f;

    this->qData.sampleTime100 = 0;
    this->qData.angleZPhiSum = 0;
    this->qData.angleZPhi = 0;

    this->dcmData.d11 = 1.0f;
    this->dcmData.d12 = 0.0f;
    this->dcmData.d13 = 0.0f;

    this->dcmData.d21 = 0.0f;
    this->dcmData.d22 = 1.0f;
    this->dcmData.d23 = 0.0f;

    this->dcmData.d31 = 0.0f;
    this->dcmData.d32 = 0.0f;
    this->dcmData.d33 = 1.0f;

    this->accGyroPiData.p = 5.0f;
    this->accGyroPiData.i = 0.001f;
    this->accGyroPiData.intSep = 1.0f;
    this->accGyroPiData.gyroErrorX = 0;
    this->accGyroPiData.gyroErrorY = 0;
    this->accGyroPiData.gyroErrorZ = 0;
    this->accGyroPiData.gyroErrorIX = 0;
    this->accGyroPiData.gyroErrorIY = 0;
    this->accGyroPiData.gyroErrorIZ = 0;

    this->magGyroPiData.p = 5.0f;
    this->magGyroPiData.i = 0.001f;
    this->magGyroPiData.intSep = 1.0f;
    this->magGyroPiData.gyroErrorX = 0;
    this->magGyroPiData.gyroErrorY = 0;
    this->magGyroPiData.gyroErrorZ = 0;
    this->magGyroPiData.gyroErrorIX = 0;
    this->magGyroPiData.gyroErrorIY = 0;
    this->magGyroPiData.gyroErrorIZ = 0;


    this->angleData.angleXTheta = 0;
    this->angleData.angleYGamma = 0;
    this->angleData.angleZPhi = 0;

    this->angleSaveData.angleXTheta = 0;
    this->angleSaveData.angleYGamma = 0;
    this->angleSaveData.angleZPhi = 0;
    this->angleSaveData.angleZPhiLast = 0;
    this->angleSaveData.angleZPhiInf = 0;
    this->angleSaveData.toggleTimes = 0;
    this->angleSaveData.angleZPhiFirst = 0;
    this->angleSaveData.isSetFirstAngle = false;

    this->UpdateT = 0.001f;
    this->UpdateHalfT = this->UpdateT / 2.0f;

    this->Angle2Radian = (M_PI / 180.0f);
    this->Radian2Angle = (180.0f / M_PI);

    this->Gyro2Radian = (1000.0f/ 65536.0f) * this->Angle2Radian;

    this->time20Ms = 0;
}

QALGORITHM::~QALGORITHM()
{

}

void QALGORITHM::Update(Mpu6050DataTypedef *mpu6050Data1, Mpu6050DataTypedef *mpu6050Data2, Hmc5883DataTypedef *hmc5883Data1, Hmc5883DataTypedef *hmc5883Data2)
{
    WDataTypedef w = {mpu6050Data1->Mpu6050GyroX * this->Gyro2Radian,
                      mpu6050Data1->Mpu6050GyroY * this->Gyro2Radian,
                     -mpu6050Data1->Mpu6050GyroZ * this->Gyro2Radian};

    //使用加速度计角度X,Y
    AccDataTypedef accNow = {mpu6050Data1->Mpu6050AccX, mpu6050Data1->Mpu6050AccY,
                            mpu6050Data1->Mpu6050AccZ, 0.0f};
    accNow.norm = sqrt(accNow.accX * accNow.accX +
                       accNow.accY * accNow.accY +
                       accNow.accZ * accNow.accZ);
    accNow.accX /= accNow.norm;
    accNow.accY /= accNow.norm;
    accNow.accZ /= accNow.norm;

    this->myAccFilter.Update(&accNow);

    //
    this->accGyroPiData.gyroErrorX = this->dcmData.d23 * accNow.accZ - this->dcmData.d33 * accNow.accY;
    this->accGyroPiData.gyroErrorY = this->dcmData.d33 * accNow.accX - this->dcmData.d13 * accNow.accZ;
    this->accGyroPiData.gyroErrorZ = this->dcmData.d13 * accNow.accY - this->dcmData.d23 * accNow.accX;

    this->accGyroPiData.gyroErrorIX += this->accGyroPiData.gyroErrorX;
    this->accGyroPiData.gyroErrorIY += this->accGyroPiData.gyroErrorY;
    this->accGyroPiData.gyroErrorIZ += this->accGyroPiData.gyroErrorZ;

    w.wX += this->accGyroPiData.p * this->accGyroPiData.gyroErrorX +
            this->accGyroPiData.i * this->accGyroPiData.gyroErrorIX;
    w.wY += this->accGyroPiData.p * this->accGyroPiData.gyroErrorY +
            this->accGyroPiData.i * this->accGyroPiData.gyroErrorIY;
    //w.wZ += this->accGyroPiData.p * this->accGyroPiData.gyroErrorZ +
    //        this->accGyroPiData.i * this->accGyroPiData.gyroErrorIZ;

    if(++this->time20Ms >= 20)
    {
        this->time20Ms = 0;

        MagDataTypedef magNow = {hmc5883Data1->HmcMagX,
                                hmc5883Data1->HmcMagY,
                                hmc5883Data1->HmcMagZ,
                                0.0f};
        MagDataTypedef magTemp;

        magNow.norm = sqrt(magNow.magX * magNow.magX +
                           magNow.magY * magNow.magY +
                           magNow.magZ * magNow.magZ);
        magNow.magX /= magNow.norm;
        magNow.magY /= magNow.norm;
        magNow.magZ /= magNow.norm;

        //
        this->myMagFilter.Update(&magNow);
        //采样Z轴的角度值，并计算Q
        if(this->qData.sampleTime100 < 100)
        {
            //
            this->qData.sampleTime100++;
            //
            this->qData.angleZPhiSum += atan2(magNow.magY, magNow.magX);
            if(this->qData.sampleTime100 == 100)
            {
                this->qData.angleZPhi = this->qData.angleZPhiSum / 100.0f;
                //记录第一次角度
                this->angleSaveData.angleZPhiFirst = (this->qData.angleZPhi * this->Radian2Angle);
                //
                this->angleSaveData.isSetFirstAngle = true;
                //开始使用磁力计 计算Q
                this->angleData.angleXTheta = 0.0f;
                this->angleData.angleYGamma = 0.0f;
                this->angleData.angleZPhi = this->qData.angleZPhi;
                //
                this->UpdateQ();
            }else
            {
                return;
            }
        }

        magTemp.magX = cos(this->angleData.angleYGamma) * magNow.magX +
                        sin(this->angleData.angleYGamma) * magNow.magZ;
        magTemp.magY = cos(this->angleData.angleXTheta) * magNow.magY +
                    sin(this->angleData.angleXTheta) * sin(this->angleData.angleYGamma) * magNow.magX -
                    sin(this->angleData.angleXTheta) * cos(this->angleData.angleYGamma) * magNow.magZ;
        magNow.magX = magTemp.magX;
        magNow.magY = magTemp.magY;

        this->magGyroPiData.gyroErrorZ = this->dcmData.d11 * magNow.magY -
                                         this->dcmData.d12 * magNow.magX;

        this->magGyroPiData.gyroErrorIZ += this->magGyroPiData.gyroErrorX;

        w.wZ += this->magGyroPiData.p * this->magGyroPiData.gyroErrorZ +
                this->magGyroPiData.i * this->magGyroPiData.gyroErrorIZ;
    }

    QDataTypedef qInc;

    qInc.q0 = (-w.wX * this->qData.q1 - w.wY * this->qData.q2 - w.wZ * this->qData.q3) * this->UpdateHalfT;
    qInc.q1 = (w.wX * this->qData.q0 + w.wZ * this->qData.q2 - w.wY * this->qData.q3) * this->UpdateHalfT;
    qInc.q2 = (w.wY * this->qData.q0 - w.wZ * this->qData.q1 + w.wX * this->qData.q3) * this->UpdateHalfT;
    qInc.q3 = (w.wZ * this->qData.q0 + w.wY * this->qData.q1 - w.wX * this->qData.q2) * this->UpdateHalfT;

    this->qData.q0 += qInc.q0;
    this->qData.q1 += qInc.q1;
    this->qData.q2 += qInc.q2;
    this->qData.q3 += qInc.q3;

    this->qData.norm = sqrt(this->qData.q0 * this->qData.q0 + this->qData.q1 * this->qData.q1 +
                           this->qData.q2 * this->qData.q2 + this->qData.q3 * this->qData.q3);

    this->qData.q0 /= this->qData.norm;
    this->qData.q1 /= this->qData.norm;
    this->qData.q2 /= this->qData.norm;
    this->qData.q3 /= this->qData.norm;

    this->qData.q0q0 = this->qData.q0 * this->qData.q0;
    this->qData.q0q1 = this->qData.q0 * this->qData.q1;
    this->qData.q0q2 = this->qData.q0 * this->qData.q2;
    this->qData.q0q3 = this->qData.q0 * this->qData.q3;

    this->qData.q1q1 = this->qData.q1 * this->qData.q1;
    this->qData.q1q2 = this->qData.q1 * this->qData.q2;
    this->qData.q1q3 = this->qData.q1 * this->qData.q3;

    this->qData.q2q2 = this->qData.q2 * this->qData.q2;
    this->qData.q2q3 = this->qData.q2 * this->qData.q3;

    this->qData.q3q3 = this->qData.q3 * this->qData.q3;

    //计算CN-B的矩阵对应的d

    //CN-B 的第一列为 n系的x轴在b系中的投影
    //CN-B 的第一列为 n系的y轴在b系中的投影
    //CN-B 的第一列为 n系的z轴在b系中的投影

    //CN-B 的第一行为 b系的x轴在n系中的投影
    //CN-B 的第一行为 b系的y轴在n系中的投影
    //CN-B 的第一行为 b系的z`轴在n系中的投影

    this->dcmData.d11 = 1.0f - 2.0f * (this->qData.q2q2 + this->qData.q3q3);
    this->dcmData.d12 = 2.0f * (this->qData.q1q2 + this->qData.q0q3);
    this->dcmData.d13 = 2.0f * (this->qData.q1q3 - this->qData.q0q2);

    this->dcmData.d21 = 2.0f * (this->qData.q1q2 - this->qData.q0q3);
    this->dcmData.d22 = 1.0f - 2.0f * (this->qData.q1q1 + this->qData.q3q3);
    this->dcmData.d23 = 2.0f * (this->qData.q2q3 + this->qData.q0q1);

    this->dcmData.d31 = 2.0f * (this->qData.q1q3 + this->qData.q0q2);
    this->dcmData.d32 = 2.0f * (this->qData.q2q3 - this->qData.q0q1);
    this->dcmData.d33 = 1.0f - 2.0f * (this->qData.q1q1 + this->qData.q2q2);

    this->angleData.angleXTheta = asin(this->dcmData.d23);
    this->angleData.angleYGamma = atan2(-this->dcmData.d13, this->dcmData.d33);
    //
    this->angleData.angleZPhi = atan2(-this->dcmData.d21, this->dcmData.d22);

    this->angleSaveData.angleXTheta = this->angleData.angleXTheta * this->Radian2Angle;
    this->angleSaveData.angleYGamma = this->angleData.angleYGamma* this->Radian2Angle;
    this->angleSaveData.angleZPhi = this->angleData.angleZPhi * this->Radian2Angle;

    //判断跳变
    if((this->angleSaveData.angleZPhi - this->angleSaveData.angleZPhiLast) > 300.0f)
    {
        this->angleSaveData.toggleTimes -= 360.0f;
    }else if((this->angleSaveData.angleZPhi - this->angleSaveData.angleZPhiLast) < -300.0f)
    {
        this->angleSaveData.toggleTimes += 360.0f;
    }

    //update
    this->angleSaveData.angleZPhiLast = this->angleSaveData.angleZPhi;

    //
    this->angleSaveData.angleZPhiInf = this->angleSaveData.angleZPhi + this->angleSaveData.toggleTimes;
}

void QALGORITHM::UpdateQ()
{
    //CN-B
    this->dcmData.d11 = cos(this->angleData.angleZPhi);
    this->dcmData.d12 = -sin(this->angleData.angleZPhi);
    this->dcmData.d13 = 0.0f;

    this->dcmData.d21 = sin(this->angleData.angleZPhi);
    this->dcmData.d22 = cos(this->angleData.angleZPhi);
    this->dcmData.d23 = 0.0f;

    this->dcmData.d31 = 0.0f;
    this->dcmData.d32 = 0.0f;
    this->dcmData.d33 = 1.0f;

//    qDebug()<<"this->dcmData.d11" << this->dcmData.d11;
//    qDebug()<<"this->dcmData.d22" << this->dcmData.d22;
//    qDebug()<<"this->dcmData.d33" << this->dcmData.d33;

    //this->qData.q0 = 1;
    this->qData.q0 = sqrt(1.0f + this->dcmData.d11 + this->dcmData.d22 + this->dcmData.d33) / 2.0f;
    //this->qData.q1 = 0;
    //this->qData.q1 = sqrt(1.0f + this->dcmData.d11 - this->dcmData.d22 - this->dcmData.d33) / 2.0f;
    this->qData.q1 = 0;
    //this->qData.q2 = 0;
    //this->qData.q2 = sqrt(1.0f - this->dcmData.d11 + this->dcmData.d22 - this->dcmData.d33) / 2.0f;
    this->qData.q2 = 0;
    //this->qData.q3 = 0;
    //this->qData.q3 = sqrt(1.0f - this->dcmData.d11 - this->dcmData.d22 + this->dcmData.d33) / 2.0f;
    this->qData.q3 = sqrt(1.0f - this->dcmData.d11 - this->dcmData.d22 + this->dcmData.d33) / 2.0f;

    //
    this->qData.q1 *= (this->sign(this->qData.q0)*this->sign(this->dcmData.d23 - this->dcmData.d32));
    this->qData.q2 *= (this->sign(this->qData.q0)*this->sign(this->dcmData.d31 - this->dcmData.d13));
    this->qData.q3 *= -(this->sign(this->qData.q0)*this->sign(this->dcmData.d12 - this->dcmData.d21));

//    qDebug()<<"this->qData.q0" << this->qData.q0;
//    qDebug()<<"this->qData.q1" << this->qData.q1;
//    qDebug()<<"this->qData.q2" << this->qData.q2;
//    qDebug()<<"this->qData.q3" << this->qData.q3;
}

float QALGORITHM::sign(float value)
{
    if (value >= 0.0f)
    {
        return 1.0f;
    }else
    {
        return -1.0f;
    }
}
