#ifndef ANGLECONTROL_H
#define ANGLECONTROL_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "Pid/pid.h"

class ANGLECONTROL
{
public:
    ANGLECONTROL();
    ~ANGLECONTROL();

    PID myOuterAngleX;
    PID myInnerAngleX;

    PID myOuterAngleY;
    PID myInnerAngleY;

    PID myOuterAngleZ;
    PID myInnerAngleZ;

    PID myOuterHeight;
    PID myInnerHeight;

    AngConOutDataTypedef myAngConOutData;

    uint32_t time2Ms;

    void Update(RcDataTypedef * rcData, AngleDataTypedef * meaAngleData);
    void SetData(PidPramDataTypedef * pidPramData);
};

#endif // ANGLECONTROL_H
