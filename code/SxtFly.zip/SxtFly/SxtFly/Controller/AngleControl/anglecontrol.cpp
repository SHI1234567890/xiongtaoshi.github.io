
#include "Controller/AngleControl/anglecontrol.h"

ANGLECONTROL::ANGLECONTROL()
{
    //
    this->time2Ms = 0;
    //X外环初值
    this->myOuterAngleX.myPidData.P = 6.0f;
    this->myOuterAngleX.myPidData.I = 0;
    this->myOuterAngleX.myPidData.D = 1.0f;
    this->myOuterAngleX.myPidData.IntSep = 5.0f;
    this->myOuterAngleX.myPidData.IntMax = 10.0f;
    this->myOuterAngleX.myPidData.OutMax = 100.0f;
    this->myOuterAngleX.myPidData.UpdateTime = 0.002f;

    //Y外环初值
    this->myOuterAngleY.myPidData.P = 6.0f;
    this->myOuterAngleY.myPidData.I = 0;
    this->myOuterAngleY.myPidData.D = 1.0f;
    this->myOuterAngleY.myPidData.IntSep = 5.0f;
    this->myOuterAngleY.myPidData.IntMax = 10.0f;
    this->myOuterAngleY.myPidData.OutMax = 100.0f;
    this->myOuterAngleY.myPidData.UpdateTime = 0.002f;

    //Z外环初值
    this->myOuterAngleZ.myPidData.P = 6.0f;
    this->myOuterAngleZ.myPidData.I = 0;
    this->myOuterAngleZ.myPidData.D = 1.0f;
    this->myOuterAngleZ.myPidData.IntSep = 5.0f;
    this->myOuterAngleZ.myPidData.IntMax = 10.0f;
    this->myOuterAngleZ.myPidData.OutMax = 100.0f;
    this->myOuterAngleZ.myPidData.UpdateTime = 0.002f;

    //
    this->myAngConOutData.outX = 0;
    this->myAngConOutData.outY = 0;
    this->myAngConOutData.outZ = 0;
    this->myAngConOutData.outH = 0;
}

ANGLECONTROL::~ANGLECONTROL()
{

}

void ANGLECONTROL::Update(RcDataTypedef *rcData, AngleDataTypedef *meaAngleData)
{
    if(++this->time2Ms >= 2)
    {
        this->time2Ms = 0;

        if(rcData->MotoOnFlag)
        {
            //X轴外环计算,以角度为单位
            this->myOuterAngleX.Update(rcData->TarAngleXTheta, meaAngleData->angleXTheta);

            //Y轴外环计算,以角度为单位
            this->myOuterAngleY.Update(rcData->TarAngleYGama, meaAngleData->angleYGamma);

            if(meaAngleData->isSetFirstAngle)
            {
                //Z轴外环计算,以角度为单位
                this->myOuterAngleZ.Update(rcData->TarAngleZPhi+meaAngleData->angleZPhiFirst, meaAngleData->angleZPhi);
            }

            this->myAngConOutData.outX = this->myOuterAngleX.myPidData.Out;
            this->myAngConOutData.outY = this->myOuterAngleY.myPidData.Out;
            this->myAngConOutData.outZ = this->myOuterAngleZ.myPidData.Out;

            this->myAngConOutData.outH = rcData->Throttle + 999;
        }else
        {
            this->myAngConOutData.outX = 0;
            this->myAngConOutData.outY = 0;
            this->myAngConOutData.outZ = 0;
            this->myAngConOutData.outH = 999;
        }
    }
}

void ANGLECONTROL::SetData(PidPramDataTypedef *pidPramData)
{
    this->myOuterAngleX.myPidData.P = pidPramData->XP;
    this->myOuterAngleX.myPidData.I = pidPramData->XI;
    this->myOuterAngleX.myPidData.D = pidPramData->XD;

    this->myOuterAngleY.myPidData.P = pidPramData->YP;
    this->myOuterAngleY.myPidData.I = pidPramData->YI;
    this->myOuterAngleY.myPidData.D = pidPramData->YD;

    this->myOuterAngleZ.myPidData.P = pidPramData->ZP;
    this->myOuterAngleZ.myPidData.I = pidPramData->ZI;
    this->myOuterAngleZ.myPidData.D = pidPramData->ZD;

    //
    this->myOuterAngleX.Clean();
    this->myOuterAngleY.Clean();
    this->myOuterAngleZ.Clean();
}
