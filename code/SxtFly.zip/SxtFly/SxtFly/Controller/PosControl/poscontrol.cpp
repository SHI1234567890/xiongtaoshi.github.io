#include "Controller/PosControl/poscontrol.h"

POSCONTROL::POSCONTROL()
{

}

POSCONTROL::~POSCONTROL()
{

}

void POSCONTROL::Update()
{

}
