#ifndef POSCONTROL_H
#define POSCONTROL_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "Pid/pid.h"

class POSCONTROL
{
public:
    POSCONTROL();
    ~POSCONTROL();

    void Update(void);
};

#endif // POSCONTROL_H
