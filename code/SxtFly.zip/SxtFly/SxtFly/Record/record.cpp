#include "Record/record.h"

RECORD::RECORD()
{
    this->angleLineNumber = 0;
    this->mpu60501LineNumber = 0;
    this->mpu60502LineNumber = 0;
    this->hmc58831LineNumber = 0;
    this->hmc58832LineNumber = 0;
    this->ms56111LineNumber = 0;
    this->ms56112LineNumber = 0;
    this->gpsLineNumber = 0;
    this->qLineNumber = 0;
    this->posLineNumber = 0;

    QString filePath = "/home/pi/SensorData";
    uint32_t filePathNumber = 0;

    if(this->IsDirExist(filePath) == false)
    {
        qDebug() << filePath << "not exist";
        this->CreateDir(filePath);
        if(this->IsDirExist(filePath) == true)
        {
            qDebug() << filePath << "be able to create";
        }else
        {
            qDebug() << filePath << "unable to create";
        }
    }else
    {
        qDebug() << filePath << "exist";
    }

    while(this->IsDirExist(filePath + "/Data" + QString::number(filePathNumber)) == true)
    {
        filePathNumber++;
    }

    filePath += "/Data" + QString::number(filePathNumber);
    if(this->CreateDir(filePath) == true)
    {
        qDebug() << filePath << "be able to create";
    }else
    {
        qDebug() << filePath << "unable to create";
    }

    //角度文件
    this->angleFile.setFileName(filePath + "/angleFile.txt");
    if(this->angleFile.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open angleFile";
    }else
    {
        qDebug() << "be able to open angleFile";
    }
    this->angleOut.setDevice(&this->angleFile);

    //mpu60501文件
    this->mpu60501File.setFileName(filePath + "/mpu60501File.txt");
    if(this->mpu60501File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open mpu60501File";
    }else
    {
        qDebug() << "be able to open mpu60501File";
    }
    this->mpu60501Out.setDevice(&this->mpu60501File);

    //mpu60502文件
    this->mpu60502File.setFileName(filePath + "/mpu60502File.txt");
    if(this->mpu60502File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open mpu60502File";
    }else
    {
        qDebug() << "be able to open mpu60502File";
    }
    this->mpu60502Out.setDevice(&this->mpu60502File);

    //hmc58831File
    this->hmc58831File.setFileName(filePath + "/hmc58831File.txt");
    if(this->hmc58831File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open hmc58831File";
    }else
    {
        qDebug() << "be able to open hmc58831File";
    }
    this->hmc58831Out.setDevice(&this->hmc58831File);

    //hmc58832File
    this->hmc58832File.setFileName(filePath + "/hmc58832File.txt");
    if(this->hmc58832File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open hmc58832File";
    }else
    {
        qDebug() << "be able to open hmc58832File";
    }
    this->hmc58832Out.setDevice(&this->hmc58832File);

    //ms56111File
    this->ms56111File.setFileName(filePath + "/ms56111File.txt");
    if(this->ms56111File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open ms56111File";
    }else
    {
        qDebug() << "be able to open ms56111File";
    }
    this->ms56111Out.setDevice(&this->ms56111File);

    //ms56112File
    this->ms56112File.setFileName(filePath + "/ms56112File.txt");
    if(this->ms56112File.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open ms56112File";
    }else
    {
        qDebug() << "be able to open ms56112File";
    }
    this->ms56112Out.setDevice(&this->ms56112File);

    //gpsFile
    this->gpsFile.setFileName(filePath + "/gpsFile.txt");
    if(this->gpsFile.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open gpsFile";
    }else
    {
        qDebug() << "be able to open gpsFile";
    }
    this->gpsOut.setDevice(&this->gpsFile);

    //qFile
    this->qFile.setFileName(filePath + "/qFile.txt");
    if(this->qFile.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open qFile";
    }else
    {
        qDebug() << "be able to open qFile";
    }
    this->qOut.setDevice(&this->qFile);

    //posFile
    this->posFile.setFileName(filePath + "/posFile.txt");
    if(this->posFile.open(QIODevice::Append | QIODevice::Text) != true)
    {
        qDebug() << "Unable to open posFile";
    }else
    {
        qDebug() << "be able to open posFile";
    }
    this->posOut.setDevice(&this->posFile);
}

RECORD::~RECORD()
{
    if(this->angleFile.isOpen())
    {
        this->angleFile.close();
    }

    if(this->mpu60501File.isOpen())
    {
        this->mpu60501File.close();
    }

    if(this->mpu60502File.isOpen())
    {
        this->mpu60502File.close();
    }

    if(this->hmc58831File.isOpen())
    {
        this->hmc58831File.close();
    }

    if(this->hmc58832File.isOpen())
    {
        this->hmc58832File.close();
    }

    if(this->ms56111File.isOpen())
    {
        this->ms56111File.close();
    }

    if(this->ms56112File.isOpen())
    {
        this->ms56112File.close();
    }

    if(this->gpsFile.isOpen())
    {
        this->gpsFile.close();
    }

    if(this->qFile.isOpen())
    {
        this->qFile.close();
    }

    if(this->posFile.isOpen())
    {
        this->posFile.close();
    }
}

bool RECORD::IsDirExist(QString filePath)
{
    QDir fileDir(filePath);

    if(fileDir.exists())
    {
        return true;
    }else
    {
        return false;
    }

}

bool RECORD::CreateDir(QString filePath)
{
    QDir fileDir(filePath);

    return fileDir.mkdir(filePath);
}

void RECORD::WriteMpu6050Data(const Mpu6050DataTypedef *mpu6050Data1, const Mpu6050DataTypedef *mpu6050Data2)
{
    if(this->mpu60501File.isOpen())
    {
        this->mpu60501Out << " LineNumber : " << this->mpu60501LineNumber++ << endl
                          << mpu6050Data1->Mpu6050AccX << " "
                          << mpu6050Data1->Mpu6050AccY << " "
                          << mpu6050Data1->Mpu6050AccZ << " "
                          << mpu6050Data1->Mpu6050Temp << " "
                          << mpu6050Data1->Mpu6050GyroX << " "
                          << mpu6050Data1->Mpu6050GyroY << " "
                          << mpu6050Data1->Mpu6050GyroZ << " "
                          << endl;
    }

    if(this->mpu60502File.isOpen())
    {
        this->mpu60502Out << " LineNumber : " << this->mpu60502LineNumber++ << endl
                          << mpu6050Data2->Mpu6050AccX << " "
                          << mpu6050Data2->Mpu6050AccY << " "
                          << mpu6050Data2->Mpu6050AccZ << " "
                          << mpu6050Data2->Mpu6050Temp << " "
                          << mpu6050Data2->Mpu6050GyroX << " "
                          << mpu6050Data2->Mpu6050GyroY << " "
                          << mpu6050Data2->Mpu6050GyroZ << " "
                          << endl;

    }
}

void RECORD::WriteHmc5883lData(const Hmc5883DataTypedef *hmc5883Data1, const Hmc5883DataTypedef *hmc5883Data2)
{
    if(this->hmc58831File.isOpen())
    {
        this->hmc58831Out << "LineNumber : " << this->hmc58831LineNumber++ << endl
                          << hmc5883Data1->HmcMagX << " "
                          << hmc5883Data1->HmcMagY << " "
                          << hmc5883Data1->HmcMagZ << " "
                          << endl;
    }

    if(this->hmc58832File.isOpen())
    {
        this->hmc58832Out << "LineNumber : " << this->hmc58832LineNumber++ << endl
                          << hmc5883Data2->HmcMagX << " "
                          << hmc5883Data2->HmcMagY << " "
                          << hmc5883Data2->HmcMagZ << " "
                          << endl;
    }

}

void RECORD::WriteMs5611Data(const Ms5611DataTypedef *ms5611Data1, const Ms5611DataTypedef *ms5611Data2)
{
    if(this->ms56111File.isOpen())
    {
        this->ms56111Out << "LineNumber : " << this->ms56111LineNumber++ << endl
                         << ms5611Data1->Ms5611P << " "
                         << endl;
    }

    if(this->ms56112File.isOpen())
    {
        this->ms56112Out << "LineNumber : " << this->ms56112LineNumber++ << endl
                         << ms5611Data2->Ms5611P << " "
                         << endl;
    }
}

void RECORD::WriteGpsData(const GpsDataTypedef *gpsData)
{
    if(this->gpsFile.isOpen())
    {
        this->gpsOut << "LineNumber : " << this->gpsLineNumber++ << endl
                     << gpsData->IsFixOk << " "
                     << gpsData->numSv << " "
                     << gpsData->longitude << " "
                     << gpsData->fLongitudeAngle << " "
                     << gpsData->latitude << " "
                     << gpsData->fLatitudeAngle << " "
                     << gpsData->Height << " "
                     << gpsData->fHeight << " "
                     << gpsData->hAcc << " "
                     << gpsData->vAcc << " "
                     << gpsData->velN << " "
                     << gpsData->velE << " "
                     << gpsData->velD << " "
                     << endl;
    }
}

void RECORD::WriteAngleData(const AngleDataTypedef *angleData)
{
    if(this->angleFile.isOpen())
    {
        this->angleOut << " LineNumber : " << this->angleLineNumber++ << endl
                       << angleData->angleXTheta << " "
                       << angleData->angleYGamma << " "
                       << angleData->angleZPhi << " "
                       << endl;
    }

}

void RECORD::WriteQData(const QDataTypedef *qData)
{
    if(this->qFile.isOpen())
    {
        this->qOut << " LineNumber : " << this->qLineNumber++ << endl
                   << qData->theta << " "
                   << qData->l << " "
                   << qData->m << " "
                   << qData->n << " "
                   << qData->q0 << " "
                   << qData->q1 << " "
                   << qData->q2 << " "
                   << qData->q3 << " "
                   << endl;
    }

}

void RECORD::WritePosData(const PosDataTypedef *posData)
{
    if(this->posFile.isOpen())
    {
        this->posOut << " LineNumber  : " << this->posLineNumber++ << endl
                     << posData->North << " "
                     << posData->East << " "
                     << posData->Up << " "
                     << endl;
    }

}
