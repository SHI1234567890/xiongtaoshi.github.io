#ifndef RECORD_H
#define RECORD_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "QFile"
#include "QTextStream"
#include "QDir"

class RECORD
{
public:
    RECORD();
    ~RECORD();

    bool IsDirExist(QString filePath);

    bool CreateDir(QString filePath);

    uint32_t angleLineNumber;
    uint32_t mpu60501LineNumber;
    uint32_t mpu60502LineNumber;
    uint32_t hmc58831LineNumber;
    uint32_t hmc58832LineNumber;
    uint32_t ms56111LineNumber;
    uint32_t ms56112LineNumber;
    uint32_t gpsLineNumber;
    uint32_t qLineNumber;
    uint32_t posLineNumber;

    //角度文件
    QFile angleFile;
    QTextStream angleOut;

    //传感器mpu60501
    QFile mpu60501File;
    QTextStream mpu60501Out;

    //传感器mpu60502
    QFile mpu60502File;
    QTextStream mpu60502Out;


    //传感器hmc58831
    QFile hmc58831File;
    QTextStream hmc58831Out;

    //传感器hmc58832
    QFile hmc58832File;
    QTextStream hmc58832Out;


    //传感器ms56111
    QFile ms56111File;
    QTextStream ms56111Out;

    //传感器ms56112
    QFile ms56112File;
    QTextStream ms56112Out;

    //GPS
    QFile gpsFile;
    QTextStream gpsOut;

    //四元数文件存放
    QFile qFile;
    QTextStream qOut;

    //位置数据的文件存放
    QFile posFile;
    QTextStream posOut;


    void WriteMpu6050Data(const Mpu6050DataTypedef * mpu6050Data1, const Mpu6050DataTypedef * mpu6050Data2);
    void WriteHmc5883lData(const Hmc5883DataTypedef * hmc5883Data1, const Hmc5883DataTypedef * hmc5883Data2);
    void WriteMs5611Data(const Ms5611DataTypedef * ms5611Data1, const Ms5611DataTypedef * ms5611Data2);
    void WriteGpsData(const GpsDataTypedef * gpsData);
    void WriteAngleData(const AngleDataTypedef * angleData);
    void WriteQData(const QDataTypedef * qData);
    void WritePosData(const PosDataTypedef * posData);
};

#endif // RECORD_H
