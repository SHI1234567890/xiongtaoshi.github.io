#include "Moto/moto.h"

MOTO::MOTO()
{
    this->moto.moto1 = 0;
    this->moto.moto2 = 0;
    this->moto.moto3 = 0;
    this->moto.moto4 = 0;
}

MOTO::~MOTO()
{

}

void MOTO::Update(AngConOutDataTypedef *myAngconData)
{
    this->moto.moto1 = myAngconData->outX + myAngconData->outY + myAngconData->outZ + myAngconData->outH;
    this->moto.moto2 = myAngconData->outX - myAngconData->outY - myAngconData->outZ + myAngconData->outH;
    this->moto.moto3 = -myAngconData->outX - myAngconData->outY + myAngconData->outZ + myAngconData->outH;
    this->moto.moto4 = -myAngconData->outX + myAngconData->outY - myAngconData->outZ + myAngconData->outH;

    if(this->moto.moto1 < 999)
    {
        this->moto.moto1 = 999;
    }else if(this->moto.moto1 > 1899)
    {
        this->moto.moto1 = 1899;
    }

    if(this->moto.moto2 < 999)
    {
        this->moto.moto2 = 999;
    }else if(this->moto.moto2 > 1899)
    {
        this->moto.moto2 = 1899;
    }

    if(this->moto.moto3 < 999)
    {
        this->moto.moto3 = 999;
    }else if(this->moto.moto3 > 1899)
    {
        this->moto.moto3 = 1899;
    }

    if(this->moto.moto4 < 999)
    {
        this->moto.moto4 = 999;
    }else if(this->moto.moto4 > 1899)
    {
        this->moto.moto4 = 1899;
    }
}

