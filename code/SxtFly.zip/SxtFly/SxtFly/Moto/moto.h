#ifndef MOTO_H
#define MOTO_H

#include "Typedef/typedef.h"
#include "QDebug"

class MOTO
{
public:
    MOTO();
    ~MOTO();

    //运用算法更新电机输出
    void Update(AngConOutDataTypedef * myAngconData);

    MotoDataTypedef moto;
};

#endif // MOTO_H
