
#include "MainTask/maintask.h"

MAINTASK::MAINTASK()
{

}

MAINTASK::~MAINTASK()
{

}

void MAINTASK::CalcAlgorithm()
{
    //更新遥控器输入
    this->myRc.Update(&this->mySensor.rcSensorData);

    //更新姿态
    this->myQAlgorithm.Update(&this->mySensor.mpu6050Data1, &this->mySensor.mpu6050Data2,
                              &this->mySensor.hmc5883Data1, &this->mySensor.hmc5883Data2);
    //更新位置
    this->myPosition.UpdateHeight(this->mySensor.msData1Init.isCalied, &this->mySensor.msData1.height);
    this->myPosition.Update(&this->mySensor.gpsData);

    //进行控制计算
    this->myPoscontrol.Update();
    this->myAngleControl.Update(&this->myRc.myRcData, &this->myQAlgorithm.angleSaveData);

    //更新输出
    this->myMoto.Update(&this->myAngleControl.myAngConOutData);
}

void MAINTASK::StartIdleThread()
{
    THREAD::connect(&this->myIdleThread, &THREAD::ThreadRun, this, &MAINTASK::IdleThreadRun, Qt::DirectConnection);
    this->myIdleThread.start();
}

void MAINTASK::StartNetworkThread()
{
    THREAD::connect(&this->myNetworkThread, &THREAD::ThreadRun, this, &MAINTASK::NetworkThreadRun, Qt::DirectConnection);
    this->myNetworkThread.start();
}

void MAINTASK::IdleThreadRun()
{
    while(1)
    {
        THREAD::msleep(1000);
//        qDebug()<<"sensorReadTimes"<<this->mySensor.sensorReadTimes<<" "
//                <<"IsrReadTimes"<<this->mySensor.IsrReadTimes<<" "
//               << "error" << this->mySensor.error << " "
//                <<"errorRate"<<this->mySensor.errorRate;
        this->myRecord.WriteMpu6050Data(&this->mySensor.mpu6050Data1, &this->mySensor.mpu6050Data2);
        this->myRecord.WriteHmc5883lData(&this->mySensor.hmc5883Data1, &this->mySensor.hmc5883Data2);
        this->myRecord.WriteMs5611Data(&this->mySensor.msData1, &this->mySensor.msData2);
        this->myRecord.WriteGpsData(&this->mySensor.gpsData);
        this->myRecord.WritePosData(&this->myPosition.myPosData1);
    }
}

void MAINTASK::NetworkThreadRun()
{
    NETWORK myNetwork;

    while(1)
    {
        this->NetworkBuff[0] = 0X88;
        this->NetworkBuff[1] = 0X88;
        this->NetworkBuff[28] = 0X88;
        this->NetworkBuff[29] = 0X88;

        F2U32DataTypedef temp;

        temp.fData = this->myQAlgorithm.angleSaveData.angleXTheta;
        this->NetworkBuff[2] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[3] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[4] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[5] = (uint32_t)(temp.u32Data);

        temp.fData = this->myQAlgorithm.angleSaveData.angleYGamma;
        this->NetworkBuff[6] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[7] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[8] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[9] = (uint32_t)(temp.u32Data);

        temp.fData = this->myQAlgorithm.angleSaveData.angleZPhiInf;
        this->NetworkBuff[10] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[11] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[12] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[13] = (uint32_t)(temp.u32Data);

        temp.fData = 0;
        this->NetworkBuff[14] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[15] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[16] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[17] = (uint32_t)(temp.u32Data);

        temp.fData = 0;
        this->NetworkBuff[18] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[19] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[20] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[21] = (uint32_t)(temp.u32Data);

        temp.fData = 0;
        this->NetworkBuff[22] = (uint32_t)(temp.u32Data >> 24);
        this->NetworkBuff[23] = (uint32_t)(temp.u32Data >> 16);
        this->NetworkBuff[24] = (uint32_t)(temp.u32Data >> 8);
        this->NetworkBuff[25] = (uint32_t)(temp.u32Data);

        myNetwork.SendData((char *)this->NetworkBuff, sizeof(this->NetworkBuff));

        //检查是否接受到了数据
        if(myNetwork.pidPramData.Update)
        {
            myNetwork.pidPramData.Update = false;
            //设置数据到PID参数中
            this->myAngleControl.SetData(&myNetwork.pidPramData);
        }

        THREAD::msleep(100);
    }
}

HAL_StatusTypedef MAINTASK::EncodeData()
{
    this->SpiBuff[0] = 0X88;
    this->SpiBuff[1] = 0X88;
    this->SpiBuff[99] = 0X88;

    this->SpiBuff[2] = (uint8_t)(this->myMoto.moto.moto1 >> 8);
    this->SpiBuff[3] = (uint8_t)(this->myMoto.moto.moto1);

    this->SpiBuff[4] = (uint8_t)(this->myMoto.moto.moto2 >> 8);
    this->SpiBuff[5] = (uint8_t)(this->myMoto.moto.moto2);

    this->SpiBuff[6] = (uint8_t)(this->myMoto.moto.moto3 >> 8);
    this->SpiBuff[7] = (uint8_t)(this->myMoto.moto.moto3);

    this->SpiBuff[8] = (uint8_t)(this->myMoto.moto.moto4 >> 8);
    this->SpiBuff[9] = (uint8_t)(this->myMoto.moto.moto4);

    return HAL_OK;
}

HAL_StatusTypedef MAINTASK::DecodeData()
{
    return mySensor.DecodeData(SpiBuff);
}
