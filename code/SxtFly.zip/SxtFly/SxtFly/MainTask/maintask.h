#ifndef MAINTASK_H
#define MAINTASK_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "Sensor/sensor.h"
#include "Thread/mythread.h"
#include "Moto/moto.h"
#include "Rc/rc.h"

#include "Angle/AccAlgorithm/accalgorithm.h"
#include "Angle/DcmAlgorithm/dcmalgorithm.h"
#include "Angle/GyroAlgorithm/gyroalgorithm.h"
#include "Angle/QAlgorithm/qalgorithm.h"
#include "Network/network.h"
#include "Position/position.h"
#include "Record/record.h"
#include "Controller/AngleControl/anglecontrol.h"
#include "Controller/PosControl/poscontrol.h"

class MAINTASK : public QObject
{
public slots:
    void IdleThreadRun(void);
    void NetworkThreadRun(void);

public:
    MAINTASK();
    ~MAINTASK();

    void StartIdleThread(void);
    void StartNetworkThread(void);

    uint8_t NetworkBuff[30];
    uint8_t SpiBuff[100];

    HAL_StatusTypedef EncodeData(void);
    HAL_StatusTypedef DecodeData(void);

    void CalcAlgorithm(void);

    //建立两个线程
    THREAD myIdleThread;
    THREAD myNetworkThread;

    //传感器类
    SENSOR mySensor;

    //电机类
    MOTO myMoto;

    //遥控器
    RC myRc;

    //四种姿态解算算法
    ACCALGORITHM myAccAlgorithm;
    DCMALGORITHM myDcmAlgorithm;
    QALGORITHM myQAlgorithm;
    GYROALGORITHM myGyroAlgorithm;

    //位置解算
    POSITION myPosition;

    //文件夹类
    RECORD myRecord;

    //控制角度姿态信息,高度
    ANGLECONTROL myAngleControl;

    //控制位置信息
    POSCONTROL myPoscontrol;
};

#endif // MAINTASK_H
