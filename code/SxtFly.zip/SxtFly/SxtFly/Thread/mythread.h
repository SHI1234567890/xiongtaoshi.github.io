#ifndef MYTHREAD_H
#define MYTHREAD_H

#include "QThread"

class THREAD : public QThread
{
    Q_OBJECT
signals:
    void ThreadRun(void);
protected:
    void run();

public:
    THREAD();
    ~THREAD();
};
#endif // MYTHREAD_H
