
#include "Thread/mythread.h"

THREAD::THREAD()
{

}

THREAD::~THREAD()
{

}

void THREAD::run()
{
    emit ThreadRun();
}

