#ifndef NETWORK_H
#define NETWORK_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "QObject"
#include "QTcpSocket"
#include "QtNetwork"
#include "QTextStream"
#include "QTime"

class NETWORK : public QObject
{
public slots:
    void TcpConnected(void);
    void TcpDisconnected(void);
    void TcpReadyRead(void);

public:
    NETWORK();
    ~NETWORK();

    bool IsTcpConnected;

    QString hostAddr;
    quint16 hostPort;

    QTcpSocket myTcpSocket;

    PidPramDataTypedef pidPramData;

    QString GetIpAddress(void);
    QString SetIpAddress(QString hostAddress);

    uint32_t SendData(const char * data, uint32_t length);
};

#endif // NETWORK_H
