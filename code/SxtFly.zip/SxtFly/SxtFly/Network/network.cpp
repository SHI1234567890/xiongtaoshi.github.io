
#include "Network/network.h"

NETWORK::NETWORK()
{
    this->hostAddr = "192.168.191.1";
    qDebug()<<"this->hostAddr : " << this->hostAddr;

    this->hostPort = 55555;

    this->IsTcpConnected = false;

    this->pidPramData.XP = 0;
    this->pidPramData.XI = 0;
    this->pidPramData.XD = 0;

    this->pidPramData.YP = 0;
    this->pidPramData.YI = 0;
    this->pidPramData.YD = 0;

    this->pidPramData.ZP = 0;
    this->pidPramData.ZI = 0;
    this->pidPramData.ZD = 0;

    this->pidPramData.Update = false;

    //
    QTcpSocket::connect(&this->myTcpSocket, &QTcpSocket::connected, this, &NETWORK::TcpConnected);
    QTcpSocket::connect(&this->myTcpSocket, &QTcpSocket::disconnected, this, &NETWORK::TcpDisconnected);
    QTcpSocket::connect(&this->myTcpSocket, &QTcpSocket::readyRead, this, &NETWORK::TcpReadyRead);

    this->myTcpSocket.abort();
    this->myTcpSocket.connectToHost(this->hostAddr, this->hostPort);
    this->myTcpSocket.waitForConnected();
}

NETWORK::~NETWORK()
{

}

QString NETWORK::GetIpAddress()
{
    QString ipAddress;

    QList<QHostAddress> ipAddressList = QNetworkInterface::allAddresses();
    int n = ipAddressList.size();

    for(int i=0; i<n; i++)
    {
        if((ipAddressList.at(i) != QHostAddress::LocalHost) &&
                (ipAddressList.at(i).toIPv4Address()))
        {
            ipAddress = ipAddressList.at(i).toString();
        }
    }

    if(ipAddress.isEmpty())
    {
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
    }

    return ipAddress;
}

QString NETWORK::SetIpAddress(QString hostAddress)
{
    QString ipAdresss;
    int n = hostAddress.lastIndexOf(".");
    for (int i=0; i<=n; i++)
    {
        ipAdresss.append(hostAddress.at(i));
    }

    ipAdresss.append('1');
    ipAdresss.append('1');
    ipAdresss.append('1');

    return ipAdresss;
}

void NETWORK::TcpConnected()
{
    this->IsTcpConnected = true;
}

void NETWORK::TcpDisconnected()
{
    this->IsTcpConnected = false;
}

void NETWORK::TcpReadyRead()
{
    if(this->myTcpSocket.bytesAvailable() >= 40)
    {
        uint8_t buffer[40];
        this->myTcpSocket.read((char *)buffer, sizeof(buffer));
        if((buffer[0] == 0X88) && (buffer[1] == 0X88) && (buffer[38] == 0X88) && (buffer[39] == 0X88))
        {
            F2U32DataTypedef temp;

            temp.u32Data = ((uint32_t)buffer[2] << 24)|((uint32_t)buffer[3] << 16)|((uint32_t)buffer[4] << 8)|((uint32_t)buffer[5]);
            this->pidPramData.XP = temp.fData;
            temp.u32Data = ((uint32_t)buffer[6] << 24)|((uint32_t)buffer[7] << 16)|((uint32_t)buffer[8] << 8)|((uint32_t)buffer[9]);
            this->pidPramData.XI = temp.fData;
            temp.u32Data = ((uint32_t)buffer[10] << 24)|((uint32_t)buffer[11] << 16)|((uint32_t)buffer[12] << 8)|((uint32_t)buffer[13]);
            this->pidPramData.XD = temp.fData;

            temp.u32Data = ((uint32_t)buffer[14] << 24)|((uint32_t)buffer[15] << 16)|((uint32_t)buffer[16] << 8)|((uint32_t)buffer[17]);
            this->pidPramData.YP = temp.fData;
            temp.u32Data = ((uint32_t)buffer[18] << 24)|((uint32_t)buffer[19] << 16)|((uint32_t)buffer[20] << 8)|((uint32_t)buffer[21]);
            this->pidPramData.YI = temp.fData;
            temp.u32Data = ((uint32_t)buffer[22] << 24)|((uint32_t)buffer[23] << 16)|((uint32_t)buffer[24] << 8)|((uint32_t)buffer[25]);
            this->pidPramData.YD = temp.fData;

            temp.u32Data = ((uint32_t)buffer[26] << 24)|((uint32_t)buffer[27] << 16)|((uint32_t)buffer[28] << 8)|((uint32_t)buffer[29]);
            this->pidPramData.ZP = temp.fData;
            temp.u32Data = ((uint32_t)buffer[30] << 24)|((uint32_t)buffer[31] << 16)|((uint32_t)buffer[32] << 8)|((uint32_t)buffer[33]);
            this->pidPramData.ZI = temp.fData;
            temp.u32Data = ((uint32_t)buffer[34] << 24)|((uint32_t)buffer[35] << 16)|((uint32_t)buffer[36] << 8)|((uint32_t)buffer[37]);
            this->pidPramData.ZD = temp.fData;

            qDebug()<<"this->pidPramData.XP : " << this->pidPramData.XP;
            qDebug()<<"this->pidPramData.XI : " << this->pidPramData.XI;
            qDebug()<<"this->pidPramData.XD : " << this->pidPramData.XD;

            qDebug()<<"this->pidPramData.YP : " << this->pidPramData.YP;
            qDebug()<<"this->pidPramData.YI : " << this->pidPramData.YI;
            qDebug()<<"this->pidPramData.YD : " << this->pidPramData.YD;

            qDebug()<<"this->pidPramData.ZP : " << this->pidPramData.ZP;
            qDebug()<<"this->pidPramData.ZI : " << this->pidPramData.ZI;
            qDebug()<<"this->pidPramData.ZD : " << this->pidPramData.ZD;

            this->pidPramData.Update = true;

        }
    }
}

uint32_t NETWORK::SendData(const char * data, uint32_t length)
{

    if(this->IsTcpConnected)
    {
        QTime timeUsed;
        timeUsed.start();

        this->myTcpSocket.write(data, length);
        this->myTcpSocket.waitForBytesWritten();

        return timeUsed.elapsed();

    }else
    {
        QTime timeUsed;
        timeUsed.start();
        this->myTcpSocket.abort();
        this->myTcpSocket.connectToHost(this->hostAddr, this->hostPort);
        this->myTcpSocket.waitForConnected();

        return timeUsed.elapsed();
    }
}
