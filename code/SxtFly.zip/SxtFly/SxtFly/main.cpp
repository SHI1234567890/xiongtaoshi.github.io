#include <QCoreApplication>
#define __USER_GNU

#include "sched.h"

#include "QDebug"

#include "Hardware/hardware.h"

void SetTaskToCpu3(void)
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(3, &mask);
    if(sched_setaffinity(0, sizeof(mask), &mask) < 0)
    {
        qDebug()<<"SetTaskToCpu3 Failed";
    }else
    {
        qDebug()<<"SetTaskToCpu3 Succeed";
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    SetTaskToCpu3();

    while(HardwareInit() == HAL_ERROR)
    {

    }

    return a.exec();
}
