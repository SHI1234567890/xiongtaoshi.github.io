#ifndef RC_H
#define RC_H

#include "Typedef/typedef.h"
#include "QDebug"

class RC
{
public:
    RC();
    ~RC();

    uint32_t time20Ms;

    RcDataTypedef myRcData;

    void Update(RcSensorDataTypedef * rcSensorData);
};

#endif // RC_H
