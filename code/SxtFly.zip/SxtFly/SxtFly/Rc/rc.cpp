
#include "Rc/rc.h"

//在遥控器开始使用之前最终，首先进行设置
//最左上角的开关，掰上来
//下面的6个开关，状态依次是 下 下 上 下 上 下
//设置完成之后，达到的效果为 下和左为最小值 上和右为最大值
//把微调开关全部调整到最左面 和 最下面
//通道说明
//通道1   右手上下    下小上大    最小值1006 中间值1400 最大值1808
//通道2   右手左右    左小右大    最小值1006 中间值1410 最大值1799
//通道3   左手上下    下小上大    最小值1006 中间值1506 最大值2007
//通道4   左手左右    左小右大    最小值1006 中间值1400 最大值1808
//通道5   下大上小              最下值1010   最大值2007
//通道6   顺时针增大             最小值1006     最大值2007

RC::RC()
{
    this->time20Ms = 0;
    this->myRcData.MotoOnFlag = false;

    this->myRcData.TarAngleXTheta = 0;
    this->myRcData.TarAngleYGama = 0;
    this->myRcData.TarAngleZPhi = 0;

    this->myRcData.TarHeight = 0;

    this->myRcData.TarPosX = 0;
    this->myRcData.TarPosY = 0;
    this->myRcData.TarPosZ = 0;
}

RC::~RC()
{

}

void RC::Update(RcSensorDataTypedef *rcSensorData)
{
    if((rcSensorData->channel1 == 0) || (rcSensorData->channel2 == 0) ||
       (rcSensorData->channel3 == 0) || (rcSensorData->channel4 == 0) ||
       (rcSensorData->channel5 == 0) || (rcSensorData->channel6 == 0))
    {
        return;
    }

    if(++this->time20Ms >= 20)
    {
        this->time20Ms = 0;

        //开关判断
        if(rcSensorData->channel5 < rcSensorData->channel5Midd)
        {
            this->myRcData.MotoOnFlag = true;
        }else
        {
            this->myRcData.MotoOnFlag = false;
        }

        //X轴目标值计算 通道2
        this->myRcData.TarAngleXTheta =
                ((float)(rcSensorData->channel2 - rcSensorData->channel2Midd) /
                 (float)rcSensorData->channel2Length) * 20.0f;

        //Y轴目标值计算 通道1
        this->myRcData.TarAngleYGama =
                ((float)(rcSensorData->channel1 - rcSensorData->channel1Midd) /
                 (float)rcSensorData->channel1Length) * 20.0f;

        //Z轴目标值计算 通道4
        this->myRcData.TarAngleZPhi =
                ((float)(rcSensorData->channel4 - rcSensorData->channel4Midd) /
                 (float)rcSensorData->channel4Length) * 20.0f;

        //油门 通道3
        this->myRcData.Throttle = rcSensorData->channel3 - rcSensorData->channel3Min;
    }
}
