#ifndef HEIGHTFILTER_H
#define HEIGHTFILTER_H

#include "Typedef/typedef.h"
#include "Filter/KalmanFilter/kalmanfilter.h"
#include "QDebug"

class HEIGHTFILTER
{
public:
    HEIGHTFILTER();
    ~HEIGHTFILTER();

    KALMANFILTER myKalmanFilter;

    bool IsHeightFirst;

    void Update(float * height);
};

#endif // HEIGHTFILTER_H
