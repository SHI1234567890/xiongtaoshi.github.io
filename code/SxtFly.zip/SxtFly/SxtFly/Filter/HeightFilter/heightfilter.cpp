#include "Filter/HeightFilter/heightfilter.h"

HEIGHTFILTER::HEIGHTFILTER()
{

    this->IsHeightFirst = true;

    this->myKalmanFilter.Init(1);
    //卡尔曼滤波增益矩阵K
    this->myKalmanFilter.K.at<float>(0,0) = 1.0f;

    //均方误差矩阵P
    this->myKalmanFilter.P.at<float>(0,0) = 1.0f;

    //系统噪声方差阵Q
    this->myKalmanFilter.Q.at<float>(0,0) = 0.001f;

    //量测噪声方差阵R
    this->myKalmanFilter.R.at<float>(0,0) = 1.0f;

    //系统一步状态转移矩阵phi
    this->myKalmanFilter.phi.at<float>(0,0) = 1.0f;

    //测量矩阵Z

    //状态矩阵X

    //观测矩阵H
    this->myKalmanFilter.H.at<float>(0,0) = 1.0f;

    //系统噪声驱动阵F
    this->myKalmanFilter.F.at<float>(0,0) = 1.0f;

    //I矩阵（对角线单位矩阵）
}

HEIGHTFILTER::~HEIGHTFILTER()
{

}

void HEIGHTFILTER::Update(float *height)
{
    if(this->IsHeightFirst)
    {
        this->IsHeightFirst = false;
        this->myKalmanFilter.X.at<float>(0,0) = *height;

        return;
    }
    this->myKalmanFilter.Z.at<float>(0,0) = *height;


    this->myKalmanFilter.Update();

    *height = this->myKalmanFilter.X.at<float>(0, 0);

}
