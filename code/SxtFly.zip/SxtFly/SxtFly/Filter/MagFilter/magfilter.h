#ifndef MAGFILTER_H
#define MAGFILTER_H

#include "Filter/KalmanFilter/kalmanfilter.h"
#include "Typedef/typedef.h"
#include "QDebug"

class MAGFILTER
{
public:
    MAGFILTER();
    ~MAGFILTER();

    KALMANFILTER myKalmanFilter;

    bool IsMagFirst;

    void Update(MagDataTypedef * magData);

};

#endif // MAGFILTER_H
