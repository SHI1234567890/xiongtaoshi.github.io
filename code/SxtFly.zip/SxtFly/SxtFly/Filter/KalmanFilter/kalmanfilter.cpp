#include "Filter/KalmanFilter/kalmanfilter.h"

KALMANFILTER::KALMANFILTER()
{

}

KALMANFILTER::~KALMANFILTER()
{

}

void KALMANFILTER::Init(uint32_t filterOrder)
{
    //卡尔曼滤波增益矩阵
    this->K = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //均方误差矩阵(衡量预测值的好坏)
    this->P = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //系统噪声方差阵（真值的噪声）
    this->Q = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //量测噪声方差阵
    this->R = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //系统一步状态转移矩阵
    this->phi = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //测量矩阵
    this->Z = Mat::zeros(filterOrder, 1, CV_32FC1);
    //状态矩阵
    this->X = Mat::zeros(filterOrder, 1, CV_32FC1);
    //观测矩阵
    this->H = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //系统噪声驱动阵
    this->F = Mat::zeros(filterOrder, filterOrder, CV_32FC1);
    //I矩阵（对角线单位矩阵）
    this->I = Mat::eye(filterOrder, filterOrder, CV_32FC1);
}

void KALMANFILTER::Update()
{
    //一步状态预测
    this->X = this->phi * this->X;
    //一步状态预测的优劣情况利用均方误差矩阵进行评判
    this->P = this->phi * this->P * this->phi.t() + this->F * this->Q * this->F.t();
    //更新卡尔曼滤波增益矩阵
    this->K = this->P * this->H.t() * (this->H * this->P * this->H.t() + this->R).inv();
    //使用测量值Z来矫正预测值X
    this->X = this->X + this->K * (this->Z - this->H * this->X);
    //更新均方误差矩阵P
    this->P = (this->I - this->K * this->H) * this->P;
}
