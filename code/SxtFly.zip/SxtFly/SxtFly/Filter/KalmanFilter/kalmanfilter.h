#ifndef KALMANFILTER_H
#define KALMANFILTER_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "opencv2/opencv.hpp"
using namespace cv;

class KALMANFILTER
{
public:
    KALMANFILTER();
    ~KALMANFILTER();

    //卡尔曼滤波增益矩阵
    Mat K;
    //均方误差
    Mat P;
    //系统噪声方差阵
    Mat Q;
    //量测噪声方差阵
    Mat R;
    //系统一步状态转移矩阵
    Mat phi;
    //测量矩阵
    Mat Z;
    //状态矩阵
    Mat X;
    //观测矩阵
    Mat H;
    //系统噪声驱动阵
    Mat F;
    //I矩阵（对角线单位矩阵）
    Mat I;

    void Init(uint32_t filterOrder);

    void Update(void);

};

#endif // KALMANFILTER_H
