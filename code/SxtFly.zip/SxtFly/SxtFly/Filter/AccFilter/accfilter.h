#ifndef ACCFILTER_H
#define ACCFILTER_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "Filter/KalmanFilter/kalmanfilter.h"

class ACCFILTER
{
public:
    ACCFILTER();
    ~ACCFILTER();

    KALMANFILTER myKalmanFilter;

    bool IsAccFirst;

    void Update(AccDataTypedef * accData);
};

#endif // ACCFILTER_H
