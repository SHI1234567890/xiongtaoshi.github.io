#include "Hardware/hardware.h"

MAINTASK myMainTask;

HAL_StatusTypedef HardwareInit()
{
    //提升优先级到99
    if(piHiPri(99) < 0)
    {
        qDebug() << "Unable to Higher Pri to 99";
        //return HAL_ERROR;
    }else
    {
        qDebug() << "be able to Higher Pri to 99";
    }

    //初始化GPIO库
    if(wiringPiSetup() < 0)
    {
        qDebug() << "Unable to init WiringPi Library";
        //return HAL_ERROR;
    }else
    {
        qDebug() << "be able to init WiringPi Library";
    }

    //通知单片机，树莓派已经准备好
    pinMode(SPI_IRQ_PIN, OUTPUT);
    digitalWrite(SPI_IRQ_PIN, 1);
    delay(10);
    digitalWrite(SPI_IRQ_PIN, 0);
    delay(20);

    //初始化SPI
    if(wiringPiSPISetup(0, SPI_SPEED) < 0)
    {
        qDebug() << "unable to init wiringPi Spi library";
        //return HAL_ERROR;
    }else
    {
        qDebug() << "be able to init wiringPi Spi library";
    }

    //初始化中断,中断优先级为99
    if(wiringPiISR(SPI_IRQ_PIN, INT_EDGE_BOTH, &IsrCallback) < 0)
    {
        qDebug() << "Unable to init WiringPi Interupt Library";
        return HAL_ERROR;
    }else
    {
        qDebug() << "be able to init WiringPi Interupt Library";
    }


    //降低main函数优先级到50
    if(piHiPri(50) < 0)
    {
        qDebug() << "Unable to Lower Pri to 50";
        //return HAL_ERROR;
    }else
    {
        qDebug() << "be able to Lower Pri to 50";
    }

    //创建网络的线程,优先级是50
    myMainTask.StartNetworkThread();

    //降低main函数优先级到1
    if(piHiPri(1) < 0)
    {
        qDebug() << "Unable to Lower Pri to 1";
        //return HAL_ERROR;
    }else
    {
        qDebug() << "be able to Lower Pri to 1";
    }

    //开启运行定时器,优先级是1
    myMainTask.StartIdleThread();

    return HAL_OK;
}

void IsrCallback()
{
    if(myMainTask.EncodeData() == HAL_OK)
    {
        wiringPiSPIDataRW(0, myMainTask.SpiBuff, sizeof(myMainTask.SpiBuff));
        if(myMainTask.DecodeData() == HAL_OK)
        {
            myMainTask.CalcAlgorithm();
        }
    }
}
