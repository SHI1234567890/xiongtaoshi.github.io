#ifndef HARDWARE_H
#define HARDWARE_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "MainTask/maintask.h"

#include "/home/pi/SxtGlobalLibrary/WiringPi/wiringPi/wiringPi.h"
#include "/home/pi/SxtGlobalLibrary/WiringPi/wiringPi/wiringPiSPI.h"

#define SPI_IRQ_PIN (4)
#define SPI_SPEED   (18000000)

HAL_StatusTypedef HardwareInit(void);

void IsrCallback(void);

#endif // HARDWARE_H
