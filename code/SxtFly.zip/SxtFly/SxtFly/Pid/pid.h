#ifndef PID_H
#define PID_H

#include "Typedef/typedef.h"
#include "QDebug"

class PID
{
public:
    PID();
    ~PID();

    PidDataTypedef myPidData;

    float Update(float Target, float Measure);
    void Clean(void);
};

#endif // PID_H
