#include "Pid/pid.h"

PID::PID()
{
    this->myPidData.P = 0;
    this->myPidData.I = 0;
    this->myPidData.D = 0;
    this->myPidData.Error = 0;
    this->myPidData.ErrorLast = 0;
    this->myPidData.Out = 0;
    this->myPidData.Int = 0;
    this->myPidData.Diff = 0;
    this->myPidData.IntSep = 0;
    this->myPidData.IntMax = 0;
    this->myPidData.OutMax = 0;

    this->myPidData.UpdateTime = 0;
}

PID::~PID()
{

}

float PID::Update(float Target, float Measure)
{
    this->myPidData.Error = Target - Measure;

    //计算微分
    this->myPidData.Diff = (this->myPidData.Error - this->myPidData.ErrorLast) / this->myPidData.UpdateTime;

    //计算积分
    //积分分离和抗饱和v积分的实现
    if((this->myPidData.Error < this->myPidData.IntSep) && (this->myPidData.Error > -this->myPidData.IntSep))
    {
        if(this->myPidData.Int > this->myPidData.IntMax)
        {
            if(this->myPidData.Error < 0.0f)
            {
                this->myPidData.Int += this->myPidData.Error * this->myPidData.UpdateTime;
            }
        }else if(this->myPidData.Int < -this->myPidData.IntMax)
        {
            if(this->myPidData.Error > 0.0f)
            {
                this->myPidData.Int += this->myPidData.Error * this->myPidData.UpdateTime;
            }
        }else
        {
            this->myPidData.Int += this->myPidData.Error * this->myPidData.UpdateTime;
        }
    }

    //更新偏差
    this->myPidData.ErrorLast = this->myPidData.Error;

    //计算PID输出的控制值
    this->myPidData.Out = this->myPidData.Error * this->myPidData.P +
                           this->myPidData.Int * this->myPidData.I +
                            this->myPidData.Diff * this->myPidData.D;

    if(this->myPidData.Out > this->myPidData.OutMax)
    {
        this->myPidData.Out = this->myPidData.OutMax;
    }else if(this->myPidData.Out < -this->myPidData.OutMax)
    {
        this->myPidData.Out = -this->myPidData.OutMax;
    }

    return this->myPidData.Out;
}

void PID::Clean()
{
    this->myPidData.Error = 0;
    this->myPidData.ErrorLast = 0;
    this->myPidData.Out = 0;
    this->myPidData.Int = 0;
    this->myPidData.Diff = 0;
}
