#include "Sensor/sensor.h"

SENSOR::SENSOR()
{
    //传感器数据初始化
    this->mpu6050Data1.Mpu6050AccX = 0;
    this->mpu6050Data1.Mpu6050AccY = 0;
    this->mpu6050Data1.Mpu6050AccZ = 0;
    this->mpu6050Data1.Mpu6050Temp = 0;
    this->mpu6050Data1.Mpu6050GyroX = 0;
    this->mpu6050Data1.Mpu6050GyroY = 0;
    this->mpu6050Data1.Mpu6050GyroZ = 0;

    this->mpu6050Data2.Mpu6050AccX = 0;
    this->mpu6050Data2.Mpu6050AccY = 0;
    this->mpu6050Data2.Mpu6050AccZ = 0;
    this->mpu6050Data2.Mpu6050Temp = 0;
    this->mpu6050Data2.Mpu6050GyroX = 0;
    this->mpu6050Data2.Mpu6050GyroY = 0;
    this->mpu6050Data2.Mpu6050GyroZ = 0;

    this->hmc5883Data1.HmcMagX = 0;
    this->hmc5883Data1.HmcMagY = 0;
    this->hmc5883Data1.HmcMagZ = 0;

    this->hmc5883Data2.HmcMagX = 0;
    this->hmc5883Data2.HmcMagY = 0;
    this->hmc5883Data2.HmcMagZ = 0;

    this->msData1.Ms5611P = 0;
    this->msData2.Ms5611P = 0;

    this->gpsData.IsFixOk = 0;
    this->gpsData.numSv = 0;
    this->gpsData.longitude = 0;
    this->gpsData.latitude = 0;
    this->gpsData.Height = 0;
    this->gpsData.vAcc = 0;
    this->gpsData.hAcc = 0;
    this->gpsData.velN = 0;
    this->gpsData.velE = 0;
    this->gpsData.velD = 0;
    this->gpsData.fLongitudeAngle = 0;
    this->gpsData.fLongitudeRadian = 0;
    this->gpsData.fLatitudeAngle = 0;
    this->gpsData.fLatitudeRadian = 0;
    this->gpsData.fHeight = 0;
    this->gpsData.Angle2Radian = (M_PI / 180.0);

    //通道说明
    //通道1   右手上下    下小上大    最小值1006 中间值1400 最大值1808
    //通道2   右手左右    左小右大    最小值1006 中间值1410 最大值1799
    //通道3   左手上下    下小上大    最小值1006 中间值1506 最大值2007
    //通道4   左手左右    左小右大    最小值1006 中间值1400 最大值1808
    //通道5   下大上小              最下值1010   最大值2007
    //通道6   顺时针增大             最小值1006     最大值2007
    this->rcSensorData.channel1 = 0;
    this->rcSensorData.channel2 = 0;
    this->rcSensorData.channel3 = 0;
    this->rcSensorData.channel4 = 0;
    this->rcSensorData.channel5 = 0;
    this->rcSensorData.channel6 = 0;

    this->rcSensorData.channel1Min = 1006;
    this->rcSensorData.channel1Max = 1808;
    this->rcSensorData.channel1Midd = (this->rcSensorData.channel1Min + this->rcSensorData.channel1Max) / 2;
    this->rcSensorData.channel1Length = (this->rcSensorData.channel1Max - this->rcSensorData.channel1Min);

    this->rcSensorData.channel2Min = 1006;
    this->rcSensorData.channel2Max = 1799;
    this->rcSensorData.channel2Midd = (this->rcSensorData.channel2Min + this->rcSensorData.channel2Max) / 2;
    this->rcSensorData.channel2Length = (this->rcSensorData.channel2Max - this->rcSensorData.channel2Min);

    this->rcSensorData.channel3Min = 1006;
    this->rcSensorData.channel3Max = 2007;
    this->rcSensorData.channel3Midd = (this->rcSensorData.channel3Min + this->rcSensorData.channel3Max) / 2;
    this->rcSensorData.channel3Length = (this->rcSensorData.channel3Max - this->rcSensorData.channel3Min);

    this->rcSensorData.channel4Min = 1006;
    this->rcSensorData.channel4Max = 1808;
    this->rcSensorData.channel4Midd = (this->rcSensorData.channel4Min + this->rcSensorData.channel4Max) / 2;
    this->rcSensorData.channel4Length = (this->rcSensorData.channel4Max - this->rcSensorData.channel4Min);

    this->rcSensorData.channel5Min = 1010;
    this->rcSensorData.channel5Max = 2007;
    this->rcSensorData.channel5Midd = (this->rcSensorData.channel5Min + this->rcSensorData.channel5Max) / 2;
    this->rcSensorData.channel5Length = (this->rcSensorData.channel5Max - this->rcSensorData.channel5Min);

    this->rcSensorData.channel6Min = 1006;
    this->rcSensorData.channel6Max = 2007;
    this->rcSensorData.channel6Midd = (this->rcSensorData.channel6Min + this->rcSensorData.channel6Max) / 2;
    this->rcSensorData.channel6Length = (this->rcSensorData.channel6Max - this->rcSensorData.channel6Min);

    //Mpu6050传感器偏差初始化保留
    this->mpu6050Data1Init.Mpu6050AccX = 0;
    this->mpu6050Data1Init.Mpu6050AccY = 0;
    this->mpu6050Data1Init.Mpu6050AccZ = 0;
    this->mpu6050Data1Init.Mpu6050Temp = 0;
    this->mpu6050Data1Init.Mpu6050GyroX = -54;
    this->mpu6050Data1Init.Mpu6050GyroY = 10;
    this->mpu6050Data1Init.Mpu6050GyroZ = 4;

    this->mpu6050Data2Init.Mpu6050AccX = 0;
    this->mpu6050Data2Init.Mpu6050AccY = 0;
    this->mpu6050Data2Init.Mpu6050AccZ = 0;
    this->mpu6050Data2Init.Mpu6050Temp = 0;
    this->mpu6050Data2Init.Mpu6050GyroX = -267;
    this->mpu6050Data2Init.Mpu6050GyroY = -29;
    this->mpu6050Data2Init.Mpu6050GyroZ = -58;

    //Ms5611偏差量初始化
    this->msData1Init.isCalied = false;
    this->msData1Init.heightAve = 0;
    this->msData1Init.heightSum = 0;
    this->msData1Init.sum100 = 0;
    this->msData1Init.wait50 = 0;

    this->msData2Init.isCalied = false;
    this->msData2Init.heightAve = 0;
    this->msData2Init.heightSum = 0;
    this->msData2Init.sum100 = 0;
    this->msData2Init.wait50 = 0;

    this->IsrReadTimes = 0;
    this->sensorReadTimes = 0;
    this->errorRate = 0;

    //hmc5883初始化
    this->hmc5883Data1Init.magXMax = 1.0f;
    this->hmc5883Data1Init.magXMin = -1.0f;
    this->hmc5883Data1Init.magXCenter = (this->hmc5883Data1Init.magXMax + this->hmc5883Data1Init.magXMin)/2;
    this->hmc5883Data1Init.magXLength = this->hmc5883Data1Init.magXMax -this->hmc5883Data1Init.magXMin;

    this->hmc5883Data1Init.magYMax = 1.0f;
    this->hmc5883Data1Init.magYMin = -1.0f;
    this->hmc5883Data1Init.magYCenter = (this->hmc5883Data1Init.magYMax + this->hmc5883Data1Init.magYMin)/2;
    this->hmc5883Data1Init.magYLength = this->hmc5883Data1Init.magYMax -this->hmc5883Data1Init.magYMin;

    this->hmc5883Data1Init.magZMax = 1.0f;
    this->hmc5883Data1Init.magZMin = -1.0f;
    this->hmc5883Data1Init.magZCenter = (this->hmc5883Data1Init.magZMax + this->hmc5883Data1Init.magZMin)/2;
    this->hmc5883Data1Init.magZLength = this->hmc5883Data1Init.magZMax -this->hmc5883Data1Init.magZMin;

    this->hmc5883Data2Init.magXMax = 1.0f;
    this->hmc5883Data2Init.magXMin = -1.0f;
    this->hmc5883Data2Init.magXCenter = (this->hmc5883Data2Init.magXMax + this->hmc5883Data2Init.magXMin)/2;
    this->hmc5883Data2Init.magXLength = this->hmc5883Data2Init.magXMax -this->hmc5883Data2Init.magXMin;

    this->hmc5883Data2Init.magYMax = 1.0f;
    this->hmc5883Data2Init.magYMin = -1.0f;
    this->hmc5883Data2Init.magYCenter = (this->hmc5883Data2Init.magYMax + this->hmc5883Data2Init.magYMin)/2;
    this->hmc5883Data2Init.magYLength = this->hmc5883Data2Init.magYMax -this->hmc5883Data2Init.magYMin;

    this->hmc5883Data2Init.magZMax = 1.0f;
    this->hmc5883Data2Init.magZMin = -1.0f;
    this->hmc5883Data2Init.magZCenter = (this->hmc5883Data2Init.magZMax + this->hmc5883Data2Init.magZMin)/2;
    this->hmc5883Data2Init.magZLength = this->hmc5883Data2Init.magZMax -this->hmc5883Data2Init.magZMin;


    //气压计计算周期
    this->time20Ms = 0;
}

SENSOR::~SENSOR()
{

}

void SENSOR::Update()
{
    this->mpu6050Data1.Mpu6050AccX -= this->mpu6050Data1Init.Mpu6050AccX;
    this->mpu6050Data1.Mpu6050AccY -= this->mpu6050Data1Init.Mpu6050AccY;
    this->mpu6050Data1.Mpu6050AccZ -= this->mpu6050Data1Init.Mpu6050AccZ;

    //将加速度计的数据转为正的坐标系中
    this->mpu6050Data1.Mpu6050AccX = -this->mpu6050Data1.Mpu6050AccX;
    this->mpu6050Data1.Mpu6050AccY = -this->mpu6050Data1.Mpu6050AccY;
    this->mpu6050Data1.Mpu6050AccZ = -this->mpu6050Data1.Mpu6050AccZ;

    this->mpu6050Data1.Mpu6050Temp -= this->mpu6050Data1Init.Mpu6050Temp;
    this->mpu6050Data1.Mpu6050GyroX -= this->mpu6050Data1Init.Mpu6050GyroX;
    this->mpu6050Data1.Mpu6050GyroY -= this->mpu6050Data1Init.Mpu6050GyroY;
    this->mpu6050Data1.Mpu6050GyroZ -= this->mpu6050Data1Init.Mpu6050GyroZ;

    this->mpu6050Data2.Mpu6050AccX -= this->mpu6050Data2Init.Mpu6050AccX;
    this->mpu6050Data2.Mpu6050AccY -= this->mpu6050Data2Init.Mpu6050AccY;
    this->mpu6050Data2.Mpu6050AccZ -= this->mpu6050Data2Init.Mpu6050AccZ;

    //将加速度计的数据转为正的坐标系中
    this->mpu6050Data2.Mpu6050AccX = -this->mpu6050Data2.Mpu6050AccX;
    this->mpu6050Data2.Mpu6050AccY = -this->mpu6050Data2.Mpu6050AccY;
    this->mpu6050Data2.Mpu6050AccZ = -this->mpu6050Data2.Mpu6050AccZ;

    this->mpu6050Data2.Mpu6050Temp -= this->mpu6050Data2Init.Mpu6050Temp;
    this->mpu6050Data2.Mpu6050GyroX -= this->mpu6050Data2Init.Mpu6050GyroX;
    this->mpu6050Data2.Mpu6050GyroY -= this->mpu6050Data2Init.Mpu6050GyroY;
    this->mpu6050Data2.Mpu6050GyroZ -= this->mpu6050Data2Init.Mpu6050GyroZ;

    //将磁力计数据进行矫正
    this->hmc5883Data1.HmcMagX -= this->hmc5883Data1Init.magXCenter;
    this->hmc5883Data1.HmcMagY -= this->hmc5883Data1Init.magYCenter;
    this->hmc5883Data1.HmcMagZ -= this->hmc5883Data1Init.magZCenter;

    this->hmc5883Data1.HmcMagY = (float)this->hmc5883Data1.HmcMagY *
                                (this->hmc5883Data1Init.magXLength /this->hmc5883Data1Init.magYLength);
    this->hmc5883Data1.HmcMagZ = (float)this->hmc5883Data1.HmcMagZ *
                                (this->hmc5883Data1Init.magXLength /this->hmc5883Data1Init.magZLength);

    this->hmc5883Data2.HmcMagX -= this->hmc5883Data2Init.magXCenter;
    this->hmc5883Data2.HmcMagY -= this->hmc5883Data2Init.magYCenter;
    this->hmc5883Data2.HmcMagZ -= this->hmc5883Data2Init.magZCenter;

    this->hmc5883Data2.HmcMagY = (float)this->hmc5883Data2.HmcMagY *
                                (this->hmc5883Data2Init.magXLength /this->hmc5883Data2Init.magYLength);
    this->hmc5883Data2.HmcMagZ = (float)this->hmc5883Data2.HmcMagZ *
                                (this->hmc5883Data2Init.magXLength /this->hmc5883Data2Init.magZLength);

    //气压计计算周期
    this->time20Ms++;
    if(this->time20Ms >= 20)
    {
        this->time20Ms = 0;
        this->msData1.fp = (float)this->msData1.Ms5611P / 100.0f;
        this->msData2.fp = (float)this->msData2.Ms5611P / 100.0f;

        this->msData1.height = 44300.0f * (1 - pow(this->msData1.fp /1013.25f , 0.190284f));
        this->msData2.height = 44300.0f * (1 - pow(this->msData2.fp /1013.25f , 0.190284f));

        if(this->msData1Init.isCalied)
        {
            this->msData1.height -= this->msData1Init.heightAve;
        }else
        {
            //
            if(this->msData1.Ms5611P != 0)
            {
                if(++this->msData1Init.wait50 >= 50)
                {
                    this->msData1Init.heightSum += this->msData1.height;
                    if(++this->msData1Init.sum100 >= 100)
                    {
                        this->msData1Init.heightAve = this->msData1Init.heightSum / 100.0;
                        this->msData1.height -= this->msData1Init.heightAve;
                        this->msData1Init.isCalied = true;
                        qDebug()<<"this->msData1Init.heightAve : " << this->msData1Init.heightAve;
                    }
                }
            }
        }

        if(this->msData2Init.isCalied)
        {
            this->msData2.height -= this->msData2Init.heightAve;
        }else
        {
            //
            if(this->msData2.Ms5611P != 0)
            {
                if(++this->msData2Init.wait50 >= 50)
                {
                    this->msData2Init.heightSum += this->msData2.height;
                    if(++this->msData2Init.sum100 >= 100)
                    {
                        this->msData2Init.heightAve = this->msData2Init.heightSum / 100.0;
                        this->msData2.height -= this->msData2Init.heightAve;
                        this->msData2Init.isCalied = true;
                        qDebug()<<"this->msData2Init.heightAve : " << this->msData2Init.heightAve;
                    }
                }
            }
        }
    }

//    if((this->gpsData.IsFixOk) && (this->gpsData.numSv >= 10))
    if(this->gpsData.numSv >= 5)
    {
        //转换经纬度单位
        this->gpsData.fLongitudeAngle = (double)this->gpsData.longitude / 10000000.0;
        this->gpsData.fLongitudeRadian= this->gpsData.fLongitudeAngle * this->gpsData.Angle2Radian;

        this->gpsData.fLatitudeAngle = (double)this->gpsData.latitude / 10000000.0;
        this->gpsData.fLatitudeRadian= this->gpsData.fLatitudeAngle * this->gpsData.Angle2Radian;

        //转换高度
        this->gpsData.fHeight = (double)this->gpsData.Height /1000.0;

    }

}

HAL_StatusTypedef SENSOR::DecodeData(uint8_t * SpiBuff)
{
    if((SpiBuff[0] == 0X88) && (SpiBuff[1] == 0X88) && (SpiBuff[99] == 0X88))
    {
        //累计读数成功次数
        this->IsrReadTimes++;

        this->sensorReadTimes = ((uint32_t)SpiBuff[2] << 24) | ((uint32_t)SpiBuff[3] << 16) |
                                ((uint32_t)SpiBuff[4] << 8) | ((uint32_t)SpiBuff[5]);

        this->error = (this->sensorReadTimes - this->IsrReadTimes);

        this->errorRate = (float)this->error/(float)(this->sensorReadTimes);

        this->mpu6050Data1.Mpu6050AccX = (int16_t)(((uint16_t)SpiBuff[6] << 8) | ((uint16_t)SpiBuff[7]));
        this->mpu6050Data1.Mpu6050AccY = (int16_t)(((uint16_t)SpiBuff[8] << 8) | ((uint16_t)SpiBuff[9]));
        this->mpu6050Data1.Mpu6050AccZ = (int16_t)(((uint16_t)SpiBuff[10] << 8) | ((uint16_t)SpiBuff[11]));
        this->mpu6050Data1.Mpu6050Temp = (int16_t)(((uint16_t)SpiBuff[12] << 8) | ((uint16_t)SpiBuff[13]));
        this->mpu6050Data1.Mpu6050GyroX = (int16_t)(((uint16_t)SpiBuff[14] << 8) | ((uint16_t)SpiBuff[15]));
        this->mpu6050Data1.Mpu6050GyroY = (int16_t)(((uint16_t)SpiBuff[16] << 8) | ((uint16_t)SpiBuff[17]));
        this->mpu6050Data1.Mpu6050GyroZ = (int16_t)(((uint16_t)SpiBuff[18] << 8) | ((uint16_t)SpiBuff[19]));

        this->mpu6050Data2.Mpu6050AccX = (int16_t)(((uint16_t)SpiBuff[20] << 8) | ((uint16_t)SpiBuff[21]));
        this->mpu6050Data2.Mpu6050AccY = (int16_t)(((uint16_t)SpiBuff[22] << 8) | ((uint16_t)SpiBuff[23]));
        this->mpu6050Data2.Mpu6050AccZ = (int16_t)(((uint16_t)SpiBuff[24] << 8) | ((uint16_t)SpiBuff[25]));
        this->mpu6050Data2.Mpu6050Temp = (int16_t)(((uint16_t)SpiBuff[26] << 8) | ((uint16_t)SpiBuff[27]));
        this->mpu6050Data2.Mpu6050GyroX = (int16_t)(((uint16_t)SpiBuff[28] << 8) | ((uint16_t)SpiBuff[29]));
        this->mpu6050Data2.Mpu6050GyroY = (int16_t)(((uint16_t)SpiBuff[30] << 8) | ((uint16_t)SpiBuff[31]));
        this->mpu6050Data2.Mpu6050GyroZ = (int16_t)(((uint16_t)SpiBuff[32] << 8) | ((uint16_t)SpiBuff[33]));

        this->hmc5883Data1.HmcMagX = (int16_t)(((uint16_t)SpiBuff[34] << 8) | ((uint16_t)SpiBuff[35]));
        this->hmc5883Data1.HmcMagZ = (int16_t)(((uint16_t)SpiBuff[36] << 8) | ((uint16_t)SpiBuff[37]));
        this->hmc5883Data1.HmcMagY = (int16_t)(((uint16_t)SpiBuff[38] << 8) | ((uint16_t)SpiBuff[39]));

        this->hmc5883Data2.HmcMagX = (int16_t)(((uint16_t)SpiBuff[40] << 8) | ((uint16_t)SpiBuff[41]));
        this->hmc5883Data2.HmcMagZ = (int16_t)(((uint16_t)SpiBuff[42] << 8) | ((uint16_t)SpiBuff[43]));
        this->hmc5883Data2.HmcMagY = (int16_t)(((uint16_t)SpiBuff[44] << 8) | ((uint16_t)SpiBuff[45]));

        this->msData1.Ms5611P = (int32_t)(((uint32_t)SpiBuff[46] << 24) | ((uint32_t)SpiBuff[47] << 16) |
                                ((uint32_t)SpiBuff[48] << 8) | ((uint32_t)SpiBuff[49]));

        this->msData2.Ms5611P = (int32_t)(((uint32_t)SpiBuff[50] << 24) | ((uint32_t)SpiBuff[51] << 16) |
                                ((uint32_t)SpiBuff[52] << 8) | ((uint32_t)SpiBuff[53]));

        this->gpsData.IsFixOk = ((SpiBuff[54] & 0X80) >> 7);
        this->gpsData.numSv = (SpiBuff[54] & 0X7F);
        this->gpsData.longitude = (int32_t)(((uint32_t)SpiBuff[55] << 24) | ((uint32_t)SpiBuff[56] << 16) |
                ((uint32_t)SpiBuff[57] << 8) | ((uint32_t)SpiBuff[58]));
        this->gpsData.latitude = (int32_t)(((uint32_t)SpiBuff[59] << 24) | ((uint32_t)SpiBuff[60] << 16) |
                ((uint32_t)SpiBuff[61] << 8) | ((uint32_t)SpiBuff[62]));
        this->gpsData.Height = (int32_t)(((uint32_t)SpiBuff[63] << 24) | ((uint32_t)SpiBuff[64] << 16) |
                ((uint32_t)SpiBuff[65] << 8) | ((uint32_t)SpiBuff[66]));
        this->gpsData.hAcc = ((uint32_t)SpiBuff[67] << 24) | ((uint32_t)SpiBuff[68] << 16) |
                ((uint32_t)SpiBuff[69] << 8) | ((uint32_t)SpiBuff[70]);
        this->gpsData.vAcc = ((uint32_t)SpiBuff[71] << 24) | ((uint32_t)SpiBuff[72] << 16) |
                ((uint32_t)SpiBuff[73] << 8) | ((uint32_t)SpiBuff[74]);
        this->gpsData.velN = (int32_t)(((uint32_t)SpiBuff[75] << 24) | ((uint32_t)SpiBuff[76] << 16) |
                ((uint32_t)SpiBuff[77] << 8) | ((uint32_t)SpiBuff[78]));
        this->gpsData.velE = (int32_t)(((uint32_t)SpiBuff[79] << 24) | ((uint32_t)SpiBuff[80] << 16) |
                ((uint32_t)SpiBuff[81] << 8) | ((uint32_t)SpiBuff[82]));
        this->gpsData.velD = (int32_t)(((uint32_t)SpiBuff[83] << 24) | ((uint32_t)SpiBuff[84] << 16) |
                ((uint32_t)SpiBuff[85] << 8) | ((uint32_t)SpiBuff[86]));

        this->rcSensorData.channel1 = ((uint16_t)SpiBuff[87] << 8) | ((uint16_t)SpiBuff[88]);
        this->rcSensorData.channel2 = ((uint16_t)SpiBuff[89] << 8) | ((uint16_t)SpiBuff[90]);
        this->rcSensorData.channel3 = ((uint16_t)SpiBuff[91] << 8) | ((uint16_t)SpiBuff[92]);
        this->rcSensorData.channel4 = ((uint16_t)SpiBuff[93] << 8) | ((uint16_t)SpiBuff[94]);
        this->rcSensorData.channel5 = ((uint16_t)SpiBuff[95] << 8) | ((uint16_t)SpiBuff[96]);
        this->rcSensorData.channel6 = ((uint16_t)SpiBuff[97] << 8) | ((uint16_t)SpiBuff[98]);

        //矫正传感器数据
        this->Update();

        return HAL_OK;
    }else
    {
        return HAL_ERROR;
    }
}

