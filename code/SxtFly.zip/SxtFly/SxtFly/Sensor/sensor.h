#ifndef SENSOR_H
#define SENSOR_H

#include "Typedef/typedef.h"
#include "QDebug"
#include "math.h"

class SENSOR
{
public:
    SENSOR();
    ~SENSOR();

    void Update(void);
    HAL_StatusTypedef DecodeData(uint8_t * SpiBuff);

    //得到加速度数据和陀螺仪数据
    Mpu6050DataTypedef mpu6050Data1;
    Mpu6050DataTypedef mpu6050Data2;

    //手动设置Mpu6050的偏差变量
    Mpu6050DataTypedef mpu6050Data1Init;
    Mpu6050DataTypedef mpu6050Data2Init;


    //hmc5883的数据，得到三个方向磁力计数据
    Hmc5883DataTypedef hmc5883Data1;
    Hmc5883DataTypedef hmc5883Data2;

    //hmc5883矫正
    Hmc5883CaliDataTypedef hmc5883Data1Init;
    Hmc5883CaliDataTypedef hmc5883Data2Init;


    //MS5611的数据，得到气压
    Ms5611DataTypedef msData1;
    Ms5611DataTypedef msData2;

    //自动设置Ms5611偏差变量
    Ms5611CaliDataTypedef msData1Init;
    Ms5611CaliDataTypedef msData2Init;

    //GPS传感器模块数据
    GpsDataTypedef gpsData;

    //遥控器数据据 Remote Control
    RcSensorDataTypedef rcSensorData;

    //单片机读取传感器数据次数
    uint32_t sensorReadTimes;
    //树莓派接受数据系数
    uint32_t IsrReadTimes;
    //数据在单片机和树莓派之间接受的正确率
    float errorRate;

    //错误次数
    uint32_t error;

    //气压计计算周期
    uint32_t time20Ms;
};
#endif // SENSOR_H
