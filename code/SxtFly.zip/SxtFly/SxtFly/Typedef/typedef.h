#ifndef TYPEDEF_H
#define TYPEDEF_H

typedef enum
{
    HAL_OK = 0,
    HAL_ERROR = 1,
}HAL_StatusTypedef;

typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;

typedef signed char         int8_t;
typedef signed short        int16_t;
typedef signed int          int32_t;

typedef struct
{
    int16_t Mpu6050AccX;
    int16_t Mpu6050AccY;
    int16_t Mpu6050AccZ;
    int16_t Mpu6050Temp;
    int16_t Mpu6050GyroX;
    int16_t Mpu6050GyroY;
    int16_t Mpu6050GyroZ;
}Mpu6050DataTypedef;

typedef struct
{
    int16_t HmcMagX;
    int16_t HmcMagY;
    int16_t HmcMagZ;
}Hmc5883DataTypedef;

typedef struct
{
    float magXMax;
    float magXMin;
    float magXCenter;
    float magXLength;

    float magYMax;
    float magYMin;
    float magYCenter;
    float magYLength;

    float magZMax;
    float magZMin;
    float magZCenter;
    float magZLength;
}Hmc5883CaliDataTypedef;

typedef struct
{
    int32_t Ms5611P;

    float fp;
    float P0;

    float height;
}Ms5611DataTypedef;

typedef struct
{
    double heightSum;
    float heightAve;
    uint32_t sum100;
    uint32_t wait50;
    bool isCalied;
}Ms5611CaliDataTypedef;

typedef struct
{
    uint8_t IsFixOk;
    uint8_t numSv;
    int32_t longitude;
    int32_t latitude;
    double fLongitudeAngle;
    double fLongitudeRadian;
    double fLatitudeAngle;
    double fLatitudeRadian;
    int32_t Height;
    double fHeight;
    uint32_t hAcc;
    uint32_t vAcc;
    int32_t velN;
    int32_t velE;
    int32_t velD;
    double Angle2Radian;
}GpsDataTypedef;

typedef struct
{
    double a;
    double b;
    double ee1;

    double W;
    double Angle2Radian;
    double N;

    //空间直角坐标系的XYZ
    double X;
    double Y;
    double Z;

    //东北天坐标系的NEU
    double North;
    double East;
    double Up;

    //东北天坐标原点
    double HomeNorth;
    double HomeEast;
    double HomeUp;

    //
    bool IsSetHome;
}Wgs84DataTypedef;

typedef struct
{
    int16_t channel1;
    int16_t channel2;
    int16_t channel3;
    int16_t channel4;
    int16_t channel5;
    int16_t channel6;

    int16_t channel1Min;
    int16_t channel1Max;
    int16_t channel1Length;
    int16_t channel1Midd;

    int16_t channel2Min;
    int16_t channel2Max;
    int16_t channel2Length;
    int16_t channel2Midd;

    int16_t channel3Min;
    int16_t channel3Max;
    int16_t channel3Length;
    int16_t channel3Midd;

    int16_t channel4Min;
    int16_t channel4Max;
    int16_t channel4Length;
    int16_t channel4Midd;

    int16_t channel5Min;
    int16_t channel5Max;
    int16_t channel5Length;
    int16_t channel5Midd;

    int16_t channel6Min;
    int16_t channel6Max;
    int16_t channel6Length;
    int16_t channel6Midd;
}RcSensorDataTypedef;

typedef struct
{
    bool MotoOnFlag;
    float Throttle;
    float TarAngleXTheta;
    float TarAngleYGama;
    float TarAngleZPhi;
    float TarHeight;
    float TarPosX;
    float TarPosY;
    float TarPosZ;
}RcDataTypedef;

typedef struct
{
    float angleXTheta;
    float angleYGamma;
    //-180~180
    float angleZPhi;
    //
    float angleZPhiLast;
    //
    float toggleTimes;
    //
    float angleZPhiInf;
    //
    float angleZPhiFirst;
    //
    bool isSetFirstAngle;
}AngleDataTypedef;

typedef struct
{
    float North;
    float East;
    float Up;
}PosDataTypedef;

typedef struct
{
    float q0;
    float q1;
    float q2;
    float q3;

    float theta;
    float l;
    float m;
    float n;

    float q0q0;
    float q0q1;
    float q0q2;
    float q0q3;

    float q1q1;
    float q1q2;
    float q1q3;

    float q2q2;
    float q2q3;

    float q3q3;

    float norm;

    //
    uint32_t sampleTime100;
    float angleZPhiSum;
    float angleZPhi;
}QDataTypedef;

typedef struct
{
    float d11;
    float d12;
    float d13;

    float d21;
    float d22;
    float d23;

    float d31;
    float d32;
    float d33;
}DcmDataTypedef;

typedef struct
{
    float wX;
    float wY;
    float wZ;
}WDataTypedef;

typedef struct
{
    float accX;
    float accY;
    float accZ;

    float norm;
}AccDataTypedef;

typedef struct
{
    float magX;
    float magY;
    float magZ;
    float norm;
}MagDataTypedef;

typedef struct
{
    float p;
    float i;

    float intSep;

    float gyroErrorX;
    float gyroErrorY;
    float gyroErrorZ;

    float gyroErrorIX;
    float gyroErrorIY;
    float gyroErrorIZ;
}GyroPiDataTypedef;

typedef struct
{
    float xMin;
    float xCenter;
    float xMax;
    float xLength;

    float yMin;
    float yCenter;
    float yMax;
    float yLength;

    float zMin;
    float zCenter;
    float zMax;
    float zLength;
}MagCaliDataTypedef;

typedef struct
{
    uint16_t moto1;
    uint16_t moto2;
    uint16_t moto3;
    uint16_t moto4;
}MotoDataTypedef;

typedef struct
{
    float P;
    float I;
    float D;

    float Int;
    float Diff;

    float Error;
    float ErrorLast;
    float IntSep;
    float IntMax;

    float Out;
    float OutMax;

    float UpdateTime;
}PidDataTypedef;

typedef struct
{
    float outX;
    float outY;
    float outZ;
    float outH;
}AngConOutDataTypedef;

typedef struct
{
    float XP;
    float XI;
    float XD;

    float YP;
    float YI;
    float YD;

    float ZP;
    float ZI;
    float ZD;

    bool Update;

}PidPramDataTypedef;

typedef union
{
    float fData;
    uint32_t u32Data;
}F2U32DataTypedef;

#endif // TYPEDEF_H
