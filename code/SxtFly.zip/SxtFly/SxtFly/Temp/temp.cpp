//更新姿态
//this->myAccAlgorithm.Update(&this->mySensor.mpu6050Data1, &this->mySensor.mpu6050Data2);
//this->myDcmAlgorithm.Update(&this->mySensor.mpu6050Data1, &this->mySensor.mpu6050Data2,
//                            &this->mySensor.hmc5883Data1, &this->mySensor.hmc5883Data2);

//this->myGyroAlgorithm.Update(&this->mySensor.mpu6050Data1, &this->mySensor.mpu6050Data2);