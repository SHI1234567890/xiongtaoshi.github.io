#ifndef POSITION_H
#define POSITION_H

#include "Filter/HeightFilter/heightfilter.h"
#include "Typedef/typedef.h"
#include "QDebug"
#include "math.h"

class POSITION
{
public:
    POSITION();
    ~POSITION();

    HEIGHTFILTER myHeightFilter;

    PosDataTypedef myPosData;

    Wgs84DataTypedef myWgsData;

    PosDataTypedef myPosData1;

    uint32_t time20Ms;

    uint32_t time200Ms;

    void UpdateHeight(bool isCalied,float *height);
    void Update(GpsDataTypedef * gpsData);
};

#endif // POSITION_H
