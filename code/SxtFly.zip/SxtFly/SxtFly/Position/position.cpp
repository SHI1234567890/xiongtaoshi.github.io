#include "Position/position.h"

POSITION::POSITION()
{
    this->time20Ms = 0;
    this->myPosData.North = 0;
    this->myPosData.East = 0;
    this->myPosData.Up = 0;

    this->myPosData1.North = 0;
    this->myPosData1.East = 0;
    this->myPosData1.Up = 0;

    this->time200Ms = 0;

    this->myWgsData.a = 6378137.0;
    this->myWgsData.b = 6356752.3142;
    this->myWgsData.ee1 = 0.0066943799013;
    this->myWgsData.W = 0;
    this->myWgsData.Angle2Radian = (M_PI / 180.0);
    this->myWgsData.N = 0;

    this->myWgsData.X = 0;
    this->myWgsData.Y = 0;
    this->myWgsData.Z = 0;

    this->myWgsData.North = 0;
    this->myWgsData.East = 0;
    this->myWgsData.Up = 0;

    this->myWgsData.HomeNorth = 0;
    this->myWgsData.HomeEast = 0;
    this->myWgsData.HomeUp = 0;

    this->myWgsData.IsSetHome = false;
}

POSITION::~POSITION()
{

}

void POSITION::UpdateHeight(bool isCalied, float *height)
{
    if(isCalied)
    {
        if(++this->time20Ms >= 20)
        {
            this->time20Ms = 0;
            this->myHeightFilter.Update(height);
            this->myPosData.Up = *height;
        }
    }
}

void POSITION::Update(GpsDataTypedef *gpsData)
{
    if(++this->time200Ms >= 200)
    {
        this->time200Ms = 0;

//        if((gpsData->IsFixOk) && (gpsData->numSv >= 10))
        if((gpsData->numSv >= 5))
        {
            //转换 BLH 到空间直角坐标系
            this->myWgsData.W = sqrt(1.0 - this->myWgsData.ee1 *
                                     sin(gpsData->fLatitudeRadian) * sin(gpsData->fLatitudeRadian));

            this->myWgsData.N = this->myWgsData.a / this->myWgsData.W;

            this->myWgsData.X = (this->myWgsData.N + gpsData->fHeight) * cos(gpsData->fLatitudeRadian) * cos(gpsData->fLongitudeRadian);
            this->myWgsData.Y = (this->myWgsData.N + gpsData->fHeight) * cos(gpsData->fLatitudeRadian) * sin(gpsData->fLongitudeRadian);
            this->myWgsData.Z = (this->myWgsData.N * (1.0 - this->myWgsData.ee1) + gpsData->fHeight) * sin(gpsData->fLatitudeRadian);

            //根据空间直角坐标系到东北天坐标系
            this->myWgsData.North = (- sin(gpsData->fLatitudeRadian) * cos(gpsData->fLongitudeRadian)) * this->myWgsData.X +
                                    (- sin(gpsData->fLongitudeRadian) * this->myWgsData.Y) +
                                    (cos(gpsData->fLatitudeRadian) * cos(gpsData->fLongitudeRadian) * this->myWgsData.Z);
            this->myWgsData.East = (- sin(gpsData->fLatitudeRadian) * sin(gpsData->fLongitudeRadian)) * this->myWgsData.X +
                                    (cos(gpsData->fLongitudeRadian) * this->myWgsData.Y) +
                                    (cos(gpsData->fLatitudeRadian) * sin(gpsData->fLongitudeRadian) * this->myWgsData.Z);
            this->myWgsData.Up = cos(gpsData->fLatitudeRadian) * this->myWgsData.X +
                                sin(gpsData->fLatitudeRadian) * this->myWgsData.Z;

            if(this->myWgsData.IsSetHome)
            {
                this->myWgsData.North -= this->myWgsData.HomeNorth;
                this->myWgsData.East -= this->myWgsData.HomeEast;
                this->myWgsData.Up -= this->myWgsData.HomeUp;
            }else
            {
                this->myWgsData.HomeNorth = this->myWgsData.North;
                this->myWgsData.HomeEast = this->myWgsData.East;
                this->myWgsData.HomeUp = this->myWgsData.Up;

                this->myWgsData.North -= this->myWgsData.HomeNorth;
                this->myWgsData.East -= this->myWgsData.HomeEast;
                this->myWgsData.Up -= this->myWgsData.HomeUp;



                this->myWgsData.IsSetHome = true;
            }

            this->myPosData1.North = this->myWgsData.North;
            this->myPosData1.East = this->myWgsData.East;
            this->myPosData1.Up = this->myWgsData.Up;

//            qDebug() << "this->myWgsData.North  :  " << this->myWgsData.North;
//            qDebug() << "this->myWgsData.East  :  " << this->myWgsData.East;
//            qDebug() << "this->myWgsData.Up  :  " << this->myWgsData.Up;
        }
    }
}
