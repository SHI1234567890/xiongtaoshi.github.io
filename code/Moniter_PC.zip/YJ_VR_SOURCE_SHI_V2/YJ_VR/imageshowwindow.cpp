#include "imageshowwindow.h"
#include "ui_imageshowwindow.h"

/* 构造函数，在这里进行初始化操作 */
ImageShowWindow::ImageShowWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ImageShowWindow)
{
    ui->setupUi(this);

    setMouseTracking(true);

    QSize MainWindowSize;
    /* 获取窗口的高和宽 */
    QDesktopWidget* desktopWidget = QApplication::desktop();
    /* 用户可用窗口大小 */
    //QRect clientRect = desktopWidget->availableGeometry();
    /* 应用程序可用窗口大小 */
    QRect applicationRect = desktopWidget->screenGeometry();

    FullScreenWidth = applicationRect.width();
    FullScreenHeight = applicationRect.height();

    qDebug()<<"applicationRect.width()" + QString::number(FullScreenWidth);
    qDebug()<<"applicationRect.height()" + QString::number(FullScreenHeight);

    mouseMoveNumber = 0;

    /* 默认进行全屏显示 */
    isFullScreenDisplayImage = 1;

    ui->FullScreenDisplayButton->setText("不全屏显示");
    ui->FullScreenDisplayButton->hide();
    ui->BackToMainWindow->hide();

    ui->ImageShowLable->resize(FullScreenWidth, FullScreenHeight);
}

/* 析构函数，在这里进行资源，释放操作 */
ImageShowWindow::~ImageShowWindow()
{
    /* 先调用信号函数 */
    emit WindowDestroy();

    delete ui;
}

/* 给外界的的程序调用的函数，设置现在显示的图像 */
void ImageShowWindow::SetImageData(QImage image)
{
    /* 如果全屏显示，那么进行拉伸图片，在全屏显示按钮点击的时候 */
    if(isFullScreenDisplayImage)
    {
        /* 拉伸 */
        QImage scaledImage = image.scaled(FullScreenWidth, FullScreenHeight);
        /* 设置新图片 */
        ui->ImageShowLable->setPixmap(QPixmap::fromImage(scaledImage));
        /*  */
        //qDebug()<<"image.scaled";
        //qDebug()<<"applicationRect.width()" + QString::number(FullScreenWidth);
        //qDebug()<<"applicationRect.height()" + QString::number(FullScreenHeight);
    }else
    {
        ui->ImageShowLable->setPixmap(QPixmap::fromImage(image));
    }
}

/* 鼠标移动时间的回掉函数 */
void ImageShowWindow::mouseMoveEvent ( QMouseEvent * event )//鼠标移动事件响应
{
    //qDebug()<<"mouseMoveEvent";
    QPoint coursePoint;
    coursePoint = QCursor::pos();//获取当前光标的位置

    int ButtonX = ui->BackToMainWindow->width();
    int ButtonY = ui->BackToMainWindow->height();

    int MousePositionX = coursePoint.x();
    int MousePositionY = coursePoint.y();

    mouseMoveNumber++;

    /* 更新按钮页面 */
    //ui->BackToMainWindow->setText(QString::number(mouseMoveNumber) + "("+QString::number(MousePositionX)+","+QString::number(MousePositionY)+")");

    if(MousePositionX < (2*ButtonX) && (MousePositionY < (2*ButtonY)))
    {
        if(ui->BackToMainWindow->isVisible() == false)
        {
            ui->BackToMainWindow->setVisible(true);
            ui->FullScreenDisplayButton->setVisible(true);
        }
    }else
    {
        if(ui->BackToMainWindow->isVisible() == true)
        {
            ui->BackToMainWindow->setVisible(false);
            ui->FullScreenDisplayButton->setVisible(false);
        }
    }
}

/* 鼠标双击事件的回掉函数 */
void ImageShowWindow::mouseDoubleClickEvent(QMouseEvent *mouseEvent)
{
    //qDebug()<<"mouseDoubleClickEvent";
    this->close();
}

/* 关闭窗口按钮的回掉函数 */
void ImageShowWindow::on_BackToMainWindow_clicked()
{
    this->close();
}

/* 全屏显示 */
void ImageShowWindow::on_FullScreenDisplayButton_clicked()
{
    if(isFullScreenDisplayImage)
    {
        isFullScreenDisplayImage = 0;

        /* 没有进行全屏显示，现在提示进行全屏显示 */
        ui->FullScreenDisplayButton->setText("全屏显示");
    }else
    {
        /* 进行全屏显示 */
        isFullScreenDisplayImage = 1;

        ui->ImageShowLable->resize(FullScreenWidth, FullScreenHeight);
        /* 已经进行了全屏显示，现在设置为，不全屏显示 */
        ui->FullScreenDisplayButton->setText("不全屏显示");
    }
}
