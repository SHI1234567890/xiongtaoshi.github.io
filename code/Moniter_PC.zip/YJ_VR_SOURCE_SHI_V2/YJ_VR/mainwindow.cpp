#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /* 默认使用前摄像头 */
    IsUseBackCamera = false;

    IsPlayAudioFlag = true;

    /* 默认认为，没有初始化过Z轴角度 */
    IsHaveInitZAngle = false;

    /* 头部姿态默认是前带的功能 */
    IsHeaderPoseInBackMode = false;

    /* 隐藏一些控件 */
    ui->uartFrame->hide();
    ui->PictureFrameLable->hide();
    ui->RecvTextEdit->hide();
    ui->SendSerialDataTextEdit->hide();

    ui->CleanAllDataButton->hide();
    ui->HeaderPoseModeButton->hide();
    ui->StartToRecvIamgeButton->hide();
    ui->TestAngleButton->hide();
    ui->RecordInitZAngle->hide();
    ui->UseBackCamera->hide();
    ui->VolumeShowLable->hide();
    ui->OutputShoudCardListComBox->hide();

    /* 初始设置 */
    ui->TcpStateLable->setText("TCP未连接");

    /* 测试程序 */
    SendSerialDataTestIndex = 0;

    TestAngleIndex = 0;

    /* 标志没有记录Z轴数据 */
    isRecordInitZAngleFlag = 0;
    isStartToRecvImage = 0;

    /* 清空串口接受数据 */
    MainSerialRecvData.clear();

    OneFrameAllDataSize = 0;
    OneImageSize = 0;
    OneAudioSize = 0;

    MainSerialBaudRate = 115200;
    MainSerialPortRecvFrameNumber = 0;
    MainSerialPortRecvErrorFrameNumber = 0;
    MainSerialPortOneFrameSize = 18;
    recvFrameNumberInSecoend = 0;

    MainSerialPorRecvFrameRate = 0;

    /* 初始化服务器UDP端口 */
    udpSocketServerPort = 44444;
    udpSockerServerAddress.setAddress("192.168.1.51");

    /* 初始化TCP服务器端口 */
    tcpSocketServerPort = 55555;

    /* 新建串口类 */
    MainSerial = new QSerialPort();

    if(MainSerial != NULL)
    {
        /* 查找可用串口 */
        foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            QSerialPort serial;
            serial.setPort(info);
            /* 判断端口是否能打开 */
            if(serial.open(QIODevice::ReadWrite))
            {
                int isHaveItemInList = 0;
                /* 判断是不是已经在列表中了 */
                for(int i=0; i<ui->MainSerialPortNumber->count(); i++)
                {
                    /* 如果，已经在列表中了，那么不添加这一项了就 */
                    if(ui->MainSerialPortNumber->itemData(i) == serial.portName())
                    {
                        isHaveItemInList++;
                    }
                }

                if(isHaveItemInList == 0)
                {
                    ui->MainSerialPortNumber->addItem(serial.portName());
                }

                serial.close();
            }
        }
    }else
    {
        /* 串口没有初始化成功，先不处理异常 */
    }

    /* 新建udp socket对象 */
    udpSocketClient = new QUdpSocket(this);
    /* 判断是否为空 */
    if(udpSocketClient != NULL)
    {

    }else
    {
       /* UDP端口没有初始化成功，先不处理 */
    }

    /* 新建TCP端口服务器类 */
    tcpSocketServer = new QTcpServer(this);
    /* 判断是否为空 */
    if(tcpSocketServer != NULL)
    {
        /* 开始监听端口 */
        if(tcpSocketServer->listen(QHostAddress::Any, tcpSocketServerPort) == true)
        {
            //qDebug()<<"tcpSocketServer listen";
            /* 注册回调函数 */
            connect(tcpSocketServer, SIGNAL(newConnection()), this, SLOT(TcpClientConnected()));
        }
    }

    /* 定时器 */
    MyTimer = new QTimer(this);
    /* 判断是否为空 */
    if(MyTimer != NULL)
    {
        /* 定时器回调函数 */
        connect(MyTimer, SIGNAL(timeout()), this, SLOT(TimerTimeOutEvent()));
        /* 开启定时器 */
        MyTimer->start(1000);
    }

    TestTimer = new QTimer(this);

    if(TestTimer != NULL)
    {
        /* 定时器回调函数 */
        connect(TestTimer, SIGNAL(timeout()), this, SLOT(TestTimerTimeOutEvent()));
        /* 开启定时器 */
        TestTimer->start(100);
    }

    /* 初始化音频输出 */
    AudioInit();
}

/* 窗口析构函数 */
MainWindow::~MainWindow()
{
    delete ui;
}

/* TCP连接回调函数 */
void MainWindow::TcpClientConnected()
{
    //qDebug()<<"TcpClientConnected";
    ui->TcpStateLable->setText("TCP已经连接");

    OneFrameAllDataSize = 0;
    OneImageSize = 0;
    OneAudioSize = 0;

    /* 获取新的连接socket对象 */
    tcpSocket = tcpSocketServer->nextPendingConnection();
    /* 设置缓冲区大小 */
    //tcpSocket->setReadBufferSize(0);
    /* 注册读取数据事件回调函数 */
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(TcpClientReadyToRead()));
    /* 注册断开连接事件回调函数 */
    connect(tcpSocket, SIGNAL(disconnected()), this, SLOT(TcpClientDisconnected()));
}

/* TCP断开回调函数 */
void MainWindow::TcpClientDisconnected()
{
    //qDebug()<<"TcpClientDisconnected";
    ui->TcpStateLable->setText("TCP已经断开");
}

/* 测试函数 */
void MainWindow::SendSerialDataTest()
{
    /* 测试用，用于发送不同的角度 */
    SendSerialDataTestIndex++;
    /* 形成循环 */
    if(SendSerialDataTestIndex > 54)
    {
        SendSerialDataTestIndex = 0;
    }

    QByteArray sendSerialData;

    sendSerialData[0] = 0x83;
    sendSerialData[1] = 0x83;
    sendSerialData[2] = 0x83;
    sendSerialData[3] = 2;

    switch(SendSerialDataTestIndex/6)
    {
        case 0:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '3';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '3';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 1:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '2';
            sendSerialData[8] = '5';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '2';
            sendSerialData[15] = '5';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 2:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '2';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '2';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 3:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '1';
            sendSerialData[8] = '5';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '1';
            sendSerialData[15] = '5';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 4:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '1';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '1';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 5:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '0';
            sendSerialData[8] = '5';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '0';
            sendSerialData[15] = '5';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 6:
            sendSerialData[4] = '+';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '0';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '+';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '0';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 7:
            sendSerialData[4] = '-';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '0';
            sendSerialData[8] = '5';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '-';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '0';
            sendSerialData[15] = '5';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 8:
            sendSerialData[4] = '-';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '1';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '-';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '1';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        case 9:
            sendSerialData[4] = '-';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '1';
            sendSerialData[8] = '5';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '-';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '1';
            sendSerialData[15] = '5';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
        default:
            sendSerialData[4] = '-';
            sendSerialData[5] = '0';
            sendSerialData[6] = '0';
            sendSerialData[7] = '0';
            sendSerialData[8] = '0';
            sendSerialData[9] = '0';
            sendSerialData[10] = '0';

            sendSerialData[11] = '-';
            sendSerialData[12] = '0';
            sendSerialData[13] = '0';
            sendSerialData[14] = '0';
            sendSerialData[15] = '0';
            sendSerialData[16] = '0';
            sendSerialData[17] = '0';
            break;
    }

    /* 在最后一位表示是否使用后摄像头 */
    if(IsUseBackCamera)
    {
        sendSerialData.append((char)1);
    }else
    {
        sendSerialData.append((char)0);
    }

    tcpSocket->write(sendSerialData);

    ui->SendSerialDataTextEdit->setText(sendSerialData);

    qDebug()<<"发送了模拟的串口数据";
}

/* TCP读取数据回调函数 */
void MainWindow::TcpClientReadyToRead()
{
    //qDebug()<<"TcpClientReadyToRead + " + QString::number(tcpSocket->bytesAvailable());

    QDataStream strameIn(tcpSocket);
    strameIn.setVersion(QDataStream::Qt_5_3);

    if((OneFrameAllDataSize==0) && (OneImageSize==0) && (OneAudioSize==0))
    {
        if (tcpSocket->bytesAvailable()<(int)(3*sizeof(quint64)))
        {
            return;
        }
        strameIn>>OneFrameAllDataSize;
        strameIn>>OneImageSize;
        strameIn>>OneAudioSize;
    }

    if (tcpSocket->bytesAvailable()<OneFrameAllDataSize)
    {
        return;
    }

    if(OneFrameAllDataSize != (OneImageSize + OneAudioSize))
    {
        //qDebug()<<"OneFrameAllDataSize != (OneImageSize + OneAudioSize)";
    }else
    {
        //qDebug()<<"OneFrameAllDataSize == (OneImageSize + OneAudioSize)";
    }

    QByteArray ImageMessage;
    QByteArray AudioMessage;

    ImageMessage.resize(OneImageSize);
    AudioMessage.resize(OneAudioSize);

    /* 流数据 */
    strameIn>>ImageMessage;
    strameIn>>AudioMessage;

    /* 显示数据 */
    ShowImage(ImageMessage);

    if(IsPlayAudioFlag)
    {
        /* 播放声音 */
        PlayAudio(AudioMessage);
    }


    //qDebug()<<"OneFrameAllDataSize + " + QString::number(OneFrameAllDataSize);
    //qDebug()<<"OneImageSize + " + QString::number(OneImageSize);
    //qDebug()<<"OneAudioSize + " + QString::number(OneAudioSize);

    //qDebug()<<"ImageMessage size + " + QString::number(ImageMessage.length());
    //qDebug()<<"AudioMessage size + " + QString::number(AudioMessage.length());

    /* 清除接受了的数据 */
    OneFrameAllDataSize = 0;
    OneImageSize = 0;
    OneAudioSize = 0;

    /* 同时发送数据回去 */
    if(isRecordInitZAngleFlag)
    {
        //qDebug()<<"sned serial data by tcp";

        if(MainSerialRecvData.length() >= MainSerialPortOneFrameSize)
        {
            //qDebug()<<"MainSerialRecvData.length() >= MainSerialPortOneFrameSize";
            /* 更新串口的帧率 */
            MainSerialPorRecvFrameRate++;

            /* 在最后一位表示是否使用后摄像头 */
            if(IsUseBackCamera)
            {
                MainSerialRecvData.append((char)1);
            }else
            {
                MainSerialRecvData.append((char)0);
            }

            /* 通过tcp发送数据回去 */
            tcpSocket->write(MainSerialRecvData);
            //qDebug()<<"tcpSocket->write" + MainSerialRecvData;
            ui->SendSerialDataTextEdit->setText(MainSerialRecvData);
        }else
        {
            //tcpSocket->write("0123456789012345678");
            //qDebug()<<"接受到的数据不正确，不进行发送";
        }
    }

    /* 串口测试函数 */
    //SendSerialDataTest();
}

void MainWindow::PlayAudio(QByteArray audioByteArray)
{
    QString ss = QString::fromLatin1(audioByteArray.data(),audioByteArray.size());
    QByteArray rc = QByteArray::fromBase64(ss.toLatin1());
    QByteArray rdc=qUncompress(rc);

    qDebug()<<"front + audioByteArray size" + QString::number(audioByteArray.length());
    qDebug()<<"back + audioByteArray size" + QString::number(rdc.length());

    /* 把数据 转换成可以显示的 显示出来 */
    InputAudioInfo->write(rdc.constData(), rdc.length());
    /* 数据在这里了，直接进行TCP传输 */
    /* 先暂时显示一下 */
    ui->VolumeShowLable->setText(QString::number(InputAudioInfo->level() * 100.0f));

    OutputAudioIODevice->write(rdc.constData(), rdc.length());

    recvFrameAduioNumberInSecoend++;
}

/* 界面更新函数 */
void MainWindow::ShowImage(QByteArray imageByteArray)
{
    QString ss = QString::fromLatin1(imageByteArray.data(),imageByteArray.size());
    QByteArray rc = QByteArray::fromBase64(ss.toLatin1());
    QByteArray rdc=qUncompress(rc);
    QImage image;
    image.loadFromData(rdc);

    ui->CameraDisplayLable->setPixmap(QPixmap::fromImage(image));
    ui->CameraDisplayLable->resize(image.size());

    if(isStartToRecvImage)
    {
        //qDebug()<<"isStartToRecvImage == 1";
        imageshowwindow->SetImageData(image);
    }else
    {
        //qDebug()<<"isStartToRecvImage == 0";
    }
    /* 更新页面 */
    update();
    /* 更新图片的帧率 */
    recvFrameNumberInSecoend++;
}

/* 打开串口时间回调函数 */
void MainWindow::on_OpenSerialPortButton_clicked()
{
    //qDebug()<<"TcpClientReadyToRead";
    /* 先来判断对象是不是为空 */
    if(MainSerial == NULL)
    {
        /* 新建串口对象 */
        MainSerial = new QSerialPort();
    }
    /* 判断是要打开串口，还是关闭串口 */
    if(MainSerial->isOpen())
    {
        /* 串口已经打开，现在来关闭串口 */
        MainSerial->close();
        ui->OpenSerialPortButton->setText("打开串口");
        //qDebug()<<"串口在打开状态，现在关闭了";

        /* 隐藏，必要的控件 */
        ui->CleanAllDataButton->hide();
        ui->HeaderPoseModeButton->hide();

        ui->RecordInitZAngle->hide();
        ui->UseBackCamera->hide();

        ui->StartToRecvIamgeButton->hide();

        ui->TestAngleButton->hide();
        ui->SendSerialDataTextEdit->hide();

        qDebug()<<"hide();";
    }else
    {
        /* 判断是否有可用串口 */
        if(ui->MainSerialPortNumber->count() != 0)
        {
            /* 串口已经关闭，现在来打开串口 */
            /* 设置串口名称 */
            MainSerial->setPortName(ui->MainSerialPortNumber->currentText());
            /* 设置波特率 */
            MainSerial->setBaudRate(MainSerialBaudRate);
            /* 设置数据位数 */
            MainSerial->setDataBits(QSerialPort::Data8);
            /* 设置奇偶校验 */
            MainSerial->setParity(QSerialPort::NoParity);
            /* 设置停止位 */
            MainSerial->setStopBits(QSerialPort::OneStop);
            /* 设置流控制 */
            MainSerial->setFlowControl(QSerialPort::NoFlowControl);
            /* 打开串口 */
            MainSerial->open(QIODevice::ReadWrite);
            /* 设置串口缓冲区大小，这里必须设置为这么大 */
            MainSerial->setReadBufferSize(MainSerialPortOneFrameSize);
            /* 注册回调函数 */
            QObject::connect(MainSerial, &QSerialPort::readyRead, this, &MainWindow::MainSerialRecvMsgEvent);
            /* 修改按键名称 */
            ui->OpenSerialPortButton->setText("关闭串口");
            qDebug()<<"串口在关闭状态，现在打开了" + ui->MainSerialPortNumber->currentText();

            /* 显示，所有的可用控件 */
            ui->CleanAllDataButton->show();

            ui->RecordInitZAngle->show();

            //ui->StartToRecvIamgeButton->show();
            //ui->HeaderPoseModeButton->show();

            //ui->UseBackCamera->show();

            //ui->TestAngleButton->show();
            //ui->SendSerialDataTextEdit->show();

            qDebug()<<"show();";

        }else
        {
            //qDebug()<<"没有可用串口，请重新常识扫描串口";
        }
    }
}

/* 串口接受数据事件回调函数 */
void MainWindow::MainSerialRecvMsgEvent()
{
    /* 如果本次数据帧接受错误，那么先不接受 */
    if(MainSerial->bytesAvailable() >= MainSerialPortOneFrameSize)
    {
        MainSerialRecvData = MainSerial->readAll();
        if(!MainSerialRecvData.isEmpty())
        {
            if(isRecordInitZAngleFlag)
            {
                MainSerialPortRecvFrameNumber++;
                /* 把接受到的数据显示到界面上 */
                ui->RecvTextEdit->setText(QString::number(MainSerialPortRecvFrameNumber) + "NUMBER" + MainSerialRecvData);
                /* 同时发送给UDP服务器 ，这里暂时注释，不通过UDP发送 */
                //udpSocketClient->writeDatagram(MainSerialRecvData.data(), MainSerialRecvData.size(), udpSockerServerAddress, udpSocketServerPort);
            }else
            {
                //qDebug()<<"还没有记录过Z轴角度";
            }
        }else
        {
            MainSerialPortRecvErrorFrameNumber++;
            //qDebug()<<"接受数据出错";
        }
    }else
    {
        MainSerialPortRecvErrorFrameNumber++;
        //qDebug()<<"接受数据出错" + QString::number(MainSerial->bytesAvailable());
    }
}

/* 清除所有数据时间回调函数 */
void MainWindow::on_CleanAllDataButton_clicked()
{
    /* 清除所有数据 */
    MainSerialPortRecvFrameNumber = 0;
    MainSerialPortRecvErrorFrameNumber = 0;
    ui->RecvTextEdit->clear();
}

/* 扫描串口按钮回调函数 */
void MainWindow::on_ScanSerialPortButton_clicked()
{
    if(MainSerial != NULL)
    {
        /* 查找可用串口 */
        foreach(const QSerialPortInfo &info, QSerialPortInfo::availablePorts())
        {
            QSerialPort serial;
            serial.setPort(info);
            /* 判断端口是否能打开 */
            if(serial.open(QIODevice::ReadWrite))
            {
                int isHaveItemInList = 0;
                /* 判断是不是已经在列表中了 */
                for(int i=0; i<ui->MainSerialPortNumber->count(); i++)
                {
                    /* 如果，已经在列表中了，那么不添加这一项了就 */
                    if(ui->MainSerialPortNumber->itemData(i) == serial.portName())
                    {
                        isHaveItemInList++;
                    }
                }

                if(isHaveItemInList == 0)
                {
                    ui->MainSerialPortNumber->addItem(serial.portName());
                }

                serial.close();
            }
        }
    }else
    {
        /* 串口没有初始化成功，先不处理异常 */
    }
}

void MainWindow::on_OpenAudioButton_clicked()
{
    if(IsPlayAudioFlag)
    {
        IsPlayAudioFlag = false;
        ui->OpenAudioButton->setText("打开音频");
    }else
    {
        IsPlayAudioFlag = true;
        ui->OpenAudioButton->setText("关闭音频");
    }
}

/* 定时器回调函数 1S 的定时器 */
void MainWindow::TimerTimeOutEvent()
{
    qDebug()<<"recvFrameNumberInSecoend + " + QString::number(recvFrameNumberInSecoend);
    qDebug()<<"recvFrameAduioNumberInSecoend + " + QString::number(recvFrameAduioNumberInSecoend);

    /* 设置图片的帧率 */
    ui->PictureFrameLable->setText(QString::number(recvFrameNumberInSecoend));
    /* 设置串口的帧率 */
    ui->uartFrame->setText(QString::number(MainSerialPorRecvFrameRate));
    /* 清零帧率 */
    recvFrameNumberInSecoend = 0;
    recvFrameAduioNumberInSecoend = 0;
    MainSerialPorRecvFrameRate = 0;
}

/* 使用后摄像头 */
void MainWindow::on_UseBackCamera_clicked()
{
    if(ui->UseBackCamera->text() == "使用后摄像头")
    {
        ui->UseBackCamera->setText("使用前摄像头");
        IsUseBackCamera = true;
    }else
    {
        ui->UseBackCamera->setText("使用后摄像头");
        IsUseBackCamera = false;
    }
}

/* 记录初始Z轴角度按钮 回调函数 */
void MainWindow::on_RecordInitZAngle_clicked()
{
    /* 首先判断端口是否为空 */
    if(MainSerial != NULL)
    {
        /* 判断端口是否打开 */
        if(MainSerial->isOpen())
        {
            QByteArray sendData = "RecordInitZAngle";
            MainSerial->write(sendData);
            isRecordInitZAngleFlag = 1;
            ui->UseBackCamera->show();
            ui->StartToRecvIamgeButton->show();
            ui->HeaderPoseModeButton->show();
            //qDebug()<<"已经发送了命令";
        }else
        {
            /*  */
            //qDebug()<<"串口没有打开，请打开串口";
        }
    }else
    {
        /*  */
        //qDebug()<<"串口没有打开，请打开串口";
    }
}

/* 测试函数 */
void MainWindow::TestTimerTimeOutEvent()
{
    //udpSocketClient->writeDatagram(MainSerialRecvData.data(), MainSerialRecvData.size(), udpSockerServerAddress, udpSocketServerPort);
}

/* 新建窗口按钮回调函数 */
void MainWindow::on_StartToRecvIamgeButton_clicked()
{
    /* 新建窗体 */
    imageshowwindow = new ImageShowWindow();
    /* 注册回调函数 */
    connect(imageshowwindow, SIGNAL(WindowDestroy()), this, SLOT(ImageShowDestroy()));
    /* 显示 */
    imageshowwindow->show();
    /* 全屏 */
    imageshowwindow->showFullScreen();
    /* 标志开始显示单独的图片页面 */
    isStartToRecvImage = 1;
}

/* 鼠标双击双击函数 */
void MainWindow::mouseDoubleClickEvent(QMouseEvent *mouseEvent)
{
    qDebug()<<"mouseDoubleClickEvent";

    /* 现在判断鼠标的位置，如果在图像之上，那么，执行图像显示程序 */

    /* 首先先来获取鼠标的位置 */
    QPoint coursePoint;
    coursePoint = QCursor::pos();//获取当前光标的位置
    int MousePositionX = coursePoint.x();
    int MousePositionY = coursePoint.y();

    /* 获得窗体的位置 */
    int ImageShowLableStartX = ui->CameraDisplayLable->geometry().x();
    int ImageShowLableStartY = ui->CameraDisplayLable->geometry().y();

    int ImageShowLableLengthX = ui->CameraDisplayLable->geometry().width();
    int ImageShowLableLengthY = ui->CameraDisplayLable->geometry().height();

    //qDebug()<<"MousePositionX" + QString::number(MousePositionX);
    //qDebug()<<"MousePositionY" + QString::number(MousePositionY);
    //qDebug()<<"ImageShowLableStartX" + QString::number(ImageShowLableStartX);
    //qDebug()<<"ImageShowLableStartY" + QString::number(ImageShowLableStartY);
    //qDebug()<<"ImageShowLableLengthX" + QString::number(ImageShowLableLengthX);
    //qDebug()<<"ImageShowLableLengthY" + QString::number(ImageShowLableLengthY);

    if(((MousePositionX > ImageShowLableStartX) && (MousePositionX < (ImageShowLableStartX + ImageShowLableLengthX))) &&
       ((MousePositionY > ImageShowLableStartY) && (MousePositionY < (ImageShowLableStartY + ImageShowLableLengthY))))
    {
        /* 新建窗体 */
        imageshowwindow = new ImageShowWindow();
        /* 注册回调函数 */
        connect(imageshowwindow, SIGNAL(WindowDestroy()), this, SLOT(ImageShowDestroy()));
        /* 显示 */
        imageshowwindow->show();
        /* 全屏 */
        imageshowwindow->showFullScreen();
        /* 标志开始显示单独的图片页面 */
        isStartToRecvImage = 1;
    }
}

/* 单独的图片页面销毁的回调函数 */
void MainWindow::ImageShowDestroy()
{
    /* 标志开始不显示单独的图片页面  */
    isStartToRecvImage = 0;
}

void MainWindow::on_HeaderPoseModeButton_clicked()
{
    if(ui->HeaderPoseModeButton->text() == "使用头部后带模式")
    {
        /* 首先判断端口是否为空 */
        if(MainSerial != NULL)
        {
            /* 判断端口是否打开 */
            if(MainSerial->isOpen())
            {
                QByteArray sendData = "Backward";
                MainSerial->write(sendData);
                /* 现在是在使用头部正带模式，下面要转入后带模式 */
                IsHeaderPoseInBackMode = true;
                ui->HeaderPoseModeButton->setText("使用头部正带模式");
            }else
            {
            }
        }else
        {
        }
    }else
    {
        /* 首先判断端口是否为空 */
        if(MainSerial != NULL)
        {
            /* 判断端口是否打开 */
            if(MainSerial->isOpen())
            {
                QByteArray sendData = "Forward";
                MainSerial->write(sendData);
                /* 现在是在使用头部后带模式，下面要转入正带模式 */
                IsHeaderPoseInBackMode = false;

                ui->HeaderPoseModeButton->setText("使用头部后带模式");
            }else
            {
                
            }
        }else
        {
            
        }
    }
}

void MainWindow::on_TestAngleButton_clicked()
{

}

void MainWindow::AudioInit()
{
    /* 初始化音频输入 */
    InputAudioFormat.setSampleRate(8000);
    InputAudioFormat.setChannelCount(1);
    InputAudioFormat.setSampleSize(16);
    InputAudioFormat.setSampleType(QAudioFormat::SignedInt);
    InputAudioFormat.setByteOrder(QAudioFormat::LittleEndian);
    InputAudioFormat.setCodec("audio/pcm");

    QAudioDeviceInfo InputDeviceInfo(QAudioDeviceInfo::defaultInputDevice());
    if (!InputDeviceInfo.isFormatSupported(InputAudioFormat))
    {
        InputAudioFormat = InputDeviceInfo.nearestFormat(InputAudioFormat);
    }

    /* 新建 audio info 类 */
    InputAudioInfo  = new AudioInfo(InputAudioFormat, this);

    /*  */
    InputAudioInfo->start();

    /* -------------------初始化输出音频--------------------- */
    /* 搜索 */
    const QAudioDeviceInfo &defaultOutputDeviceInfo = QAudioDeviceInfo::defaultOutputDevice();

    /* 先添加默认的 */
    ui->OutputShoudCardListComBox->addItem(defaultOutputDeviceInfo.deviceName(), qVariantFromValue(defaultOutputDeviceInfo));

    /* 循环假如所有的声卡 */
    foreach (const QAudioDeviceInfo &deviceInfo, QAudioDeviceInfo::availableDevices(QAudio::AudioOutput))
    {
        if(deviceInfo != defaultOutputDeviceInfo)
        {
            ui->OutputShoudCardListComBox->addItem(deviceInfo.deviceName(), qVariantFromValue(deviceInfo));
        }
    }

    /* 初始化音频输出格式 */
    OutputAudioFormat.setSampleRate(8000);
    OutputAudioFormat.setChannelCount(1);
    OutputAudioFormat.setSampleSize(16);
    OutputAudioFormat.setCodec("audio/pcm");
    OutputAudioFormat.setByteOrder(QAudioFormat::LittleEndian);
    OutputAudioFormat.setSampleType(QAudioFormat::SignedInt);

    QAudioDeviceInfo OutputDeviceInfo(QAudioDeviceInfo::defaultOutputDevice());
    if (!OutputDeviceInfo.isFormatSupported(OutputAudioFormat))
    {
        qWarning() << "Default format not supported - trying to use nearest";
        OutputAudioFormat = OutputDeviceInfo.nearestFormat(OutputAudioFormat);
    }

    /* 初始化输音频输出器件 */
    OutputAudioDevice = QAudioDeviceInfo::defaultOutputDevice();

    /* 输出音频类 */
    AudioOutput = new QAudioOutput(OutputAudioDevice, OutputAudioFormat, this);

    OutputAudioIODevice = AudioOutput->start();
}












/* audio */


/* AudioInfo 的 类实现 */
AudioInfo::AudioInfo(const QAudioFormat &format, QObject *parent)
    :   QIODevice(parent)
    ,   m_format(format)
    ,   m_maxAmplitude(0)
    ,   m_level(0.0)

{
    switch (m_format.sampleSize())
    {
    case 8:
        switch (m_format.sampleType())
        {
        case QAudioFormat::UnSignedInt:
            m_maxAmplitude = 255;
            break;
        case QAudioFormat::SignedInt:
            m_maxAmplitude = 127;
            break;
        default:
            break;
        }
        break;
    case 16:
        switch (m_format.sampleType())
        {
        case QAudioFormat::UnSignedInt:
            m_maxAmplitude = 65535;
            break;
        case QAudioFormat::SignedInt:
            m_maxAmplitude = 32767;
            break;
        default:
            break;
        }
        break;

    case 32:
        switch (m_format.sampleType())
        {
        case QAudioFormat::UnSignedInt:
            m_maxAmplitude = 0xffffffff;
            break;
        case QAudioFormat::SignedInt:
            m_maxAmplitude = 0x7fffffff;
            break;
        case QAudioFormat::Float:
            m_maxAmplitude = 0x7fffffff; // Kind of
        default:
            break;
        }
        break;

    default:
        break;
    }
}

AudioInfo::~AudioInfo()
{
    qDebug()<<"~AudioInfo";
}

void AudioInfo::start()
{
    qDebug()<<"AudioInfo::start()";

    open(QIODevice::WriteOnly);
}

void AudioInfo::stop()
{
    qDebug()<<"AudioInfo::stop()";

    close();
}

qint64 AudioInfo::readData(char *data, qint64 maxlen)
{
    qDebug()<<"AudioInfo::readData";

    Q_UNUSED(data)
    Q_UNUSED(maxlen)

    return 0;
}

qint64 AudioInfo::writeData(const char *data, qint64 len)
{
    if (m_maxAmplitude) {
        Q_ASSERT(m_format.sampleSize() % 8 == 0);
        const int channelBytes = m_format.sampleSize() / 8;
        const int sampleBytes = m_format.channelCount() * channelBytes;
        Q_ASSERT(len % sampleBytes == 0);
        const int numSamples = len / sampleBytes;

        quint32 maxValue = 0;
        const unsigned char *ptr = reinterpret_cast<const unsigned char *>(data);

        for (int i = 0; i < numSamples; ++i) {
            for (int j = 0; j < m_format.channelCount(); ++j) {
                quint32 value = 0;

                if (m_format.sampleSize() == 8 && m_format.sampleType() == QAudioFormat::UnSignedInt) {
                    value = *reinterpret_cast<const quint8*>(ptr);
                } else if (m_format.sampleSize() == 8 && m_format.sampleType() == QAudioFormat::SignedInt) {
                    value = qAbs(*reinterpret_cast<const qint8*>(ptr));
                } else if (m_format.sampleSize() == 16 && m_format.sampleType() == QAudioFormat::UnSignedInt) {
                    if (m_format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qFromLittleEndian<quint16>(ptr);
                    else
                        value = qFromBigEndian<quint16>(ptr);
                } else if (m_format.sampleSize() == 16 && m_format.sampleType() == QAudioFormat::SignedInt) {
                    if (m_format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qAbs(qFromLittleEndian<qint16>(ptr));
                    else
                        value = qAbs(qFromBigEndian<qint16>(ptr));
                } else if (m_format.sampleSize() == 32 && m_format.sampleType() == QAudioFormat::UnSignedInt) {
                    if (m_format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qFromLittleEndian<quint32>(ptr);
                    else
                        value = qFromBigEndian<quint32>(ptr);
                } else if (m_format.sampleSize() == 32 && m_format.sampleType() == QAudioFormat::SignedInt) {
                    if (m_format.byteOrder() == QAudioFormat::LittleEndian)
                        value = qAbs(qFromLittleEndian<qint32>(ptr));
                    else
                        value = qAbs(qFromBigEndian<qint32>(ptr));
                } else if (m_format.sampleSize() == 32 && m_format.sampleType() == QAudioFormat::Float) {
                    value = qAbs(*reinterpret_cast<const float*>(ptr) * 0x7fffffff); // assumes 0-1.0
                }

                maxValue = qMax(value, maxValue);
                ptr += channelBytes;
            }
        }

        maxValue = qMin(maxValue, m_maxAmplitude);
        m_level = qreal(maxValue) / m_maxAmplitude;
    }

    return len;
}
