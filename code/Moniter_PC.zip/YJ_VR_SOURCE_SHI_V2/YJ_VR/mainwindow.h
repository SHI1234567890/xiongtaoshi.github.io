#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDebug>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QUdpSocket>
#include <QTcpSocket>
#include <QTcpServer>
#include <QTimer>
#include <imageshowwindow.h>

#include <QAudioInput>
#include <QAudioOutput>
#include <QByteArray>
#include <QComboBox>
#include <QObject>
#include <QPixmap>
#include <QPushButton>
#include <QSlider>
#include <QWidget>
#include <qendian.h>

namespace Ui {
class MainWindow;
}

#define IMG_BLOCK_SIZE ((quint64)500)

struct sendImageDataStruct
{
    /* 图像数据存储数组 */
    char imageDataBuffer[IMG_BLOCK_SIZE];
    /* 一包数据大小 */
    quint16 onePackerSize;
    /* 包的序列 */
    quint16 packerIndex;
    /* 总共有多少包 */
    quint16 BlocksNumber;
    /* 是否是最后一包数据标志位 */
    quint16 dataEndFalg;
};

class AudioInfo : public QIODevice
{
    Q_OBJECT

public:
    AudioInfo(const QAudioFormat &format, QObject *parent);
    ~AudioInfo();

    void start();
    void stop();

    qreal level() const { return m_level; }

    qint64 readData(char *data, qint64 maxlen);
    qint64 writeData(const char *data, qint64 len);

private:
    const QAudioFormat m_format;
    quint32 m_maxAmplitude;
    qreal m_level; // 0.0 <= m_level <= 1.0
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
     void mouseDoubleClickEvent ( QMouseEvent * );

private slots:

    void MainSerialRecvMsgEvent();
    void TcpClientConnected();
    void TcpClientReadyToRead();
    void TcpClientDisconnected();
    void ShowImage(QByteArray imageByteArray);
    void PlayAudio(QByteArray audioByteArray);

    void on_OpenSerialPortButton_clicked();

    void on_CleanAllDataButton_clicked();

    void on_ScanSerialPortButton_clicked();

    void TimerTimeOutEvent();

    void on_RecordInitZAngle_clicked();

    void TestTimerTimeOutEvent();

    void SendSerialDataTest();

    void on_StartToRecvIamgeButton_clicked();

    void ImageShowDestroy();

    void on_UseBackCamera_clicked();

    void on_HeaderPoseModeButton_clicked();

    void on_TestAngleButton_clicked();

    void AudioInit();

    void on_OpenAudioButton_clicked();

private:
    Ui::MainWindow *ui;
    /* 定时器 */
    QTimer * MyTimer;
    /* 测试定时器 */
    QTimer * TestTimer;
    /* ----------串口相关变量------------ */
    /* 声明串口对象 */
    QSerialPort * MainSerial;
    /* 声明串口波特率 */
    qint32 MainSerialBaudRate;
    /* 声明串口一帧数据的大小 */
    qint32 MainSerialPortOneFrameSize;
    /* 声明接受数据帧数 */
    qint32 MainSerialPortRecvFrameNumber;
    /* 声明串口接受数据帧率 */
    qint32 MainSerialPorRecvFrameRate;
    /* 串口接受数据 */
    QByteArray MainSerialRecvData;
    /* 声明接受错误数据帧数 */
    qint32 MainSerialPortRecvErrorFrameNumber;
    /* ----------UDP相关变量-------------- */
    /* UDP通信对象 */
    QUdpSocket * udpSocketClient;
    /* -------UDP服务器端口----------- */
    qint32 udpSocketServerPort;
    /* UDP服务器地址 */
    QHostAddress udpSockerServerAddress;
    /* ---------TCP服务器相关----------- */
    /* TCP服务器对象 */
    QTcpServer *tcpSocketServer;
    /* TCP 服务器的监听端口 */
    qint32 tcpSocketServerPort;
    /* tcp的socket */
    QTcpSocket *tcpSocket;
    /* 图像接受相关 */
    quint64 OneFrameAllDataSize;
    quint64 OneImageSize;
    quint64 OneAudioSize;
    /* 接受图像次数 */
    qint32 recvFrameNumberInSecoend;
    qint32 recvFrameAduioNumberInSecoend;

    /* 记录是否矫正了第一次的角度 */
    quint32 isRecordInitZAngleFlag;
    /* 记录是否开始播放视频标志位 */
    quint32 isStartToRecvImage;
    /* 画面显示窗口 */
    ImageShowWindow * imageshowwindow;
    /* 记录第几次发送串口数据，测试用，用来生成，不同的串口数据 */
    quint32 SendSerialDataTestIndex;
    /* 是否使用后摄像头 */
    bool IsUseBackCamera;
    /* 是否使用后带功能，后带就是，在X,Y,轴上变号 */
    bool IsHeaderPoseInBackMode;
    /* 是否初始化Z轴角度 */
    bool IsHaveInitZAngle;
    /* 用于测试角度的数据 */
    quint32 TestAngleIndex;

    /* 音频输入设备信息 */
    AudioInfo * InputAudioInfo;
    /* 音频输入格式 */
    QAudioFormat InputAudioFormat;

    /* 音频输出变量 */
    QAudioDeviceInfo OutputAudioDevice;
    QAudioOutput * AudioOutput;
    QIODevice * OutputAudioIODevice;
    QAudioFormat OutputAudioFormat;
    bool IsPlayAudioFlag;
};

#endif // MAINWINDOW_H
