#ifndef IMAGESHOWWINDOW_H
#define IMAGESHOWWINDOW_H

#include <QWidget>
#include <QDebug>
# include <QtWidgets/qdesktopwidget.h>

namespace Ui {
class ImageShowWindow;
}

class ImageShowWindow : public QWidget
{
    Q_OBJECT

public:
    explicit ImageShowWindow(QWidget *parent = 0);
    ~ImageShowWindow();

    void SetImageData(QImage image);

private slots:
    void mouseMoveEvent( QMouseEvent * event );

    void on_BackToMainWindow_clicked();

    void on_FullScreenDisplayButton_clicked();

protected:
     void mouseDoubleClickEvent ( QMouseEvent * );

private:
    Ui::ImageShowWindow *ui;
    quint32 mouseMoveNumber;
    quint32 isFullScreenDisplayImage;
    quint32 FullScreenWidth;
    quint32 FullScreenHeight;
signals:
    void WindowDestroy();
};

#endif // IMAGESHOWWINDOW_H
