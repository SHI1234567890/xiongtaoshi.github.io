/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_AudioInfo_t {
    QByteArrayData data[1];
    char stringdata[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AudioInfo_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AudioInfo_t qt_meta_stringdata_AudioInfo = {
    {
QT_MOC_LITERAL(0, 0, 9) // "AudioInfo"

    },
    "AudioInfo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AudioInfo[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void AudioInfo::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject AudioInfo::staticMetaObject = {
    { &QIODevice::staticMetaObject, qt_meta_stringdata_AudioInfo.data,
      qt_meta_data_AudioInfo,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *AudioInfo::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AudioInfo::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_AudioInfo.stringdata))
        return static_cast<void*>(const_cast< AudioInfo*>(this));
    return QIODevice::qt_metacast(_clname);
}

int AudioInfo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QIODevice::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[24];
    char stringdata[500];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 22), // "MainSerialRecvMsgEvent"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 18), // "TcpClientConnected"
QT_MOC_LITERAL(4, 54, 20), // "TcpClientReadyToRead"
QT_MOC_LITERAL(5, 75, 21), // "TcpClientDisconnected"
QT_MOC_LITERAL(6, 97, 9), // "ShowImage"
QT_MOC_LITERAL(7, 107, 14), // "imageByteArray"
QT_MOC_LITERAL(8, 122, 9), // "PlayAudio"
QT_MOC_LITERAL(9, 132, 14), // "audioByteArray"
QT_MOC_LITERAL(10, 147, 31), // "on_OpenSerialPortButton_clicked"
QT_MOC_LITERAL(11, 179, 29), // "on_CleanAllDataButton_clicked"
QT_MOC_LITERAL(12, 209, 31), // "on_ScanSerialPortButton_clicked"
QT_MOC_LITERAL(13, 241, 17), // "TimerTimeOutEvent"
QT_MOC_LITERAL(14, 259, 27), // "on_RecordInitZAngle_clicked"
QT_MOC_LITERAL(15, 287, 21), // "TestTimerTimeOutEvent"
QT_MOC_LITERAL(16, 309, 18), // "SendSerialDataTest"
QT_MOC_LITERAL(17, 328, 33), // "on_StartToRecvIamgeButton_cli..."
QT_MOC_LITERAL(18, 362, 16), // "ImageShowDestroy"
QT_MOC_LITERAL(19, 379, 24), // "on_UseBackCamera_clicked"
QT_MOC_LITERAL(20, 404, 31), // "on_HeaderPoseModeButton_clicked"
QT_MOC_LITERAL(21, 436, 26), // "on_TestAngleButton_clicked"
QT_MOC_LITERAL(22, 463, 9), // "AudioInit"
QT_MOC_LITERAL(23, 473, 26) // "on_OpenAudioButton_clicked"

    },
    "MainWindow\0MainSerialRecvMsgEvent\0\0"
    "TcpClientConnected\0TcpClientReadyToRead\0"
    "TcpClientDisconnected\0ShowImage\0"
    "imageByteArray\0PlayAudio\0audioByteArray\0"
    "on_OpenSerialPortButton_clicked\0"
    "on_CleanAllDataButton_clicked\0"
    "on_ScanSerialPortButton_clicked\0"
    "TimerTimeOutEvent\0on_RecordInitZAngle_clicked\0"
    "TestTimerTimeOutEvent\0SendSerialDataTest\0"
    "on_StartToRecvIamgeButton_clicked\0"
    "ImageShowDestroy\0on_UseBackCamera_clicked\0"
    "on_HeaderPoseModeButton_clicked\0"
    "on_TestAngleButton_clicked\0AudioInit\0"
    "on_OpenAudioButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x08 /* Private */,
       3,    0,  115,    2, 0x08 /* Private */,
       4,    0,  116,    2, 0x08 /* Private */,
       5,    0,  117,    2, 0x08 /* Private */,
       6,    1,  118,    2, 0x08 /* Private */,
       8,    1,  121,    2, 0x08 /* Private */,
      10,    0,  124,    2, 0x08 /* Private */,
      11,    0,  125,    2, 0x08 /* Private */,
      12,    0,  126,    2, 0x08 /* Private */,
      13,    0,  127,    2, 0x08 /* Private */,
      14,    0,  128,    2, 0x08 /* Private */,
      15,    0,  129,    2, 0x08 /* Private */,
      16,    0,  130,    2, 0x08 /* Private */,
      17,    0,  131,    2, 0x08 /* Private */,
      18,    0,  132,    2, 0x08 /* Private */,
      19,    0,  133,    2, 0x08 /* Private */,
      20,    0,  134,    2, 0x08 /* Private */,
      21,    0,  135,    2, 0x08 /* Private */,
      22,    0,  136,    2, 0x08 /* Private */,
      23,    0,  137,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,    7,
    QMetaType::Void, QMetaType::QByteArray,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->MainSerialRecvMsgEvent(); break;
        case 1: _t->TcpClientConnected(); break;
        case 2: _t->TcpClientReadyToRead(); break;
        case 3: _t->TcpClientDisconnected(); break;
        case 4: _t->ShowImage((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 5: _t->PlayAudio((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 6: _t->on_OpenSerialPortButton_clicked(); break;
        case 7: _t->on_CleanAllDataButton_clicked(); break;
        case 8: _t->on_ScanSerialPortButton_clicked(); break;
        case 9: _t->TimerTimeOutEvent(); break;
        case 10: _t->on_RecordInitZAngle_clicked(); break;
        case 11: _t->TestTimerTimeOutEvent(); break;
        case 12: _t->SendSerialDataTest(); break;
        case 13: _t->on_StartToRecvIamgeButton_clicked(); break;
        case 14: _t->ImageShowDestroy(); break;
        case 15: _t->on_UseBackCamera_clicked(); break;
        case 16: _t->on_HeaderPoseModeButton_clicked(); break;
        case 17: _t->on_TestAngleButton_clicked(); break;
        case 18: _t->AudioInit(); break;
        case 19: _t->on_OpenAudioButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
