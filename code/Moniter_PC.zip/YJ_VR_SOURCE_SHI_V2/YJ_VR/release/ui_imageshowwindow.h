/********************************************************************************
** Form generated from reading UI file 'imageshowwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IMAGESHOWWINDOW_H
#define UI_IMAGESHOWWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ImageShowWindow
{
public:
    QLabel *ImageShowLable;
    QPushButton *BackToMainWindow;
    QPushButton *FullScreenDisplayButton;

    void setupUi(QWidget *ImageShowWindow)
    {
        if (ImageShowWindow->objectName().isEmpty())
            ImageShowWindow->setObjectName(QStringLiteral("ImageShowWindow"));
        ImageShowWindow->resize(714, 482);
        ImageShowLable = new QLabel(ImageShowWindow);
        ImageShowLable->setObjectName(QStringLiteral("ImageShowLable"));
        ImageShowLable->setGeometry(QRect(0, 0, 1326, 768));
        ImageShowLable->setAlignment(Qt::AlignCenter);
        BackToMainWindow = new QPushButton(ImageShowWindow);
        BackToMainWindow->setObjectName(QStringLiteral("BackToMainWindow"));
        BackToMainWindow->setGeometry(QRect(0, 0, 91, 41));
        FullScreenDisplayButton = new QPushButton(ImageShowWindow);
        FullScreenDisplayButton->setObjectName(QStringLiteral("FullScreenDisplayButton"));
        FullScreenDisplayButton->setGeometry(QRect(0, 40, 91, 41));

        retranslateUi(ImageShowWindow);

        QMetaObject::connectSlotsByName(ImageShowWindow);
    } // setupUi

    void retranslateUi(QWidget *ImageShowWindow)
    {
        ImageShowWindow->setWindowTitle(QApplication::translate("ImageShowWindow", "Form", 0));
        ImageShowLable->setText(QApplication::translate("ImageShowWindow", "\345\233\276\345\203\217\346\230\276\347\244\272", 0));
        BackToMainWindow->setText(QApplication::translate("ImageShowWindow", "\351\200\200\345\207\272\351\241\265\351\235\242", 0));
        FullScreenDisplayButton->setText(QApplication::translate("ImageShowWindow", "\345\205\250\345\261\217\346\230\276\347\244\272", 0));
    } // retranslateUi

};

namespace Ui {
    class ImageShowWindow: public Ui_ImageShowWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IMAGESHOWWINDOW_H
