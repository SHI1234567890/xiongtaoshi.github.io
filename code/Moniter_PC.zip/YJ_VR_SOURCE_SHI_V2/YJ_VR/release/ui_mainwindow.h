/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.4.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *CameraDisplayLable;
    QTextEdit *RecvTextEdit;
    QComboBox *MainSerialPortNumber;
    QPushButton *OpenSerialPortButton;
    QPushButton *CleanAllDataButton;
    QPushButton *ScanSerialPortButton;
    QLabel *TcpStateLable;
    QLabel *PictureFrameLable;
    QPushButton *RecordInitZAngle;
    QLabel *uartFrame;
    QPushButton *StartToRecvIamgeButton;
    QPushButton *UseBackCamera;
    QPushButton *HeaderPoseModeButton;
    QTextEdit *SendSerialDataTextEdit;
    QPushButton *TestAngleButton;
    QComboBox *OutputShoudCardListComBox;
    QLabel *VolumeShowLable;
    QPushButton *OpenAudioButton;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1080, 606);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        CameraDisplayLable = new QLabel(centralWidget);
        CameraDisplayLable->setObjectName(QStringLiteral("CameraDisplayLable"));
        CameraDisplayLable->setGeometry(QRect(20, 20, 768, 576));
        RecvTextEdit = new QTextEdit(centralWidget);
        RecvTextEdit->setObjectName(QStringLiteral("RecvTextEdit"));
        RecvTextEdit->setGeometry(QRect(810, 340, 131, 101));
        MainSerialPortNumber = new QComboBox(centralWidget);
        MainSerialPortNumber->setObjectName(QStringLiteral("MainSerialPortNumber"));
        MainSerialPortNumber->setGeometry(QRect(960, 120, 111, 22));
        OpenSerialPortButton = new QPushButton(centralWidget);
        OpenSerialPortButton->setObjectName(QStringLiteral("OpenSerialPortButton"));
        OpenSerialPortButton->setGeometry(QRect(960, 190, 111, 31));
        CleanAllDataButton = new QPushButton(centralWidget);
        CleanAllDataButton->setObjectName(QStringLiteral("CleanAllDataButton"));
        CleanAllDataButton->setGeometry(QRect(960, 230, 111, 31));
        ScanSerialPortButton = new QPushButton(centralWidget);
        ScanSerialPortButton->setObjectName(QStringLiteral("ScanSerialPortButton"));
        ScanSerialPortButton->setGeometry(QRect(960, 150, 111, 31));
        TcpStateLable = new QLabel(centralWidget);
        TcpStateLable->setObjectName(QStringLiteral("TcpStateLable"));
        TcpStateLable->setGeometry(QRect(960, 270, 101, 21));
        PictureFrameLable = new QLabel(centralWidget);
        PictureFrameLable->setObjectName(QStringLiteral("PictureFrameLable"));
        PictureFrameLable->setGeometry(QRect(960, 300, 101, 21));
        RecordInitZAngle = new QPushButton(centralWidget);
        RecordInitZAngle->setObjectName(QStringLiteral("RecordInitZAngle"));
        RecordInitZAngle->setGeometry(QRect(960, 370, 101, 41));
        uartFrame = new QLabel(centralWidget);
        uartFrame->setObjectName(QStringLiteral("uartFrame"));
        uartFrame->setGeometry(QRect(960, 330, 71, 31));
        StartToRecvIamgeButton = new QPushButton(centralWidget);
        StartToRecvIamgeButton->setObjectName(QStringLiteral("StartToRecvIamgeButton"));
        StartToRecvIamgeButton->setGeometry(QRect(960, 430, 111, 41));
        UseBackCamera = new QPushButton(centralWidget);
        UseBackCamera->setObjectName(QStringLiteral("UseBackCamera"));
        UseBackCamera->setGeometry(QRect(960, 480, 111, 41));
        HeaderPoseModeButton = new QPushButton(centralWidget);
        HeaderPoseModeButton->setObjectName(QStringLiteral("HeaderPoseModeButton"));
        HeaderPoseModeButton->setGeometry(QRect(960, 530, 111, 41));
        SendSerialDataTextEdit = new QTextEdit(centralWidget);
        SendSerialDataTextEdit->setObjectName(QStringLiteral("SendSerialDataTextEdit"));
        SendSerialDataTextEdit->setGeometry(QRect(820, 10, 121, 101));
        TestAngleButton = new QPushButton(centralWidget);
        TestAngleButton->setObjectName(QStringLiteral("TestAngleButton"));
        TestAngleButton->setGeometry(QRect(820, 120, 121, 51));
        OutputShoudCardListComBox = new QComboBox(centralWidget);
        OutputShoudCardListComBox->setObjectName(QStringLiteral("OutputShoudCardListComBox"));
        OutputShoudCardListComBox->setGeometry(QRect(820, 260, 121, 61));
        VolumeShowLable = new QLabel(centralWidget);
        VolumeShowLable->setObjectName(QStringLiteral("VolumeShowLable"));
        VolumeShowLable->setGeometry(QRect(820, 190, 121, 51));
        OpenAudioButton = new QPushButton(centralWidget);
        OpenAudioButton->setObjectName(QStringLiteral("OpenAudioButton"));
        OpenAudioButton->setGeometry(QRect(960, 80, 111, 31));
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Sany", 0));
        CameraDisplayLable->setText(QApplication::translate("MainWindow", "\345\233\276\345\203\217\346\230\276\347\244\272", 0));
        OpenSerialPortButton->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", 0));
        CleanAllDataButton->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272\346\225\260\346\215\256", 0));
        ScanSerialPortButton->setText(QApplication::translate("MainWindow", "\346\211\253\346\217\217\344\270\262\345\217\243", 0));
        TcpStateLable->setText(QApplication::translate("MainWindow", "TCP\347\212\266\346\200\201", 0));
        PictureFrameLable->setText(QApplication::translate("MainWindow", "FRAME", 0));
        RecordInitZAngle->setText(QApplication::translate("MainWindow", "\350\256\260\345\275\225\345\210\235\345\247\213Z\350\275\264\350\247\222\345\272\246", 0));
        uartFrame->setText(QApplication::translate("MainWindow", "uartFrame", 0));
        StartToRecvIamgeButton->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\346\216\245\345\217\227\350\247\206\351\242\221\346\225\260\346\215\256", 0));
        UseBackCamera->setText(QApplication::translate("MainWindow", "\344\275\277\347\224\250\345\220\216\346\221\204\345\203\217\345\244\264", 0));
        HeaderPoseModeButton->setText(QApplication::translate("MainWindow", "\344\275\277\347\224\250\345\244\264\351\203\250\345\220\216\345\270\246\346\250\241\345\274\217", 0));
        TestAngleButton->setText(QApplication::translate("MainWindow", "\346\265\213\350\257\225\350\247\222\345\272\246", 0));
        VolumeShowLable->setText(QApplication::translate("MainWindow", "\351\237\263\351\242\221", 0));
        OpenAudioButton->setText(QApplication::translate("MainWindow", "\345\205\263\351\227\255\351\237\263\351\242\221", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
