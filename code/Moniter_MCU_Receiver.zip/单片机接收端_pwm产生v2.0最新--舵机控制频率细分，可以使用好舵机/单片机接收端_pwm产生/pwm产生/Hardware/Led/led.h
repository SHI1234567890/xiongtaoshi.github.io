#ifndef _LED_H
#define	_LED_H

#include "system.h"

/**
*LED��������
*
*/

#define LED0		PBout(5)
#define LED1		PCout(1)
#define LED2		PCout(2)
#define LED3		PCout(3)

/**
*LED�˿ڵĺ궨��
*
*/

#define GPIO_PORT_LED0	GPIOB
#define GPIO_PIN_LED0		GPIO_Pin_5
#define RCC_LED0				RCC_APB2Periph_GPIOB

#define GPIO_PORT_LED1	GPIOC
#define GPIO_PIN_LED1		GPIO_Pin_1
#define RCC_LED1				RCC_APB2Periph_GPIOC

#define GPIO_PORT_LED2	GPIOC
#define GPIO_PIN_LED2		GPIO_Pin_2
#define RCC_LED2				RCC_APB2Periph_GPIOC

#define GPIO_PORT_LED3	GPIOC
#define GPIO_PIN_LED3		GPIO_Pin_3
#define RCC_LED3				RCC_APB2Periph_GPIOC

void vLED_Init(void);

#endif 

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
