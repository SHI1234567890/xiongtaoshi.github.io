#ifndef _WATCHDOG_H
#define	_WATCHDOG_H

#include "system.h"

#define IWDG_PERIOD_4096MS		((uint32_t)4095)

void vWatchDogInit(uint32_t PeriodInMs);
void vFeedWatchDog(void);

#endif 

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
