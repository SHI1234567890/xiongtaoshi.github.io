#ifndef _TIMER4PWM_H
#define	_TIMER4PWM_H

#include "system.h"

/* PWM�Ŀ���ռ�ձȷ�Χ */
#define MOTO_MAX_PWM_PAUSE					((int32_t)1000)

void vTIM4_Init(uint32_t ulClockDivide, uint32_t ulPeriod);
void vMotoPwmOut(int32_t lChannel1, int32_t lChannel2, int32_t lChannel3, int32_t lChannel4);
void vMotoXPwmOut(int32_t lChannel1, int32_t lChannel2);
void vMotoZPwmOut(int32_t lChannel3, int32_t lChannel4);
void vUnlockMoto(void);
void vAdjustMoto(void);

#endif 

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
