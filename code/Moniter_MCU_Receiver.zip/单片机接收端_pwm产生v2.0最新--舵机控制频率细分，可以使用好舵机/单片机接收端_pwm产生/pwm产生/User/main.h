#ifndef _MAIN_H
#define _MAIN_H

#include "system.h"
#include "usart1_dma.h"
#include "util.h"
#include "timer4pwm.h"
#include "control.h"
#include "led.h"
#include "watchDog.h"

/* �豸��ʼ��ʧ�ܣ���Ӧ���豸ID */
typedef enum 
{
	NO_EXAMPLE_DEVICE = 0,
}SystemInitFaultTypedef;

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
