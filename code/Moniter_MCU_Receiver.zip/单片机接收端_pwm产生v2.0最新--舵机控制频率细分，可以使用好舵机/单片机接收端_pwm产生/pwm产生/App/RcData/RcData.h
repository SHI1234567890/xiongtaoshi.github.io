#ifndef _RC_DATA_H
#define _RC_DATA_H

#include "system.h"
#include "util.h"

typedef struct
{
	float fX;
	float fY;
	float fZ;
}RC_RcTypeDef;

/* ����1 */
void vRcDataByUsart1(uint8_t *pucBuffer,RC_RcTypeDef *pxRcData);
/* ����2 */
void vRcData(uint8_t *pucBuffer,RC_RcTypeDef *pxRcData);


#endif
/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
