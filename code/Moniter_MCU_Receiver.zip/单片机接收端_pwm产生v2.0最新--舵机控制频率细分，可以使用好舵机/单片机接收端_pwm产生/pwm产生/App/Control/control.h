#ifndef _CONTROL_H
#define _CONTROL_H

#include "system.h"
#include "util.h"
#include "timer4pwm.h"
#include "usart1_dma.h"
#include "RcData.h"
#include "timer3.h"
#include "led.h"

typedef struct
{
	float fX;
	float fY;
	float fZ;
}CONTROL_AngleTypeDef;

void vMotorControl(void);
void vAdjustAngle(CONTROL_AngleTypeDef *pxAngleData);

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
