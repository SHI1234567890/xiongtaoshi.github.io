#include "control.h"

int32_t lFinalWidthX = 0;
int32_t lEveryStepWidthX = 0;
int32_t lStepHaveUse = 0;
int32_t lRealWidthX = 0;

int32_t lFinalWidthZ = 0;
int32_t lEveryStepWidthZ = 0;
int32_t lRealWidthZ = 0;

uint32_t ulIsFirstSet = 1;

void vInitValue(void)
{
	lFinalWidthX = 1410;
	lEveryStepWidthX = 0;
	lRealWidthX = 1410;
	
	lFinalWidthZ = 1410;
	lEveryStepWidthZ = 0;
	lRealWidthZ = 1410;
	
	lStepHaveUse = 0;
}

void mySetWidth(int32_t lTargetWidthX,int32_t lTargetWidthZ)
{
	if(ulIsFirstSet)
	{
		ulIsFirstSet = 0;
		vInitValue();
	}
	
	lEveryStepWidthX = (lTargetWidthX - lFinalWidthX) / 7;
	lFinalWidthX = lTargetWidthX;
	
	lEveryStepWidthZ = (lTargetWidthZ - lFinalWidthZ) / 7;
	lFinalWidthZ = lTargetWidthZ;
	lStepHaveUse = 7;
}

		/* 	0.5ms - 500   -90
			1.5ms - 1500  0
			2.5ms - 2500  90
		*/
#define X_CHANNEL_MIN		((int32_t)750)
#define X_CHANNEL_MAX		((int32_t)2250)

#define Z_CHANNEL_MIN		((int32_t)850)
#define Z_CHANNEL_MAX		((int32_t)1950)

#define ANGLE_DEAD_ZONE	((float)1.0f)

void vAdjustAngle(CONTROL_AngleTypeDef *pxAngleData)
{
	/* ��¼��һ�εĽǶ�ֵ */
	static int32_t fLastAngleX = 0.0f;
	static int32_t fLastAngleZ = 0.0f;	
	/* ��¼��һ�ε�ͨ������ */
	static uint32_t lLastChannel1 = 1400;
	static uint32_t lLastChannel3 = 1410;
	
	/* ���㵱ǰ��ͨ������ */
	int32_t lChannel1 = 0;
	int32_t lChannel3 = 0;
	
	float fAngleX = pxAngleData->fX;
	float fAngleZ = pxAngleData->fZ;
	
	if((fAngleX != 0.0f) || (fAngleZ != 0.0f))
	{	/* ���Ƕ�ֵ����ȡ�� */
		if(((fAngleX - fLastAngleX) < ANGLE_DEAD_ZONE) && ((fAngleX - fLastAngleX) > (-ANGLE_DEAD_ZONE)))
		{
			//�Ƕ�����
		}else
		{
			lChannel1 = (int32_t)((fAngleX * (2000 / 180)) + 1400);
		
			if(lChannel1 < X_CHANNEL_MIN)
			{
				lChannel1 = X_CHANNEL_MIN;
			}else if(lChannel1 > X_CHANNEL_MAX)
			{
				lChannel1 = X_CHANNEL_MAX;
			}
			lLastChannel1 = lChannel1;
			/* ��¼һ�µ�ǰ�ĽǶ�ֵ */
			fLastAngleX = fAngleX;
		}
	
		if(((fAngleZ - fLastAngleZ) < ANGLE_DEAD_ZONE) && ((fAngleZ - fLastAngleZ) > (-ANGLE_DEAD_ZONE)))
		{
			/* �Ƕ����� */
		}else
		{
			lChannel3 = (int32_t)((fAngleZ * (2000 / 180)) + 1410);
			if(lChannel3 < Z_CHANNEL_MIN)
			{
				lChannel3 = Z_CHANNEL_MIN;
			}else if(lChannel3 > Z_CHANNEL_MAX)
			{
				lChannel3 = Z_CHANNEL_MAX;		
			}
			lLastChannel3 = lChannel3;
			/* ��¼һ����һ�ε�ֵ�������´μ��� */
			fLastAngleZ = fAngleZ;
		}
	}
	//vMotoPwmOut(lLastChannel1, lLastChannel3, lLastChannel3, lLastChannel1);	
	mySetWidth(lLastChannel1,lLastChannel3);
}

uint32_t ulCntNumber = 0;

void vMotorControl(void)
{
	static CONTROL_AngleTypeDef xAngleData = {0.0f,0.0f,0.0f};
	if(ulUsart1RxOkFlag == 1)
	{
		ulUsart1RxOkFlag = 0;
		ulCntNumber++;
		/* ��ô������ĽǶ����� */
		vRcData((uint8_t *)vucUSART1_RxBuffer,(RC_RcTypeDef *)&xAngleData);
		/* ����һ�½Ƕ����� �Ƕ��޷� */
		//vCalculateAngle(&xAngleData);
		/* ����pwm ��������Ƕ� */
		vAdjustAngle(&xAngleData);
		/* ���¿��� */
		vUSART1_DmaRxStart();
		LED3 = !LED3;
	}
}

void TIM3_IRQHandler(void)   										
{
	static uint32_t ulTimer1S = 0;
	static uint32_t ulRxDataRate = 0;
	static uint32_t ulTmr10ms = 0;

	if(TIM3->SR & (uint32_t)(1)) 											
	{
		if(++ulTmr10ms >= 10)
		{
			ulTmr10ms = 0;
			if(lStepHaveUse)
			{
				lStepHaveUse--;
				lRealWidthX += lEveryStepWidthX;
				lRealWidthZ += lEveryStepWidthZ;
				
				/* ���һ�ε����ˣ�������ֱ�ӵ����������սǶ� */
				if(lStepHaveUse == 0)
				{
					lRealWidthX = lFinalWidthX;
					lRealWidthZ = lFinalWidthZ;
				}	
				vMotoPwmOut(lRealWidthX, lRealWidthX, lRealWidthZ, lRealWidthZ);
			}else
			{
				
			}
		}
		
		if(++ulTimer1S >= 1000)
		{
			ulTimer1S = 0;
			ulRxDataRate = ulCntNumber;
			ulCntNumber = 0;
			LED2 = !LED2;
		}
		TIM3 -> SR &= (uint32_t)(~1);										
	}
}


