#ifndef _RASPIIRQ_H
#define _RASPIIRQ_H

#include "stm32f1xx_hal.h"

HAL_StatusTypeDef CheckRaspiReady(void);

#endif
