#ifndef _TYPEDEF_H
#define _TYPEDEF_H

#include "stm32f1xx_hal.h"

typedef union
{
	uint32_t u32Data;
	float fData;
}F2U32;

#endif
