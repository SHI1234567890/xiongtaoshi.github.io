#ifndef _SPITRANSFER_H
#define _SPITRANSFER_H

#include "stm32f1xx_hal.h"

HAL_StatusTypeDef SpiSendData(void);

#endif
