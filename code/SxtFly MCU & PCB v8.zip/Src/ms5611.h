#ifndef _MS5611_H
#define _MS5611_H

#include "stm32f1xx_hal.h"

#define MS5611_IIC_ADDR						((uint8_t)0xEE)

#define MS5611_Reset							((uint8_t)0X1E)

#define MS5611_ConvertD1OSR256		((uint8_t)0X40)
#define MS5611_ConvertD1OSR512		((uint8_t)0X42)
#define MS5611_ConvertD1OSR1024		((uint8_t)0X44)
#define MS5611_ConvertD1OSR2048		((uint8_t)0X46)
#define MS5611_ConvertD1OSR4096		((uint8_t)0X48)

#define MS5611_ConvertD2OSR256		((uint8_t)0X50)
#define MS5611_ConvertD2OSR512		((uint8_t)0X52)
#define MS5611_ConvertD2OSR1024		((uint8_t)0X54)
#define MS5611_ConvertD2OSR2048		((uint8_t)0X56)
#define MS5611_ConvertD2OSR4096		((uint8_t)0X58)

#define MS5611_ADCRead						((uint8_t)0X00) 
#define MS5611_PROMRead						((uint8_t)0xA0)
#define MS5611_PROMCRCRead				((uint8_t)0xAE)

#define MS5611_PROMLength					((uint8_t)16)
#define MS5611_ADCLength					((uint8_t)3)

#define Ms5611RxBufferSize				((uint8_t)4)

typedef struct
{
	uint8_t Prom[MS5611_PROMLength];    
	uint16_t C1;
	uint16_t C2; 
	uint16_t C3;
	uint16_t C4;
	uint16_t C5;
	uint16_t C6; 
	uint8_t ADC[MS5611_ADCLength];  
	uint32_t D1;
	uint32_t D2;
	int32_t dT;
	int32_t T2;
	int32_t TEMP;
	int64_t OFF;
	int64_t OFF2;
	int64_t SENS;
	int64_t SENS2;
	int32_t P;
	uint32_t POW2_7;
	uint32_t POW2_8;
	uint32_t POW2_15; 
	uint32_t POW2_18;
	uint32_t POW2_21;
	uint32_t POW2_23;
	uint32_t POW2_31; 
	uint8_t MS5611RxBuffer[Ms5611RxBufferSize];
}Ms5611DataTypedef;

extern Ms5611DataTypedef ms5611Data1; 
extern Ms5611DataTypedef ms5611Data2;

HAL_StatusTypeDef Ms5611Init(void);
HAL_StatusTypeDef Ms5611StartConvertDx(uint8_t index, uint8_t dIndex);
HAL_StatusTypeDef Ms5611ReadAdc(uint8_t index);
HAL_StatusTypeDef Ms5611GetAdc(uint8_t index, uint8_t dIndex);
HAL_StatusTypeDef Ms5611CalcResult(uint8_t index);

#endif
