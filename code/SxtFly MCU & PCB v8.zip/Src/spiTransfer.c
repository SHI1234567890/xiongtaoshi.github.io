
#include "spiTransfer.h"

#include "mpu6050.h"
#include "hmc5883l.h"
#include "ms5611.h"
#include "gps.h"

#include "task.h"

//���ݰ��ܳ� 90
#define SPIBUFFERLENGTH	((uint32_t)90)
uint8_t SpiTxBuffer[SPIBUFFERLENGTH];
uint8_t SpiRxBuffer[SPIBUFFERLENGTH];

HAL_StatusTypeDef SetData2Buffer(void)
{
	uint32_t index = 0;
	uint32_t allIndex = 0;
	
	//14*2 + 6*2 + 8*2 + 26 + 3 = 85
	
	SpiTxBuffer[allIndex++] = 0X88;
	SpiTxBuffer[allIndex++] = 0X88;
	
	SpiTxBuffer[allIndex++] = (uint8_t)(SensorReadRealTimes >> 24);
	SpiTxBuffer[allIndex++] = (uint8_t)(SensorReadRealTimes >> 16);
	SpiTxBuffer[allIndex++] = (uint8_t)(SensorReadRealTimes >> 8);
	SpiTxBuffer[allIndex++] = (uint8_t)(SensorReadRealTimes);

	//MPU60501
	for(index=0; index<Mpu6050RxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = mpu6050Data1.Mpu6050RxBuffer[index];
	}
	//MPU60502
	for(index=0; index<Mpu6050RxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = mpu6050Data2.Mpu6050RxBuffer[index];
	}
	//HMC5883L1
	for(index=0; index<Hmc5883lRxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = hmc5883LData1.Hmc5883lRxBuffer[index];
	}	
	//HMC5883L2
	for(index=0; index<Hmc5883lRxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = hmc5883LData2.Hmc5883lRxBuffer[index];
	}	
	//MS56111
	for(index=0; index<Ms5611RxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = ms5611Data1.MS5611RxBuffer[index];
	}	
	//MS56112
	for(index=0; index<Ms5611RxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = ms5611Data2.MS5611RxBuffer[index];
	}
	//GPS
	for(index=0; index<GpsRxBufferSize; index++)
	{
		SpiTxBuffer[allIndex++] = gpsData.GpsRxBuffer[index];
	}	
	
	SpiTxBuffer[allIndex++] = 0X88;
	SpiTxBuffer[allIndex++] = 0X88;
	SpiTxBuffer[allIndex++] = 0X88;
	
	return HAL_OK;
}

extern SPI_HandleTypeDef hspi3;

extern TIM_HandleTypeDef htim7;   

HAL_StatusTypeDef SpiSendData(void)
{
	//�ϴ����ݴ���ȷʵ������
	if(IsSpiSendRecvEndFlag == 1)
	{
		//��ʼһ���µĴ���
		IsSpiSendRecvEndFlag = 0;
		//�����Џ�������������
		SetData2Buffer();
		//�ж��Ƿ�׼����
		if(HAL_SPI_TransmitReceive_DMA(&hspi3, SpiTxBuffer, SpiRxBuffer, SPIBUFFERLENGTH) == HAL_OK)
		{
			//��ת����ݮ����ӵ����ŵ�ƽ
			HAL_GPIO_TogglePin(RaspiIrq_GPIO_Port, RaspiIrq_Pin);
			
			return HAL_OK;
		}else
		{
			return HAL_ERROR;
		}
	}else
	{
		return HAL_ERROR;
	}
}

