
#include "hmc5883l.h"

//���I2C_HandleTypeDef��IIC���͵�Э��
extern I2C_HandleTypeDef hi2c1;		
extern I2C_HandleTypeDef hi2c2;	
//���Hmc5883lDataTypedef���͵ı���
Hmc5883lDataTypedef hmc5883LData1 = {0};
Hmc5883lDataTypedef hmc5883LData2 = {0};

//��Hmc5883l����д����
HAL_StatusTypeDef Hmc5883lWriteReg(uint8_t index, uint8_t regAddr, uint8_t regData)
{
	if(index == 1)
	{
		//���ض�Hmc5883l�Ĵ�����д����
		return HAL_I2C_Mem_Write(&hi2c1, HMC5883L_IIC_ADDR, regAddr, I2C_MEMADD_SIZE_8BIT, &regData, 1, 0xff);
	}else if(index == 2)
	{
		return HAL_I2C_Mem_Write(&hi2c2, HMC5883L_IIC_ADDR, regAddr, I2C_MEMADD_SIZE_8BIT, &regData, 1, 0xff);
	}else
	{
		return HAL_ERROR;
	}
}


//��Hmc5883l���ж�����
HAL_StatusTypeDef Hmc5883lMultReadData(uint8_t index, uint8_t regAddr, uint8_t * buffer, uint8_t length)
{
	if(index == 1)
	{
		//��IIC������ݵĽ��ܣ���ͨ��DMA���䵽������
		return HAL_I2C_Mem_Read_DMA(&hi2c1, HMC5883L_IIC_ADDR, regAddr, I2C_MEMADD_SIZE_8BIT, buffer, length);
	}else if(index == 2)
	{
		return HAL_I2C_Mem_Read_DMA(&hi2c2, HMC5883L_IIC_ADDR, regAddr, I2C_MEMADD_SIZE_8BIT, buffer, length);
	}else
	{
		return HAL_ERROR;
	}
}

//���ش������Ķ���
HAL_StatusTypeDef Hmc5883lRead(uint8_t index, uint8_t * buffer, uint8_t length)
{	
	return Hmc5883lMultReadData(index, HMC5883L_DATA_OUTPUT_X_MSB_ADDR, buffer, length);
}

//��Hmc5883l���г�ʼ��
HAL_StatusTypeDef Hmc5883lInit(void)
{
	//�ж�Hmc5883l�Ƿ�׼����
	if(HAL_I2C_IsDeviceReady(&hi2c1, HMC5883L_IIC_ADDR, 0XFF, 0XFF) != HAL_OK)
	{
		return HAL_ERROR;
	}	
	
	if(HAL_I2C_IsDeviceReady(&hi2c2, HMC5883L_IIC_ADDR, 0XFF, 0XFF) != HAL_OK)
	{
		return HAL_ERROR;
	}	
	
	//�жϼĴ���A�Ƿ�д��
	if(Hmc5883lWriteReg(1, HMC5883L_CONFIGURATION_A_ADDR, 0X18) != HAL_OK)	     				
	{
		return HAL_ERROR;
	}
	//�жϼĴ���B�Ƿ�д��
	if(Hmc5883lWriteReg(1, HMC5883L_CONFIGURATION_B_ADDR, 0X00) != HAL_OK)	    	
	{
		return HAL_ERROR;
	}
	//�ж�Hmc5883Lģʽ�Ƿ�д��
	if(Hmc5883lWriteReg(1, HMC5883L_MODE_ADDR, 0X00) != HAL_OK) 										
	{
		return HAL_ERROR;
	}		

	if(Hmc5883lWriteReg(2, HMC5883L_CONFIGURATION_A_ADDR, 0X18) != HAL_OK)	     				
	{
		return HAL_ERROR;
	}
	if(Hmc5883lWriteReg(2, HMC5883L_CONFIGURATION_B_ADDR, 0X00) != HAL_OK)	    	
	{
		return HAL_ERROR;
	}
	if(Hmc5883lWriteReg(2, HMC5883L_MODE_ADDR, 0X00) != HAL_OK) 										
	{
		return HAL_ERROR;
	}		
	
	return HAL_OK;
}

HAL_StatusTypeDef Hmc5883lReadData(uint32_t index)
{
	//�Ե�һ��Hmc5883l���ж����ݵĽ���
	if(index == 1)
	{
		//�ж������Ƿ��ͳɹ�
		if(Hmc5883lRead(1, hmc5883LData1.Hmc5883lRxBuffer, Hmc5883lRxBufferSize) != HAL_OK)
		{
			return HAL_ERROR;
		}		
		
		//�������������ݽ�����Hmc5883lDataTypedef���͵ı�����
		hmc5883LData1.Hmc5883lMagNowX = (((int16_t)hmc5883LData1.Hmc5883lRxBuffer[0] << 8)|hmc5883LData1.Hmc5883lRxBuffer[1]);
		hmc5883LData1.Hmc5883lMagNowY = (((int16_t)hmc5883LData1.Hmc5883lRxBuffer[2] << 8)|hmc5883LData1.Hmc5883lRxBuffer[3]);
		hmc5883LData1.Hmc5883lMagNowZ = (((int16_t)hmc5883LData1.Hmc5883lRxBuffer[4] << 8)|hmc5883LData1.Hmc5883lRxBuffer[5]);	

		return HAL_OK;
	}else if(index == 2)
	{
		if(Hmc5883lRead(2, hmc5883LData2.Hmc5883lRxBuffer, Hmc5883lRxBufferSize) != HAL_OK)
		{
			return HAL_ERROR;
		}
		
		hmc5883LData2.Hmc5883lMagNowX = (((int16_t)hmc5883LData2.Hmc5883lRxBuffer[0] << 8)|hmc5883LData2.Hmc5883lRxBuffer[1]);
		hmc5883LData2.Hmc5883lMagNowY = (((int16_t)hmc5883LData2.Hmc5883lRxBuffer[2] << 8)|hmc5883LData2.Hmc5883lRxBuffer[3]);
		hmc5883LData2.Hmc5883lMagNowZ = (((int16_t)hmc5883LData2.Hmc5883lRxBuffer[4] << 8)|hmc5883LData2.Hmc5883lRxBuffer[5]); 

		return HAL_OK;
	}else
	{
		return HAL_ERROR;
	}
}




