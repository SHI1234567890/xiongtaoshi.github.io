
#include "ms5611.h"
#include "math.h"

#include "typedef.h"

//����IIC��1,2�����͵ı���
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;

//����Ms5611DataTypedef���͵���������
Ms5611DataTypedef ms5611Data1 = {0}; 
Ms5611DataTypedef ms5611Data2 = {0}; 

HAL_StatusTypeDef Ms5611ReadPromBlock(uint8_t index)
{
	uint32_t promIndex = 0;
	
	if(index == 1)
	{
		for(promIndex=0; promIndex<MS5611_PROMLength; promIndex+=2)
		{
			//�ж��Ƿ�������ģʽ����Ӳ����ַ�����ݵ�ms5611Data1.Prom����
			if(HAL_I2C_Mem_Read(&hi2c1, MS5611_IIC_ADDR, MS5611_PROMRead+promIndex, I2C_MEMADD_SIZE_8BIT, ms5611Data1.Prom+promIndex, 2, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}
		}
		
		//�õ�Ӳ�����ص����ݣ����н���C
		ms5611Data1.C1 = (((uint16_t)ms5611Data1.Prom[2] << 8)|ms5611Data1.Prom[3]);
		ms5611Data1.C2 = (((uint16_t)ms5611Data1.Prom[4] << 8)|ms5611Data1.Prom[5]);
		ms5611Data1.C3 = (((uint16_t)ms5611Data1.Prom[6] << 8)|ms5611Data1.Prom[7]);
		ms5611Data1.C4 = (((uint16_t)ms5611Data1.Prom[8] << 8)|ms5611Data1.Prom[9]);
		ms5611Data1.C5 = (((uint16_t)ms5611Data1.Prom[10] << 8)|ms5611Data1.Prom[11]);
		ms5611Data1.C6 = (((uint16_t)ms5611Data1.Prom[12] << 8)|ms5611Data1.Prom[13]);
		
		//�õ�������Ҫ������ms5611Data1.POW
		ms5611Data1.POW2_7 = (uint32_t)1<<7;
		ms5611Data1.POW2_8 = (uint32_t)1<<8;
		ms5611Data1.POW2_15 = (uint32_t)1<<15;
		ms5611Data1.POW2_18 = (uint32_t)1<<18;
		ms5611Data1.POW2_21 = (uint32_t)1<<21;
		ms5611Data1.POW2_23 = (uint32_t)1<<23;
		ms5611Data1.POW2_31 = (uint32_t)1<<31; 

		ms5611Data1.P = 0;
		ms5611Data1.TEMP = 0;
		
		return HAL_OK;
	}else if(index == 2)
	//�Եڶ�����ѹ�ƽ������Ķ����ʹ�ŵ�ms5611Data2
	{
		for(promIndex=0; promIndex<MS5611_PROMLength; promIndex+=2)
		{
			if(HAL_I2C_Mem_Read(&hi2c2, MS5611_IIC_ADDR, MS5611_PROMRead+promIndex, I2C_MEMADD_SIZE_8BIT, ms5611Data2.Prom+promIndex, 2, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}
		}
		
		ms5611Data2.C1 = (((uint16_t)ms5611Data1.Prom[2] << 8)|ms5611Data1.Prom[3]);
		ms5611Data2.C2 = (((uint16_t)ms5611Data1.Prom[4] << 8)|ms5611Data1.Prom[5]);
		ms5611Data2.C3 = (((uint16_t)ms5611Data1.Prom[6] << 8)|ms5611Data1.Prom[7]);
		ms5611Data2.C4 = (((uint16_t)ms5611Data1.Prom[8] << 8)|ms5611Data1.Prom[9]);
		ms5611Data2.C5 = (((uint16_t)ms5611Data1.Prom[10] << 8)|ms5611Data1.Prom[11]);
		ms5611Data2.C6 = (((uint16_t)ms5611Data1.Prom[12] << 8)|ms5611Data1.Prom[13]);
		
		ms5611Data2.POW2_7 = (uint32_t)1<<7;
		ms5611Data2.POW2_8 = (uint32_t)1<<8;
		ms5611Data2.POW2_15 = (uint32_t)1<<15;
		ms5611Data2.POW2_18 = (uint32_t)1<<18;
		ms5611Data2.POW2_21 = (uint32_t)1<<21;
		ms5611Data2.POW2_23 = (uint32_t)1<<23;
		ms5611Data2.POW2_31 = (uint32_t)1<<31;
		
		ms5611Data2.P = 0;
		ms5611Data2.TEMP = 0;
		
		return HAL_OK;
	}else
	{
		return HAL_ERROR;
	}
}

HAL_StatusTypeDef Ms5611WriteCmdBlock(uint8_t index, uint8_t cmd)
{
	if(index == 1)
	{
		//ת��ģʽ
		return HAL_I2C_Master_Transmit(&hi2c1, MS5611_IIC_ADDR, &cmd, 1, 0xff);
	}else if(index == 2)
	{
		return HAL_I2C_Master_Transmit(&hi2c2, MS5611_IIC_ADDR, &cmd, 1, 0xff);
	}else
	{
		return HAL_ERROR;
	}	
}

HAL_StatusTypeDef Ms5611ReadAdcBlock(uint8_t index, uint8_t dIndex)
{
	//���ڵ�һ����ѹ��Ӳ��
	if(index == 1)
	{
		if(dIndex == 1)
		{
			//�ж϶������Ƿ�ɹ�
			if(HAL_I2C_Mem_Read(&hi2c1, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data1.ADC, MS5611_ADCLength, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}
			
			//�õ�D1
			ms5611Data1.D1 = (((uint32_t)ms5611Data1.ADC[0] << 16)|((uint32_t)ms5611Data1.ADC[1] << 8)|ms5611Data1.ADC[2]);
		}else if(dIndex == 2)
		{
			if(HAL_I2C_Mem_Read(&hi2c1, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data1.ADC, MS5611_ADCLength, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}	

			//�õ�D2
			ms5611Data1.D2 = (((uint32_t)ms5611Data1.ADC[0] << 16)|((uint32_t)ms5611Data1.ADC[1] << 8)|ms5611Data1.ADC[2]);
		}else
		{
			return HAL_ERROR;
		}

		return HAL_OK;
	}else if(index == 2)
	//�Եڶ�����ѹ��Ӳ����ȡ
	{
		if(dIndex == 1)
		{
			if(HAL_I2C_Mem_Read(&hi2c2, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data2.ADC, MS5611_ADCLength, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}
			
			ms5611Data2.D1 = (((uint32_t)ms5611Data2.ADC[0] << 16)|((uint32_t)ms5611Data2.ADC[1] << 8)|ms5611Data2.ADC[2]);
		}else if(dIndex == 2)
		{
			if(HAL_I2C_Mem_Read(&hi2c2, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data2.ADC, MS5611_ADCLength, 0XFF) != HAL_OK)
			{
				return HAL_ERROR;
			}	

			ms5611Data2.D2 = (((uint32_t)ms5611Data2.ADC[0] << 16)|((uint32_t)ms5611Data2.ADC[1] << 8)|ms5611Data2.ADC[2]);
		}else
		{
			return HAL_ERROR;
		}

		return HAL_OK;
	}else
	{
		return HAL_ERROR;
	}	
}

HAL_StatusTypeDef Ms5611StartConvertDx(uint8_t index, uint8_t dIndex)
{
	uint8_t cmdDx = 0;
	
	if(index == 1)
	{
		if(dIndex == 1)
		{
			//��ַ
			cmdDx = MS5611_ConvertD1OSR4096; 
			//ת��ģʽΪ����ģʽ
			return HAL_I2C_Master_Transmit(&hi2c1, MS5611_IIC_ADDR, &cmdDx, 1, 0xff);
		}else if(dIndex == 2)
		{
			cmdDx = MS5611_ConvertD2OSR4096; 
			return HAL_I2C_Master_Transmit(&hi2c1, MS5611_IIC_ADDR, &cmdDx, 1, 0xff);
		}else
		{
			return HAL_ERROR;
		}
		
	}else if(index == 2)
	{
		if(dIndex == 1)
		{
			cmdDx = MS5611_ConvertD1OSR4096; 
			return HAL_I2C_Master_Transmit(&hi2c2, MS5611_IIC_ADDR, &cmdDx, 1, 0xff);
		}else if(dIndex == 2)
		{
			cmdDx = MS5611_ConvertD2OSR4096; 
			return HAL_I2C_Master_Transmit(&hi2c2, MS5611_IIC_ADDR, &cmdDx, 1, 0xff);
		}else
		{
			return HAL_ERROR;
		}
	}else
	{
		return HAL_ERROR;
	}	
}

//����ADC
HAL_StatusTypeDef Ms5611ReadAdc(uint8_t index)
{
	if(index == 1)
	{
		if(HAL_I2C_Mem_Read_DMA(&hi2c1, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data1.ADC, MS5611_ADCLength) != HAL_OK)
		{
			return HAL_ERROR;
		}
// 		if(HAL_I2C_Mem_Read(&hi2c1, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data1.ADC, MS5611_ADCLength, 0XFF) != HAL_OK) 
// 		{
// 			return HAL_ERROR;
// 		}

		return HAL_OK;
	}else if(index == 2)
	{
		if(HAL_I2C_Mem_Read_DMA(&hi2c2, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data2.ADC, MS5611_ADCLength) != HAL_OK)
		{
			return HAL_ERROR;
		}	
// 		if(HAL_I2C_Mem_Read(&hi2c2, MS5611_IIC_ADDR, MS5611_ADCRead, I2C_MEMADD_SIZE_8BIT, ms5611Data2.ADC, MS5611_ADCLength, 0XFF) != HAL_OK)
// 		{
// 			return HAL_ERROR;
// 		}	

		return HAL_OK;
	}else
	{
		return HAL_ERROR;
	}	
}

//�õ�ADC����
HAL_StatusTypeDef Ms5611GetAdc(uint8_t index, uint8_t dIndex)
{
	//��һ��Ӳ��
	if(index == 1)
	{
		if(dIndex == 1)
		{
			ms5611Data1.D1 = (((uint32_t)ms5611Data1.ADC[0] << 16)|((uint32_t)ms5611Data1.ADC[1] << 8)|ms5611Data1.ADC[2]);
		}else if(dIndex == 2)
		{
			ms5611Data1.D2 = (((uint32_t)ms5611Data1.ADC[0] << 16)|((uint32_t)ms5611Data1.ADC[1] << 8)|ms5611Data1.ADC[2]);
		}else
		{
			return HAL_ERROR;
		}
		
		return HAL_OK;		
	}else if(index == 2)
	{
		if(dIndex == 1)
		{
			ms5611Data2.D1 = (((uint32_t)ms5611Data2.ADC[0] << 16)|((uint32_t)ms5611Data2.ADC[1] << 8)|ms5611Data2.ADC[2]);
		}else if(dIndex == 2)
		{
			ms5611Data2.D2 = (((uint32_t)ms5611Data2.ADC[0] << 16)|((uint32_t)ms5611Data2.ADC[1] << 8)|ms5611Data2.ADC[2]);
		}else
		{
			return HAL_ERROR;
		}
		
		return HAL_OK;			
	}else
	{
		return HAL_ERROR;
	}
}

//�����������ݽ��н������
HAL_StatusTypeDef Ms5611CalcResult(uint8_t index)
{
	//���ڵ�һ��Ӳ��
	if(index == 1)
	{
		//���¶Ȳ�
		ms5611Data1.dT = ms5611Data1.D2 - (ms5611Data1.C5 * ms5611Data1.POW2_8);
		//����õ��¶ȱ���
		ms5611Data1.TEMP = (int32_t)2000 + (ms5611Data1.dT*ms5611Data1.C6)/ms5611Data1.POW2_23;
		ms5611Data1.OFF = ms5611Data1.C2 * ms5611Data1.POW2_18 + (ms5611Data1.C4 * ms5611Data1.dT)/ms5611Data1.POW2_7;
		ms5611Data1.SENS = ms5611Data1.C1 * ms5611Data1.POW2_15 + (ms5611Data1.C3 * ms5611Data1.dT)/ms5611Data1.POW2_8;
		
		if(ms5611Data1.TEMP >= (int32_t)2000)
		{
			ms5611Data1.T2 = 0;
			ms5611Data1.OFF2 = 0;
			ms5611Data1.SENS2 = 0;			
		}else
		{
			ms5611Data1.T2 = ((int64_t)ms5611Data1.dT * (int64_t)ms5611Data1.dT) / (int64_t)ms5611Data1.POW2_31;
			ms5611Data1.OFF2 = (int64_t)5 * ((ms5611Data1.TEMP - (int64_t)2000) * (ms5611Data1.TEMP - (int64_t)2000)) / (int64_t)2;
			ms5611Data1.SENS2 = ms5611Data1.OFF2 / 2;
			
			if(ms5611Data1.TEMP < (int32_t)-1500)
			{
				ms5611Data1.OFF2 += (int64_t)7 * (ms5611Data1.TEMP + (int32_t)1500) * (ms5611Data1.TEMP + (int32_t)1500);
				ms5611Data1.SENS2 += (int64_t)11 * (ms5611Data1.TEMP + (int32_t)1500) * (ms5611Data1.TEMP + (int32_t)1500) / (int64_t)2;
			}
		}
		
		ms5611Data1.TEMP -= ms5611Data1.T2;
		ms5611Data1.OFF -= ms5611Data1.OFF2;
		ms5611Data1.SENS -= ms5611Data1.SENS2;

		//�õ�ѹ������
		ms5611Data1.P = ((ms5611Data1.D1 * ms5611Data1.SENS)/ms5611Data1.POW2_21 - ms5611Data1.OFF)/ms5611Data1.POW2_15;
		
		ms5611Data1.MS5611RxBuffer[0] = (uint8_t)((uint32_t)ms5611Data1.P >> 24);
		ms5611Data1.MS5611RxBuffer[1] = (uint8_t)((uint32_t)ms5611Data1.P >> 16);
		ms5611Data1.MS5611RxBuffer[2] = (uint8_t)((uint32_t)ms5611Data1.P >> 8);
		ms5611Data1.MS5611RxBuffer[3] = (uint8_t)((uint32_t)ms5611Data1.P);
		
		return HAL_OK;
	}else if(index == 2)
	{
		//���¶Ȳ�
		ms5611Data2.dT = ms5611Data2.D2 - (ms5611Data2.C5 * ms5611Data2.POW2_8);
		//����õ��¶ȱ���
		ms5611Data2.TEMP = (int32_t)2000 + (ms5611Data2.dT*ms5611Data2.C6)/ms5611Data2.POW2_23;
		ms5611Data2.OFF = ms5611Data2.C2 * ms5611Data2.POW2_18 + (ms5611Data2.C4 * ms5611Data2.dT)/ms5611Data2.POW2_7;
		ms5611Data2.SENS = ms5611Data2.C1 * ms5611Data2.POW2_15 + (ms5611Data2.C3 * ms5611Data2.dT)/ms5611Data2.POW2_8;
		
		if(ms5611Data2.TEMP >= (int32_t)2000)
		{
			ms5611Data2.T2 = 0;
			ms5611Data2.OFF2 = 0;
			ms5611Data2.SENS2 = 0;			
		}else
		{
			ms5611Data2.T2 = ((int64_t)ms5611Data2.dT * (int64_t)ms5611Data2.dT) / (int64_t)ms5611Data2.POW2_31;
			ms5611Data2.OFF2 = (int64_t)5 * ((ms5611Data2.TEMP - (int64_t)2000) * (ms5611Data2.TEMP - (int64_t)2000)) / (int64_t)2;
			ms5611Data2.SENS2 = ms5611Data2.OFF2 / 2;
			
			if(ms5611Data2.TEMP < (int32_t)-1500)
			{
				ms5611Data2.OFF2 += (int64_t)7 * (ms5611Data2.TEMP + (int32_t)1500) * (ms5611Data2.TEMP + (int32_t)1500);
				ms5611Data2.SENS2 += (int64_t)11 * (ms5611Data2.TEMP + (int32_t)1500) * (ms5611Data2.TEMP + (int32_t)1500) / (int64_t)2;
			}
		}
		
		ms5611Data2.TEMP -= ms5611Data2.T2;
		ms5611Data2.OFF -= ms5611Data2.OFF2;
		ms5611Data2.SENS -= ms5611Data2.SENS2;

		//�õ�ѹ������
		ms5611Data2.P = ((ms5611Data2.D1 * ms5611Data2.SENS)/ms5611Data2.POW2_21 - ms5611Data2.OFF)/ms5611Data2.POW2_15;
		
		ms5611Data2.MS5611RxBuffer[0] = (uint8_t)((uint32_t)ms5611Data2.P >> 24);
		ms5611Data2.MS5611RxBuffer[1] = (uint8_t)((uint32_t)ms5611Data2.P>> 16);
		ms5611Data2.MS5611RxBuffer[2] = (uint8_t)((uint32_t)ms5611Data2.P >> 8);
		ms5611Data2.MS5611RxBuffer[3] = (uint8_t)((uint32_t)ms5611Data2.P);
		
		return HAL_OK;
	}else
	{
		return HAL_ERROR;
	}
}

//��Ӳ�����г�ʼ��
HAL_StatusTypeDef Ms5611Init(void)
{	
	//���Ӳ��1�Ƿ�׼����
	if(HAL_I2C_IsDeviceReady(&hi2c1, MS5611_IIC_ADDR, 0XFF, 0XFF) != HAL_OK)
	{
		return HAL_ERROR;
	}
	//���Ӳ���Ƿ�׼����
	if(HAL_I2C_IsDeviceReady(&hi2c2, MS5611_IIC_ADDR, 0XFF, 0XFF) != HAL_OK)
	{
		return HAL_ERROR;
	}
	
	/* ��λ */
	if(Ms5611WriteCmdBlock(1, MS5611_Reset) != HAL_OK)
	{
		return HAL_ERROR;
	}
	
	/* ��λ */
	if(Ms5611WriteCmdBlock(2, MS5611_Reset) != HAL_OK)
	{
		return HAL_ERROR; 
	}
	
	/* �ȴ���λ�ɹ� */
	HAL_Delay(10);
	
	/* ��ȡ ��һ�� MS5611 �� PROM */	
	if(Ms5611ReadPromBlock(1) != HAL_OK)
	{
		return HAL_ERROR;
	}	
	
	/* ��ȡ �ڶ��� MS5611 �� PROM */
	if(Ms5611ReadPromBlock(2) != HAL_OK) 
	{
		return HAL_ERROR;
	}
	
	//��ʼת��
	if(Ms5611WriteCmdBlock(1, MS5611_ConvertD1OSR4096) != HAL_OK)
	{
		return HAL_ERROR;
	}
	//��ʼת��
	if(Ms5611WriteCmdBlock(2, MS5611_ConvertD1OSR4096) != HAL_OK)
	{
		return HAL_ERROR;
	}
	/* ��ʱ�ȴ� */
	HAL_Delay(10);
	
	/* ��������D1 */
	if(Ms5611ReadAdcBlock(1, 1) != HAL_OK)
	{
		return HAL_ERROR;
	}
	/* ��������D1 */
	if(Ms5611ReadAdcBlock(2, 1) != HAL_OK)
	{
		return HAL_ERROR;
	}
	
	//��ʼת��
	if(Ms5611WriteCmdBlock(1, MS5611_ConvertD2OSR4096) != HAL_OK)
	{
		return HAL_ERROR;
	}
	//��ʼת��
	if(Ms5611WriteCmdBlock(2, MS5611_ConvertD2OSR4096) != HAL_OK)
	{
		return HAL_ERROR;
	}
	/* ��ʱ�ȴ� */
	HAL_Delay(10);
	
	/* ��������D2 */
	if(Ms5611ReadAdcBlock(1, 2) != HAL_OK)
	{
		return HAL_ERROR;
	}
	/* ��������D2 */
	if(Ms5611ReadAdcBlock(2, 2) != HAL_OK)
	{
		return HAL_ERROR;
	}
	
	return HAL_OK;
}

