# -*- coding: cp936 -*-
import copy
import numpy
import random
import math

class EvolutionStrategies:
    def __init__(self, populationNum, biasNum, weightNum):
        self.reCombinationRate = 0.8
        self.populationNum = populationNum
        self.dnaNum = biasNum+weightNum
        self.biasNum = biasNum
        self.weightNum = weightNum
        self.times = 4
        self.reCombinationNum = int(self.reCombinationRate * populationNum)
        if (self.reCombinationNum == 0):
            self.reCombinationNum = 2
        if ((self.reCombinationNum%2) != 0):
            self.reCombinationNum -= 1
        #���� x �� sigma
        #[x0, sigma0]
        self.population = numpy.mat(numpy.random.normal(0, 10, [self.populationNum, self.dnaNum]))
        self.sigma = numpy.mat(numpy.random.normal(2, 0.5, [self.populationNum, self.dnaNum]))
        #self.fitness = numpy.mat(numpy.random.normal(0, 10, populationNum)).T
        self.fitness = self.getFitness(self.population)
        
    def printParameter(self):
        print self.population
        print self.sigma
        print self.fitness

    #bias = [ [], ...]     weight = [ [], ...]
    def getParameter(self):
        bias = []
        weight = []
        for i in range(self.populationNum):
            tempBias = []
            for j in range(0, self.biasNum, 1):
                tempBias.append(self.population[i, j])
            bias.append(tempBias)
            tempWeight = []
            for j in range(self.biasNum, self.biasNum+self.weightNum, 1):
                tempWeight.append(self.population[i, j])
            weight.append(tempWeight)

        return bias, weight
        
    def printParameterType(self):
        print type(self.population)
        print type(self.sigma)
        print type(self.fitness)

    def getFitness(self, data):
        return -numpy.multiply(data, data)

    def setFitness(self, fitness):
        self.fitness = numpy.mat(fitness)

    def reCombination(self):
        result = numpy.argsort(-self.fitness, axis=0)
        childPopulation = numpy.mat(numpy.zeros((int(self.reCombinationNum/2), self.dnaNum)))
        childSigma = numpy.mat(numpy.zeros((int(self.reCombinationNum/2), self.dnaNum)))

        #��������
        index = 0
        for i in range(0, self.reCombinationNum, 2):
            for j in range(self.dnaNum):
                if(random.randint(0, 1)):
                    childPopulation[index, j] = self.population[result[i, 0], j]
                    childSigma[index, j] = self.sigma[result[i, 0], j]
                else:
                    childPopulation[index, j] = self.population[result[i+1, 0], j]
                    childSigma[index, j] = self.sigma[result[i+1, 0], j]
            index += 1

        #print 'childPopulation', childPopulation

        #����ͻ��
        childSigma *= math.exp(numpy.random.normal(0, 1))
        mutationPopulation = numpy.mat(numpy.zeros((int(numpy.shape(childPopulation)[0]*self.times), self.dnaNum)))
        
        for i in range(self.times):
            for j in range(numpy.shape(childPopulation)[0]):
                for k in range(self.dnaNum):
                    if (i == 0 or i == 1):
                        mutationPopulation[i*numpy.shape(childPopulation)[0]+j , k] = childPopulation[j , k]
                    else:
                        mutationPopulation[i*numpy.shape(childPopulation)[0]+j , k] = childPopulation[j , k] + numpy.random.normal(0, childSigma[j , k])


        #mutationFitness = numpy.mat(numpy.random.normal(0, 10, int(numpy.shape(childPopulation)[0]*self.times))).T
        mutationFitness = self.getFitness(mutationPopulation)

        #print 'mutationPopulation', mutationPopulation

        result = numpy.argsort(-mutationFitness, axis=0)

        for i in range(self.populationNum):
            self.population[i, :] = mutationPopulation[result[i, 0], :]
            self.fitness[i, 0] = mutationFitness[result[i, 0], 0]
            
        #print 'self.population', self.population
        #print 'min(self.population)', min(abs(self.population[:, 0]))
        #print 'self.fitness', self.fitness

        
