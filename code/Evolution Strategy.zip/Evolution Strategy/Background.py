class Background:
    def __init__(self, xLength, yLength, moveSpeed):
        self.imageFileName = 'background.png'
        self.xLength = xLength
        self.yLength = yLength
        self.moveSpeed = moveSpeed
        self.position1 = 0
        self.position2 = xLength

    def loadPicture(self, pygame):
        self.image_background = pygame.transform.smoothscale(pygame.image.load(self.imageFileName).convert_alpha(), (self.xLength, self.yLength))

    def getPicture(self):
        return self.image_background

    def getPosition1(self):
        return self.position1

    def getPosition2(self):
        return self.position2

    def reset(self):
        self.position1 = 0
        self.position2 = self.xLength

    def update(self):
        self.position1 -= self.moveSpeed
        self.position2 -= self.moveSpeed

        if (self.position1 < -self.xLength):
            self.position1 = self.xLength

        if (self.position2 < -self.xLength):
            self.position2 = self.xLength

    def draw(self, mainScreenPicture):
        mainScreenPicture.blit(self.getPicture(), (self.getPosition1(), 0))
        mainScreenPicture.blit(self.getPicture(), (self.getPosition2(), 0))




