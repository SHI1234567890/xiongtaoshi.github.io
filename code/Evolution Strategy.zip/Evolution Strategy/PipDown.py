# -*- coding: cp936 -*-

class PipDown:
    def __init__(self, xLength, heightSpacing, moveSpeed, startPosition, pipSpacing, yScreenLength):
        self.imageFileName = 'pipebottom.png'
        self.xLength = xLength
        self.heightSpacing = heightSpacing
        self.yScreenLength = yScreenLength
        self.moveSpeed = moveSpeed
        self.startPosition = startPosition
        self.pipSpacing = pipSpacing
        self.position1 = startPosition
        self.position2 = startPosition + pipSpacing
        
    def loadPicture(self, pygame, pictureHeight1, pictureHeight2):
        self.image_pipdown1 = pygame.transform.smoothscale(\
                                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                                    (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight1))
        self.image_pipdown2 = pygame.transform.smoothscale(\
                                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                                    (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight2))

    def getPicture1(self):
        return self.image_pipdown1

    def getPicture2(self):
        return self.image_pipdown2

    def getPosition1(self):
        return self.position1

    def getPosition2(self):
        return self.position2

    def getPicture1Height(self):
        return self.image_pipdown1.get_height()

    def getPicture2Height(self):
        return self.image_pipdown2.get_height()

    def getPosition(self):
        #���Ͻ�(X,Y), ���Ͻ�(X,Y), ���½�(X,Y), ���½�(X,Y)
        position1 = []
        position2 = []

        position1.append([self.position1, self.yScreenLength-self.image_pipdown1.get_height()])
        position1.append([self.position1+self.image_pipdown1.get_width(), self.yScreenLength-self.image_pipdown1.get_height()])
        position1.append([self.position1, self.yScreenLength])
        position1.append([self.position1+self.image_pipdown1.get_width(), self.yScreenLength])

        position2.append([self.position2, self.yScreenLength-self.image_pipdown2.get_height()])
        position2.append([self.position2+self.image_pipdown2.get_width(), self.yScreenLength-self.image_pipdown2.get_height()])
        position2.append([self.position2, self.yScreenLength])
        position2.append([self.position2+self.image_pipdown2.get_width(), self.yScreenLength])

        return [position1, position2]

    def reset(self, pygame, pictureHeight1, pictureHeight2):
        self.position1 = self.startPosition
        self.position2 = self.startPosition + self.pipSpacing

        self.image_pipdown1 = pygame.transform.smoothscale(\
                                                pygame.image.load(self.imageFileName).convert_alpha(), \
                                                (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight1))
        self.image_pipdown2 = pygame.transform.smoothscale(\
                                                pygame.image.load(self.imageFileName).convert_alpha(), \
                                                (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight2))

    def update(self, pygame, pictureHeight1, pictureHeight2):
        self.position1 -= self.moveSpeed
        self.position2 -= self.moveSpeed

        if (self.position1 < -self.xLength):
            self.position1 = self.startPosition
            self.image_pipdown1 = pygame.transform.smoothscale(\
                                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                                    (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight1))

        if (self.position2 < -self.xLength):
            self.position2 = self.startPosition
            self.image_pipdown2 = pygame.transform.smoothscale(\
                                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                                    (self.xLength, self.yScreenLength-self.heightSpacing-pictureHeight2))

    def draw(self, mainScreenPicture):
        mainScreenPicture.blit(self.getPicture1(), (self.getPosition1(), self.yScreenLength-self.getPicture1Height()))
        mainScreenPicture.blit(self.getPicture2(), (self.getPosition2(), self.yScreenLength-self.getPicture2Height()))   
