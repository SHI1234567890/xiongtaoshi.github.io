class MoveSpeed:
    def __init__(self, moveSpeed):
        self.moveSpeed = moveSpeed

    def getMoveSpeed(self):
        return self.moveSpeed
