class Screen:
    def __init__(self, xLength, yLength):
        self.xLength = xLength
        self.yLength = yLength

    def getLength(self):
        return self.xLength, self.yLength

    def getXLength(self):
        return self.xLength

    def getYLength(self):
        return self.yLength

