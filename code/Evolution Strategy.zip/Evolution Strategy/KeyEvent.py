import pygame
import sys
import pygame.locals

class KeyEvent:
    def __init__(self):
        self.keyDownFlag = False
        self.speed = 60

    def getKeyDownFlag(self):
        return self.keyDownFlag

    def reset(self):
        self.keyDownFlag = False

    def getSpeed(self):
        return self.speed

    def update(self, allEvent):
        for event in allEvent:
            if event.type == pygame.locals.QUIT:
                sys.exit()
                
            if event.type == pygame.locals.KEYDOWN:
                if event.key == pygame.locals.K_UP:
                    self.speed += 60
                elif event.key == pygame.locals.K_DOWN:
                    self.speed -= 60
                print 'self.speed', self.speed
            '''
            if event.type == pygame.locals.KEYDOWN:
                self.keyDownFlag = True
            elif event.type == pygame.locals.KEYUP:
                self.keyDownFlag = False
            '''

                
