# -*- coding: cp936 -*-

import random

class PipUp:
    def __init__(self, xLength, yLengthMax, yLengthMin, moveSpeed, startPosition, pipSpacing):
        self.imageFileName = 'pipetop.png'
        self.xLength = xLength
        self.yLengthMax = yLengthMax
        self.yLengthMin = yLengthMin
        self.moveSpeed = moveSpeed
        self.startPosition = startPosition
        self.pipSpacing = pipSpacing
        self.position1 = startPosition
        self.position2 = startPosition + pipSpacing

    def loadPicture(self, pygame):
        self.image_pipup1 = pygame.transform.smoothscale(\
                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                    (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))
        self.image_pipup2 = pygame.transform.smoothscale(\
                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                    (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))

    def getPicture1(self):
        return self.image_pipup1

    def getPicture2(self):
        return self.image_pipup2

    def getPosition1(self):
        return self.position1

    def getPosition2(self):
        return self.position2

    def getPicture1Height(self):
        return self.image_pipup1.get_height()

    def getPicture2Height(self):
        return self.image_pipup2.get_height()

    def getPosition(self):
        #���Ͻ�(X,Y), ���Ͻ�(X,Y), ���½�(X,Y), ���½�(X,Y)
        position1 = []
        position2 = []

        position1.append([self.position1, 0])
        position1.append([self.position1+self.image_pipup1.get_width(), 0])
        position1.append([self.position1, self.image_pipup1.get_height()])
        position1.append([self.position1+self.image_pipup1.get_width(), self.image_pipup1.get_height()])

        position2.append([self.position2, 0])
        position2.append([self.position2+self.image_pipup2.get_width(), 0])
        position2.append([self.position2, self.image_pipup2.get_height()])
        position2.append([self.position2+self.image_pipup2.get_width(), self.image_pipup2.get_height()])

        return [position1, position2]

    def reset(self, pygame):
        self.position1 = self.startPosition
        self.position2 = self.startPosition + self.pipSpacing

        self.image_pipup1 = pygame.transform.smoothscale(\
                                        pygame.image.load(self.imageFileName).convert_alpha(), \
                                        (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))
        self.image_pipup2 = pygame.transform.smoothscale(\
                                        pygame.image.load(self.imageFileName).convert_alpha(), \
                                        (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))
        
    def update(self, pygame):
        self.position1 -= self.moveSpeed
        self.position2 -= self.moveSpeed
        
        if (self.position1 < -self.xLength):
            self.position1 = self.startPosition
            self.image_pipup1 = pygame.transform.smoothscale(\
                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                    (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))

        if (self.position2 < -self.xLength):
            self.position2 = self.startPosition
            self.image_pipup2 = pygame.transform.smoothscale(\
                                                    pygame.image.load(self.imageFileName).convert_alpha(), \
                                                    (self.xLength, random.randint(self.yLengthMin, self.yLengthMax)))
        

    def draw(self, mainScreenPicture):
        mainScreenPicture.blit(self.getPicture1(), (self.getPosition1(), 0))
        mainScreenPicture.blit(self.getPicture2(), (self.getPosition2(), 0))
