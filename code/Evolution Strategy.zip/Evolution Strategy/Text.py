class Text:
    def __init__(self):
        self.scoreNowPosition = (10, 10)    
        self.scoreMaxPosition = (10, 30)
        self.generationPosition = (10, 50)
        self.alivePosition = (10, 70)
        self.gameoverFlagPosition = (10, 90)

        self.scoreNow = 0
        self.scoreMax = 0
        self.generation = 0
        self.alive = 0
        self.gameoverFlag = False

    def printText(self, mainScreenPicture, mainScreenText, alive, gameoverFlag):
        
        self.alive = alive
        self.gameoverFlag = gameoverFlag
        
        textSurface = mainScreenText.render('scoreNow:{%d}'%(self.scoreNow), True, (255, 255, 255))
        mainScreenPicture.blit(textSurface, self.scoreNowPosition)

        textSurface = mainScreenText.render('scoreMax:{%d}'%(self.scoreMax), True, (255, 255, 255))
        mainScreenPicture.blit(textSurface, self.scoreMaxPosition)

        textSurface = mainScreenText.render('generation:{%d}'%(self.generation), True, (255, 255, 255))
        mainScreenPicture.blit(textSurface, self.generationPosition)

        textSurface = mainScreenText.render('alive:{%d}'%(self.alive), True, (255, 255, 255))
        mainScreenPicture.blit(textSurface, self.alivePosition)

        if(self.gameoverFlag == True):
            textSurface = mainScreenText.render('gameover', True, (255, 255, 255))
            mainScreenPicture.blit(textSurface, self.gameoverFlagPosition)
        else:
            textSurface = mainScreenText.render('notGameover', True, (255, 255, 255))
            mainScreenPicture.blit(textSurface, self.gameoverFlagPosition)

    def reset(self):
        self.scoreNow = 0
        self.generation += 1

    def update(self):
        self.scoreNow += 1
        if (self.scoreMax < self.scoreNow):
            self.scoreMax = self.scoreNow
    
