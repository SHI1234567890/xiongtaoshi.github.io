import numpy

class NeuralNetwork:
    def __init__(self, networkSize):
        #networkSize = [2, 3, 1]
        #input = [[x], [x]]
        #bias = [[3X1], [1X1]]
        #weight = [[3X2], [1X3]]
        self.networkLen = len(networkSize)
        self.networkBias = [numpy.mat(numpy.random.randn(x, 1)) for x in networkSize[1:]]
        self.networkWeight = [numpy.mat(numpy.random.randn(x, y)) for x,y in zip(networkSize[1:], networkSize[:-1])]

    def sigmoid(self, z):
        return 1/(1+numpy.exp(-z))

    def setParameter(self, biasOne, weightOne):
        index = 0
        for i in range(len(self.networkBias)):
            length = numpy.shape(self.networkBias[i])
            for j in range(length[0]):
                for k in range(length[1]):
                    self.networkBias[i][j, k] = biasOne[index]
                    index += 1
        index = 0
        for i in range(len(self.networkWeight)):
            length = numpy.shape(self.networkWeight[i])
            for j in range(length[0]):
                for k in range(length[1]):
                    self.networkWeight[i][j, k] = weightOne[index]
                    index += 1

    def getBiasNum(self):
        biasNum = 0
        for i in range(len(self.networkBias)):
            biasNum += numpy.shape(self.networkBias[i])[0]
        return biasNum

    def getWeightNum(self):
        weightNum = 0
        for i in range(len(self.networkWeight)):
            length = numpy.shape(self.networkWeight[i])
            weightNum += length[0] * length[1]

        return weightNum

    def feedForword(self, x):
        x = numpy.mat(x)
        for i in range(self.networkLen-1):
            x = self.sigmoid(self.networkWeight[i]*x + self.networkBias[i])
        return x

class NeuralNetworkGroup:
    def __init__(self, popNumber, networkSize):
        self.popNumber = popNumber
        self.myNeuralNetworkGroup = []
        self.output = []
        for i in range(popNumber):
            self.myNeuralNetworkGroup.append(NeuralNetwork(networkSize))
            self.output.append(False)

    #[ 50 [[x], [x]]  ...]
    def feedForword(self, x):
        for i in range(self.popNumber):
            if(self.myNeuralNetworkGroup[i].feedForword(x[i]) > 0.5):
                self.output[i] = True
            else:
                self.output[i] = False

        return self.output

    def getBiasNum(self):
        return self.myNeuralNetworkGroup[0].getBiasNum()
        
    def getWeightNum(self):
        return self.myNeuralNetworkGroup[0].getWeightNum()

    #bias = [ [], ...]     weight = [ [], ...]
    def setParameter(self, data):
        bias = data[0]
        weight = data[1]
        
        for i in range(self.popNumber):
            self.myNeuralNetworkGroup[i].setParameter(bias[i], weight[i])
