

import matplotlib
import matplotlib.pyplot as plt
import numpy
import random

myList1 = [188, 141, 142, 135, 135, 136, 135, 136, 135, 135, 135, 135, 135, 135, 135, 135,
           135, 135, 135, 135, 135, 137, 201, 158, 138, 158, 236, 392, 554]



myListIndex = range(len(myList1))


#01
fig01 = plt.figure()

ax = fig01.add_subplot(111)
ax.set_title('best value')
ax.plot(myListIndex, myList1)
    
plt.show()
