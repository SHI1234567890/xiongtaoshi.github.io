# -*- coding: cp936 -*-
class Bird:
    def __init__(self, xLength, yLength, xPosition, yPosition, yScreenLength, popNumber):
        self.imageFileName = 'bird.png'
        self.xLength = xLength
        self.yLength = yLength
        self.initXPosition = xPosition
        self.initYPosition = yPosition
        self.yScreenLength = yScreenLength
        
        self.velocity = 0.25
        self.jump = -5
        self.popNumber = popNumber

        #self.xPosition = xPosition
        #self.yPosition = yPosition
        #self.scoreNow = 0

        self.xPosition = []
        self.yPosition = []
        self.gravity = []
        self.scoreNow = []
        self.crashFlag = []
        self.keyDownFlag = []
        self.keyDownFlagTimes = []

        self.flyTimes = 12
        
        for i in range(popNumber):
            self.xPosition.append(xPosition)
            self.yPosition.append(yPosition)
            self.gravity.append(0)
            self.scoreNow.append(0)
            self.crashFlag.append(False)
            self.keyDownFlag.append(False)
            self.keyDownFlagTimes.append(0)

    def loadPicture(self, pygame):
        self.image_bird = pygame.transform.smoothscale(pygame.image.load(self.imageFileName).convert_alpha(), (self.xLength, self.yLength))
        self.image_birdUp = pygame.transform.rotate(self.image_bird, 30)
        self.image_birdDown = pygame.transform.rotate(self.image_bird, -30)
        self.imageList = []
        for i in range(0, 60, 5):
            #0      5   10    15   20   25   30  35  40   40  50  55
            #-30  -25  -20   -15  -10  -5   0    5   10   15   20  25
            self.imageList.append(pygame.transform.rotate(self.image_bird, i-30))

    def getRotateUpPicture(self):
        return self.image_birdUp

    def getRotateDownPicture(self):
        return self.image_birdDown
        

    def getPicture(self):
        return self.image_bird

    def getXPosition(self, index):
        return self.xPosition[index]

    def getYPosition(self, index):
        return self.yPosition[index]

    def getPosition(self):
        allPosition = []
        for i in range(self.popNumber):
            #���Ͻ�(X,Y), ���Ͻ�(X,Y), ���½�(X,Y), ���½�(X,Y)
            position = []
            position.append([self.xPosition[i], self.yPosition[i]])
            position.append([self.xPosition[i]+self.xLength, self.yPosition[i]])
            position.append([self.xPosition[i], self.yPosition[i]+self.yLength])
            position.append([self.xPosition[i]+self.xLength, self.yPosition[i]+self.yLength])
            allPosition.append(position)

        return allPosition

    def setCrashFlag(self, allCrashFlag):
        for i in range(len(allCrashFlag)):
            self.crashFlag[i] = allCrashFlag[i]

    def getFitness(self):
        fitness = []
        for i in range(self.popNumber):
            fitness.append([self.scoreNow[i]])
        return fitness

    def getAverageFitness(self):
        AverageFitness = 0
        for i in range(self.popNumber):
            AverageFitness += self.scoreNow[i]
            
        return AverageFitness/self.popNumber       

    def reset(self):
        for i in range(self.popNumber):
            self.scoreNow[i] = 0
            self.gravity[i] = 0
            self.xPosition[i] = self.initXPosition
            self.yPosition[i] = self.initYPosition
            self.crashFlag[i] = False
            self.keyDownFlag[i] = False
            self.keyDownFlagTimes[i] = 0

    def updateOne(self, keyDownFlagOne, index):
        self.scoreNow[index] += 1
        if (keyDownFlagOne == True):
            self.gravity[index] = self.jump

        self.gravity[index] += self.velocity
        self.yPosition[index] += self.gravity[index]

        if(self.yPosition[index] < 0):
            self.yPosition[index] = 0
        elif (self.yPosition[index] > (self.yScreenLength-self.yLength)):
             self.yPosition[index] = self.yScreenLength - self.yLength

    #keyDownFlag = [ 50 True or False ]
    def update(self, keyDownFlag):
        for i in range(self.popNumber):
            self.keyDownFlag[i] = keyDownFlag[i]
            if (self.crashFlag[i] == False):
                self.updateOne(keyDownFlag[i], i)

    def draw(self, mainScreenPicture):
        for i in range(self.popNumber):
            if (self.crashFlag[i] == False):
                if(self.keyDownFlag[i] == True):
                    self.keyDownFlagTimes[i] = self.flyTimes
                    
                self.keyDownFlagTimes[i] -= 1
                if (self.keyDownFlagTimes[i] > 0): 
                    mainScreenPicture.blit(self.getRotateUpPicture(), (self.getXPosition(i), self.getYPosition(i)))
                    #mainScreenPicture.blit(self.imageList[int(self.keyDownFlagTimes[i])], (self.getXPosition(i), self.getYPosition(i)))
                else:
                    mainScreenPicture.blit(self.getRotateDownPicture(), (self.getXPosition(i), self.getYPosition(i)))

    
        
