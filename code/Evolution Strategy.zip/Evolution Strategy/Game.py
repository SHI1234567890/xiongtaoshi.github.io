# -*- coding: cp936 -*-
import pygame
import sys
import pygame.locals

import Screen
import Background
import MoveSpeed
import KeyEvent
import PipUp
import PipDown
import Bird
import Text
import Crash
import NeuralNetwork
import EvolutionStrategies

popNumber = 10

myNeuralNetworkGroup = NeuralNetwork.NeuralNetworkGroup(popNumber, [2, 2, 1])
myEvolutionStrategies = EvolutionStrategies.EvolutionStrategies(popNumber, \
                                                                myNeuralNetworkGroup.getBiasNum(), \
                                                                myNeuralNetworkGroup.getWeightNum())

myScreen = Screen.Screen(400, 512)
myMoveSpeed = MoveSpeed.MoveSpeed(2)
myKeyEvent = KeyEvent.KeyEvent()
myBackground = Background.Background(myScreen.getXLength(), \
                                                     myScreen.getYLength(), myMoveSpeed.getMoveSpeed())
myPipUp = PipUp.PipUp(25, 306, 106, myMoveSpeed.getMoveSpeed(), \
                                                      myScreen.getXLength(), myScreen.getXLength()/2)
myPipDown = PipDown.PipDown(25, 100, myMoveSpeed.getMoveSpeed(), \
                                                    myScreen.getXLength(), myScreen.getXLength()/2, myScreen.getYLength())
myBird = Bird.Bird(30, 20, 100, myScreen.getYLength()/2, myScreen.getYLength(), popNumber)
myText = Text.Text()
myCrash = Crash.Crash(popNumber)

#��ʼ��
pygame.init()
pygame.display.set_caption('Fly Bird')
mainScreenPicture = pygame.display.set_mode(myScreen.getLength(), 0, 32)
mainScreenText = pygame.font.SysFont('arial', 16)

myBackground.loadPicture(pygame)
myPipUp.loadPicture(pygame)
myPipDown.loadPicture(pygame, myPipUp.getPicture1Height(), myPipUp.getPicture2Height())
myBird.loadPicture(pygame)

myClock = pygame.time.Clock()

myKeyDownFlag = []
for i in range(50):
    myKeyDownFlag.append(False)

myAverageFitness = []
trainingTimes = 0

while True:
    myBackground.draw(mainScreenPicture)
    myPipUp.draw(mainScreenPicture)
    myPipDown.draw(mainScreenPicture)
    myBird.draw(mainScreenPicture)
    myText.printText(mainScreenPicture, mainScreenText, myCrash.getAliveNumber(), myCrash.getCrashFlag())

    if(myCrash.isAllCrash() == True):
        #start reset
        myCrash.reset()
        myText.reset()

        myPipUp.reset(pygame)
        myPipDown.reset(pygame, myPipUp.getPicture1Height(), myPipUp.getPicture2Height())
        myBackground.reset()
        myKeyEvent.reset()
        #1.����fitness 2.reCombination 3.��ES�еĲ������µ�NNG
        myEvolutionStrategies.setFitness(myBird.getFitness())
        myEvolutionStrategies.reCombination()
        myNeuralNetworkGroup.setParameter(myEvolutionStrategies.getParameter())
        myAverageFitness.append(myBird.getAverageFitness())
        print 'myAverageFitness', myAverageFitness
        myBird.reset()
        trainingTimes += 1

    #myClock.tick(60)
    myClock.tick(myKeyEvent.getSpeed())
    myBackground.update()
    myPipUp.update(pygame)
    myPipDown.update(pygame, myPipUp.getPicture1Height(), myPipUp.getPicture2Height())
    myCrash.update(myBird.getPosition(), myPipUp.getPosition(), myPipDown.getPosition())
    myBird.setCrashFlag(myCrash.getCrashFlag())
    #ʹ�����������
    myBird.update(myNeuralNetworkGroup.feedForword(myCrash.getDistance()))
    myText.update()
    
    myKeyEvent.update(pygame.event.get())
    pygame.display.update()
    


