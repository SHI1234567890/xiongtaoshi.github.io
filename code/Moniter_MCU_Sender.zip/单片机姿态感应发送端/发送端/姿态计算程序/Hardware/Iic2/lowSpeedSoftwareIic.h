#ifndef _LOWSPEED_SOFTWARE_IIC_H
#define	_LOWSPEED_SOFTWARE_IIC_H

#include "system.h"

ErrorStatus xLowSpeedSoftwareIicCheckDevice(uint8_t IicSlaveAddr);
ErrorStatus xLowSpeedSoftwareIicWrite(uint8_t IicSlaveAddr, uint8_t regAddr, uint8_t * buffer, uint32_t length);
ErrorStatus xLowSpeedSoftwareIicRead(uint8_t IicSlaveAddr, uint8_t regAddr, uint8_t * buffer, uint32_t length);

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */

