#ifndef _SPI1_H
#define _SPI1_H

#include "system.h"

void vSPI1_Init(void);
uint8_t ulSPI1_ReadWriteDataByBlockMode(uint8_t dat);

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
