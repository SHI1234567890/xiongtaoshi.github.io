#ifndef _TIMER3_H
#define _TIMER3_H

#include "system.h"

/* �����������ں궨�� */
#define TIMER3_CALLBACK_FREQUENCY_500HZ			((uint32_t)2000)
#define TIMER3_CALLBACK_FREQUENCY_1000HZ		((uint32_t)1000)

void vTIM3_Init(uint32_t ulPeriodInMs);

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
