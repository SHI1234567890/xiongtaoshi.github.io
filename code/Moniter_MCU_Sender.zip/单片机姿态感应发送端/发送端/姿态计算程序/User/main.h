#ifndef _MAIN_H
#define _MAIN_H

#include "system.h"
#include "usart1_dma.h"
#include "timer3.h"
#include "spi1.h"
#include "watchDog.h"  
#include "nrf24l01+.h"
#include "softwareIic.h"
#include "mpu6050.h"
#include "hmc5883l.h" 
#include "led.h"
#include "timer4Pwm.h"  
#include "util.h"

/* �豸��ʼ��ʧ�ܣ���Ӧ���豸ID */
typedef enum 
{
	NO_EXAMPLE_DEVICE = 0,
	NO_MPU6050_DEVICE,
	NO_HMC5883L_DEVICE,
	NO_NRF24L01_DEVICE
}SystemInitFaultTypedef;

#endif

/* end of file cppyright reserve by team of yanjun ,More information please browse www.yanjun.tech */
