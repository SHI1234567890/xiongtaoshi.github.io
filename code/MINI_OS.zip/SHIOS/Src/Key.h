#ifndef _KEY_H
#define _KEY_H

#include "stm32f1xx_hal.h"

#define KEY_NUMBER					((uint8_t)3)
#define KEY_0								((uint8_t)0)
#define KEY_1								((uint8_t)1)
#define KEY_2								((uint8_t)2)

#define ReadKey0()					HAL_GPIO_ReadPin(KEY0_GPIO_Port, KEY0_Pin);
#define ReadKey1()					HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin);
#define ReadKey2()					HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin);

#define KEY_UP	  ((uint8_t)0)
#define KEY_DOWN	((uint8_t)1)

void KEY_Scan(void);
uint8_t Key_Driver(void);

#endif
