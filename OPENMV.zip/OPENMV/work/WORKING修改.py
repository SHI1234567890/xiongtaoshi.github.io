import sensor, image, mjpeg, time, math, pyb, lcd

from pyb import Pin, ExtInt

from pyb import Timer

#设定区域
ROI = (40, 0, 260, 240)

GRAYSCALE_THRESHOLD = [(150, 255)]

# Camera setup...
sensor.reset() # Initialize the camera sensor.
sensor.set_pixformat(sensor.GRAYSCALE) # use grayscale.
sensor.set_framesize(sensor.QVGA) # use QQVGA for speed.
sensor.skip_frames(30) # Let new settings take affect.
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking
#关闭白平衡
clock = time.clock() # Tracks FPS.

lcd.init() # Initialize the lcd screen.

XPosition = 0
YPosition = 0

#初始化串口3
uart3 = pyb.UART(3, 115200)
uart3.init(115200, bits=8, parity=None, stop=1, timeout=10)

def FindTargetAndDraw():

    global XPosition
    global YPosition
    clock.tick() # Track elapsed milliseconds between snapshots().
    img = sensor.snapshot() # Take a picture and return the image.
    #利用颜色识别分别寻找三个矩形区域内的线段
    blobs = img.find_blobs(GRAYSCALE_THRESHOLD, x_stride=1, y_stride=1, merge=True, roi=ROI)
    #目标区域找到直线
    if blobs:
        # Find the index of the blob with the most pixels.
        most_pixels = 0
        largest_blob = 0
        for i in range(len(blobs)):
        #目标区域找到的颜色块（线段块）可能不止一个，找到最大的一个，作为本区域内的目标直线
            if blobs[i].pixels() > most_pixels:
                most_pixels = blobs[i].pixels()
                #merged_blobs[i][4]是这个颜色块的像素总数，如果此颜色块像素总数大于
                #most_pixels，则把本区域作为像素总数最大的颜色块。更新most_pixels和largest_blob
                #标记最大的一个
                largest_blob = i
        # Draw a rect around the blob.
        #将此区域的像素数最大的颜色块画矩形和十字形标记出来
        img.draw_rectangle(blobs[largest_blob].rect(), size=10)
        img.draw_cross(blobs[largest_blob].cx(),
                       blobs[largest_blob].cy())
        print("find target ", blobs[largest_blob].cx(), blobs[largest_blob].cy())
        XPosition = blobs[largest_blob].cx()
        YPosition = blobs[largest_blob].cy()
        UartSendData()
    img.draw_rectangle(ROI, size=10)
    img.draw_string(100, 100, 'X:' + '%d' %XPosition + '\n' + 'Y:' + '%d' %YPosition + '\n')
    lcd.display(img)
    print(clock.fps())

def FindTarget():
    global XPosition
    global YPosition
    clock.tick() # Track elapsed milliseconds between snapshots().
    img = sensor.snapshot() # Take a picture and return the image.
    #利用颜色识别分别寻找三个矩形区域内的线段
    blobs = img.find_blobs(GRAYSCALE_THRESHOLD, x_stride=1, y_stride=1, merge=True, roi=ROI)
    #目标区域找到直线
    if blobs:
        # Find the index of the blob with the most pixels.
        most_pixels = 0
        largest_blob = 0
        for i in range(len(blobs)):
        #目标区域找到的颜色块（线段块）可能不止一个，找到最大的一个，作为本区域内的目标直线
            if blobs[i].pixels() > most_pixels:
                most_pixels = blobs[i].pixels()
                #merged_blobs[i][4]是这个颜色块的像素总数，如果此颜色块像素总数大于
                #most_pixels，则把本区域作为像素总数最大的颜色块。更新most_pixels和largest_blob
                #标记最大的一个
                largest_blob = i
        # Draw a rect around the blob.
        #将此区域的像素数最大的颜色块画矩形和十字形标记出来
        #img.draw_rectangle(blobs[largest_blob].rect())
        #img.draw_cross(blobs[largest_blob].cx(), blobs[largest_blob].cy())
        print("find target ", blobs[largest_blob].cx(), blobs[largest_blob].cy())
        XPosition = blobs[largest_blob].cx()
        YPosition = blobs[largest_blob].cy()
        UartSendData()
    #img.draw_rectangle(ROI)
    print(clock.fps())

#等待串口数据到达
def UartReadData():
    global uart3

    print("UartReadData")
    #等待数据的到来
    uartData = uart3.readall()
    while (uartData == None):
        uartData = uart3.readall()
        print("no data arrived")
        #寻找目标点
        FindTargetAndDraw()
    #数据到来了
    print("data arrived")
    print(uartData)

#发送数据
def UartSendData():
    global uart3
    global XPosition
    global YPosition

    led1 = pyb.LED(1)
    led1.toggle()

    led3 = pyb.LED(3)
    led3.toggle()

    uart3.writechar(0x8c)

    temp = XPosition
    uart3.writechar((temp >> 8)&0xff)
    uart3.writechar(temp&0xff)

    temp = YPosition
    uart3.writechar((temp >> 8)&0xff)
    uart3.writechar(temp&0xff)

    uart3.writechar(0x8b)

#开机默认进入校准模式
UartReadData()

while(True):
    FindTarget()
